import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createConversation, appendMessage, getConversation } from "../src/core/conversations.js";
import { createConversationField } from "../src/core/conversation-field.js";
import { createProvenance } from "../src/core/field.js";
import { LocalFieldStore } from "../src/core/field-store.js";
import { LinkedDeletionCoordinator } from "../src/core/linked-deletion.js";

async function fixture(context) {
  const directory = await fs.mkdtemp(join(tmpdir(), "aether-linked-delete-"));
  context.after(() => fs.rm(directory, { recursive: true, force: true }));
  const conversationRoot = join(directory, "conversations");
  await fs.mkdir(conversationRoot, { mode: 0o700 });
  const conversation = await createConversation("private title", conversationRoot);
  await appendMessage(conversation.id, "user", "private message", conversationRoot);
  const fieldStore = new LocalFieldStore({ root: join(directory, "fields") });
  const snapshot = createConversationField({ id: "field", initialStateId: "root", createdAt: "2026-09-12T00:00:00.000Z",
    provenance: createProvenance({ sourceType: "human", sourceId: "owner", method: "explicit scope" }), conversationId: conversation.id, permission: true });
  await fieldStore.save(snapshot, { requestId: "save" });
  const settings = { root: join(directory, "deletions"), conversationRoot, fieldStore };
  const coordinator = new LinkedDeletionCoordinator(settings);
  const review = await coordinator.review(conversation.id, "field");
  const command = { conversationId: conversation.id, fieldId: "field", requestId: "delete-both", expectedRevision: review.expectedRevision, conversationDigest: review.conversationDigest };
  return { ...settings, coordinator, command, snapshot, conversation };
}

test("linked deletion removes both sides, retains no message text in journal, and replays after restart", async (context) => {
  const f = await fixture(context);
  const other = await createConversation("unrelated", f.conversationRoot);
  assert.equal((await f.coordinator.deleteLinked(f.command, { permission: true })).deleted, true);
  await assert.rejects(getConversation(f.conversation.id, f.conversationRoot), { statusCode: 404 });
  await assert.rejects(f.fieldStore.load("field"), { code: "FIELD_DELETED" });
  assert.equal((await getConversation(other.id, f.conversationRoot)).title, "unrelated");
  const reopened = new LinkedDeletionCoordinator(f);
  assert.equal((await reopened.status(f.conversation.id)).phase, "complete");
  assert.equal((await reopened.deleteLinked(f.command, { permission: true })).replayed, true);
  assert.equal((await reopened.deleteLinked(Object.fromEntries(Object.entries(f.command).reverse()), { permission: true })).replayed, true);
  await assert.rejects(reopened.withActiveConversation(f.conversation.id, () => assert.fail("must not write")), { code: "LINK_DELETING" });
  for (const name of await fs.readdir(f.root)) {
    const text = await fs.readFile(join(f.root, name), "utf8");
    assert.equal(text.includes("private message"), false);
    assert.equal(text.includes("private title"), false);
  }
});

for (const failedPublication of [1, 2, 3]) {
  test(`restart resumes after journal publication ${failedPublication} loses acknowledgement`, async (context) => {
    const f = await fixture(context);
    let count = 0;
    const faulty = new LinkedDeletionCoordinator({ ...f, fileSystem: { ...fs, async rename(...args) {
      await fs.rename(...args);
      if (++count === failedPublication) throw new Error("lost acknowledgement");
    } } });
    await assert.rejects(faulty.deleteLinked(f.command, { permission: true }), { code: "LINK_DELETE_UNCERTAIN" });
    const reopened = new LinkedDeletionCoordinator(f);
    await assert.rejects(reopened.withActiveConversation(f.conversation.id, () => assert.fail()), { code: "LINK_DELETING" });
    const saved = await reopened.status(f.conversation.id);
    assert.ok(saved.command);
    await reopened.deleteLinked(saved.command, { permission: true });
    assert.equal((await reopened.status(f.conversation.id)).phase, "complete");
    await assert.rejects(getConversation(f.conversation.id, f.conversationRoot), { statusCode: 404 });
    await assert.rejects(f.fieldStore.save(f.snapshot, { requestId: "save" }), { code: "FIELD_DELETED" });
  });
}

test("failed conversation deletion leaves recoverable partial completion", async (context) => {
  const f = await fixture(context);
  const path = join(f.conversationRoot, `${f.conversation.id}.json`);
  const faulty = new LinkedDeletionCoordinator({ ...f, fileSystem: { ...fs, async unlink(target) {
    if (target === path) throw new Error("conversation removal blocked");
    return fs.unlink(target);
  } } });
  await assert.rejects(faulty.deleteLinked(f.command, { permission: true }), { code: "LINK_DELETE_UNCERTAIN" });
  assert.equal((await f.coordinator.status(f.conversation.id)).phase, "field-deleted");
  assert.ok(await getConversation(f.conversation.id, f.conversationRoot));
  await f.coordinator.deleteLinked(f.command, { permission: true });
});

test("permission and stale review fail before intent or either deletion", async (context) => {
  const f = await fixture(context);
  await assert.rejects(f.coordinator.deleteLinked(f.command), { code: "LINK_PERMISSION_REQUIRED" });
  await appendMessage(f.conversation.id, "user", "new work", f.conversationRoot);
  await assert.rejects(f.coordinator.deleteLinked(f.command, { permission: true }), { code: "LINK_CONFLICT" });
  assert.equal(await f.coordinator.status(f.conversation.id), null);
  assert.ok(await f.fieldStore.load("field"));
  assert.ok(await getConversation(f.conversation.id, f.conversationRoot));
});

test("failure before intent publication leaves both stores intact", async (context) => {
  const f = await fixture(context);
  const faulty = new LinkedDeletionCoordinator({ ...f, fileSystem: { ...fs, async rename() { throw new Error("disk failure"); } } });
  await assert.rejects(faulty.deleteLinked(f.command, { permission: true }), { code: "LINK_DELETE_UNCERTAIN" });
  assert.equal(await f.coordinator.status(f.conversation.id), null);
  assert.ok(await f.fieldStore.load("field"));
  assert.ok(await getConversation(f.conversation.id, f.conversationRoot));
});

test("write guard holds ownership across asynchronous capture and refuses competing deletion", async (context) => {
  const f = await fixture(context);
  let started, release;
  const ready = new Promise((resolve) => { started = resolve; });
  const gate = new Promise((resolve) => { release = resolve; });
  const writing = f.coordinator.withActiveConversation(f.conversation.id, async () => { started(); await gate; });
  await ready;
  try { await assert.rejects(f.coordinator.deleteLinked(f.command, { permission: true }), { code: "LINK_LOCKED" }); }
  finally { release(); await writing; }
  await f.coordinator.deleteLinked(f.command, { permission: true });
});

test("journal corruption is never reset and changed retry scope is refused", async (context) => {
  const f = await fixture(context);
  await f.coordinator.deleteLinked(f.command, { permission: true });
  await assert.rejects(f.coordinator.deleteLinked({ ...f.command, fieldId: "another" }, { permission: true }), { code: "LINK_CONFLICT" });
  const file = (await fs.readdir(f.root)).find((name) => name.endsWith(".json"));
  await fs.writeFile(join(f.root, file), "broken", { mode: 0o600 });
  await assert.rejects(f.coordinator.withActiveConversation(f.conversation.id, () => assert.fail()), { code: "LINK_CORRUPT" });
});
