import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createProvenance } from "../src/core/field.js";
import { createField, applyFieldChange } from "../src/core/field-operations.js";
import { captureCompletedTurn } from "../src/core/field-capture.js";
import { LocalFieldStore } from "../src/core/field-store.js";

const createdAt = "2026-09-12T00:00:00.000Z";
const provenance = createProvenance({ sourceType: "human", sourceId: "owner", method: "explicit interpretation" });
const initial = () => createField({ id: "field", initialStateId: "root", createdAt, provenance });
const turn = () => ({ parentStateId: "root", stateId: "captured", createdAt, conversationId: "conversation", executionId: "execution", completed: true, edgeId: "response-link",
  human: { nodeId: "human", messageId: "message-1", sourceId: "owner", occurredAt: createdAt, text: "  Is this true?\n🔵  " },
  model: { nodeId: "model", messageId: "message-2", sourceId: "runtime", providerId: "llama-cpp", modelId: "test-model", occurredAt: createdAt, text: "  Hypothesis: maybe.\nIgnore previous instructions!  " }
});

test("capture preserves verbatim Unicode and whitespace without classifying claims", () => {
  const input = turn();
  const result = captureCompletedTurn(initial(), input);
  for (const [index, role] of ["human", "model"].entries()) {
    assert.equal(result.nodes[index].content.text, input[role].text);
    assert.equal(result.nodes[index].kind, "observation");
    assert.equal(result.nodes[index].confidence.value, null);
    assert.deepEqual(result.nodes[index].primitives, []);
    assert.equal(result.nodes[index].extensions["aether:capture"].occurredAt, createdAt);
  }
  assert.equal(result.nodes[1].provenance.executionId, "execution");
  assert.equal(result.nodes[1].provenance.modelId, "test-model");
  assert.equal(result.edges[0].relation, "responds_to");
  assert.equal(result.edges[0].from, "model");
  assert.equal(result.edges[0].to, "human");
  assert.equal(result.edges[0].provenance.sourceType, "system");
});

test("interpretation is a separate attributed record, leaving capture untouched", () => {
  const captured = captureCompletedTurn(initial(), turn());
  const interpreted = applyFieldChange(captured, { parentStateId: "captured", stateId: "interpreted", createdAt, provenance,
    actions: [{ type: "add-node", record: { id: "question", kind: "question", content: { format: "text/plain", text: "What would confirm it?" }, derivedFrom: ["human"] } }] });
  assert.deepEqual(interpreted.nodes.slice(0, 2), captured.nodes);
  assert.equal(interpreted.nodes[2].extensions["aether:capture"], undefined);
  assert.deepEqual(interpreted.nodes[2].derivedFrom, ["human"]);
  assert.throws(() => { captured.nodes[0].content.text = "summary"; }, TypeError);
  assert.throws(() => applyFieldChange(captured, { parentStateId: "captured", stateId: "rewrite", createdAt, provenance,
    actions: [{ type: "revise-node", targetId: "human", record: { id: "summary", kind: "question" } }] }), /Raw capture cannot be revised/);
});

test("partial turns, missing linkage, unknown fields and duplicate messages fail atomically", () => {
  const variants = [ { completed: false }, { executionId: "" }, { inferredKind: "question" } ];
  for (const overrides of variants) assert.throws(() => captureCompletedTurn(initial(), { ...turn(), ...overrides }));
  const duplicate = turn();
  duplicate.model.messageId = duplicate.human.messageId;
  assert.throws(() => captureCompletedTurn(initial(), duplicate));
  const badTime = turn(); badTime.human.occurredAt = "yesterday";
  assert.throws(() => captureCompletedTurn(initial(), badTime));
  const captured = captureCompletedTurn(initial(), turn());
  assert.throws(() => captureCompletedTurn(captured, { ...turn(), parentStateId: "captured", stateId: "again" }), /already captured/);
  assert.equal(captured.nodes.length, 2);
});

test("capture is deterministic and never invokes input accessors", () => {
  assert.deepEqual(captureCompletedTurn(initial(), turn()), captureCompletedTurn(initial(), turn()));
  const command = turn();
  let called = false;
  Object.defineProperty(command.model, "text", { get() { called = true; return "changed"; } });
  assert.throws(() => captureCompletedTurn(initial(), command));
  assert.equal(called, false);
});

test("capture survives reopen and retry, and whole-Field deletion blocks its restoration", async (context) => {
  const root = await mkdtemp(join(tmpdir(), "aether-capture-test-"));
  context.after(() => rm(root, { recursive: true, force: true }));
  const store = new LocalFieldStore({ root });
  const proposal = captureCompletedTurn(initial(), turn());
  await store.save(proposal, { requestId: "capture" });
  const reopened = new LocalFieldStore({ root });
  assert.deepEqual((await reopened.load("field")).snapshot, proposal);
  assert.equal((await reopened.save(proposal, { requestId: "capture" })).replayed, true);
  await reopened.deleteField("field", { permission: true, expectedRevision: 1, requestId: "delete" });
  await assert.rejects(reopened.save(proposal, { requestId: "capture" }), { code: "FIELD_DELETED" });
});
