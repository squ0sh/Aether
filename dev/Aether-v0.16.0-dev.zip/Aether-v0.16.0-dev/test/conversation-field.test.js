import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createProvenance } from "../src/core/field.js";
import { applyFieldChange, createField } from "../src/core/field-operations.js";
import { createConversationField, reviewConversationFieldDeletion } from "../src/core/conversation-field.js";
import { captureCompletedTurn } from "../src/core/field-capture.js";
import { LocalFieldStore } from "../src/core/field-store.js";

const createdAt = "2026-09-12T00:00:00.000Z";
const provenance = createProvenance({ sourceType: "human", sourceId: "owner", method: "explicit scope choice" });
const base = { id: "field", initialStateId: "root", createdAt, provenance };
const dedicated = () => createConversationField({ ...base, conversationId: "chat-1", permission: true });
const options = { conversationId: "chat-1", requestId: "delete", expectedRevision: 1, permission: true };
async function fixture(context) {
  const root = await fs.mkdtemp(join(tmpdir(), "aether-conversation-field-"));
  context.after(() => fs.rm(root, { recursive: true, force: true }));
  return { root, store: new LocalFieldStore({ root }) };
}
const interpretation = (snapshot, source = provenance) => applyFieldChange(snapshot, {
  parentStateId: "root", stateId: "interpretation", createdAt, provenance: source,
  actions: [{ type: "add-node", record: { id: "claim", kind: "hypothesis", content: { format: "text/plain", text: "private interpretation" } } }]
});

test("dedicated scope is explicit and deletion review describes all retained content", () => {
  assert.throws(() => createConversationField({ ...base, conversationId: "chat-1", permission: false }));
  const snapshot = interpretation(dedicated());
  const review = reviewConversationFieldDeletion({ snapshot, revision: 2 }, "chat-1");
  assert.equal(review.expectedRevision, 2);
  assert.equal(review.nodeCount, 1);
  assert.equal(review.stateCount, 2);
  assert.equal(review.scope, "entire-dedicated-field");
  assert.ok(Object.isFrozen(review));
  assert.throws(() => reviewConversationFieldDeletion({ snapshot, revision: 2 }, "chat-2"));
  assert.throws(() => reviewConversationFieldDeletion({ snapshot: createField(base), revision: 1 }, "chat-1"));
});

test("scoped deletion removes interpretations, reopens safely and blocks old saves", async (context) => {
  const { root, store } = await fixture(context);
  const snapshot = interpretation(dedicated());
  await store.save(snapshot, { requestId: "save" });
  const review = reviewConversationFieldDeletion(await store.load("field"), "chat-1");
  await store.deleteConversationField(review.fieldId, options);
  const reopened = new LocalFieldStore({ root });
  await assert.rejects(reopened.load("field"), { code: "FIELD_DELETED" });
  await assert.rejects(reopened.save(snapshot, { requestId: "save" }), { code: "FIELD_DELETED" });
  assert.equal((await reopened.deleteConversationField("field", options)).replayed, true);
  await assert.rejects(reopened.deleteConversationField("field", { ...options, conversationId: "chat-2" }), { code: "FIELD_REQUEST_CONFLICT" });
  await assert.rejects(reopened.deleteField("field", options), { code: "FIELD_REQUEST_CONFLICT" });
});

test("scoped deletion refuses generic, wrong-conversation, and mixed Fields", async (context) => {
  const { store } = await fixture(context);
  const foreign = createProvenance({ sourceType: "human", sourceId: "other", conversationId: "chat-2", method: "other conversation" });
  for (const [index, snapshot] of [createField(base), dedicated(), interpretation(dedicated(), foreign)].entries()) {
    const field = { ...snapshot, id: `field-${index}`, nodes: snapshot.nodes.map((n) => ({ ...n, fieldId: `field-${index}` })),
      states: snapshot.states.map((s) => ({ ...s, fieldId: `field-${index}` })) };
    await store.save(field, { requestId: "save" });
    await assert.rejects(store.deleteConversationField(field.id, { ...options, conversationId: index === 1 ? "chat-2" : "chat-1" }), { code: "FIELD_SCOPE_CONFLICT" });
    assert.deepEqual((await store.load(field.id)).snapshot, field);
  }
});

test("scope and revision are checked inside writer protection", async (context) => {
  const { store } = await fixture(context);
  await store.save(dedicated(), { requestId: "save" });
  await assert.rejects(store.deleteConversationField("field", { ...options, permission: false }), { code: "FIELD_PERMISSION_REQUIRED" });
  await store.save(interpretation(dedicated()), { requestId: "new-work" });
  await assert.rejects(store.deleteConversationField("field", options), { code: "FIELD_CONFLICT" });
  assert.equal((await store.load("field")).snapshot.nodes.length, 1);
});

test("scoped deletion retries safely after publication acknowledgement is lost", async (context) => {
  const { root, store } = await fixture(context);
  await store.save(dedicated(), { requestId: "save" });
  const faulty = new LocalFieldStore({ root, fileSystem: { ...fs, async rename(...args) { await fs.rename(...args); throw new Error("lost acknowledgement"); } } });
  await assert.rejects(faulty.deleteConversationField("field", options), { code: "FIELD_DELETE_UNCERTAIN" });
  assert.equal((await store.deleteConversationField("field", options)).replayed, true);
});

test("raw capture cannot mix a different conversation into a dedicated Field", () => {
  const command = { parentStateId: "root", stateId: "turn", createdAt, conversationId: "chat-2", executionId: "run", completed: true, edgeId: "edge",
    human: { nodeId: "human", messageId: "h", sourceId: "owner", occurredAt: createdAt, text: "question" },
    model: { nodeId: "model", messageId: "m", sourceId: "model", occurredAt: createdAt, text: "answer", providerId: "mock", modelId: "mock" } };
  assert.throws(() => captureCompletedTurn(dedicated(), command), /not explicitly dedicated/);
  const captured = captureCompletedTurn(dedicated(), { ...command, conversationId: "chat-1" });
  assert.equal(captured.nodes.length, 2);
});
