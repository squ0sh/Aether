import { STRUCTURAL_TERMS, STRUCTURAL_VERSION } from "../../src/core/structural-vocabulary.js";

// Synthetic descriptions, not observations of real systems. Recipe expansion only
// supplies dependency links; all interpretive attributes below are hand-authored.
function scenario(spec, requested) {
  const context = { scope: spec.scope, scale: spec.scale, conditions: spec.conditions, referenceFrame: spec.frame };
  const attributes = {
    distinction: { criterion: spec.distinction, entities: spec.entities },
    relation: { aspect: spec.relation, entities: spec.entities },
    reference: { frame: spec.frame, baseline: spec.baseline, dimension: spec.dimension },
    possibility: { alternatives: spec.alternatives, modality: "considered" },
    constraint: { restriction: spec.restriction, appliesTo: spec.entities },
    magnitude: { quantity: spec.quantity, unitOrScale: spec.unit, reference: spec.baseline },
    order: { basis: spec.order, sequence: spec.sequence, causality: "not-implied" },
    equivalence: { criterion: spec.equivalence, retainedDifferences: spec.differences },
    context: { scope: spec.scope, scale: spec.scale, conditions: spec.conditions },
    change: { configurations: spec.sequence },
    transformation: { mapping: spec.mapping, retainedHistory: spec.history },
    ...requested
  };
  const structures = new Map();
  function include(term) {
    if (structures.has(term)) return;
    const definition = STRUCTURAL_TERMS[term];
    definition.requires.forEach(include);
    structures.set(term, {
      id: `${spec.id}:${term}`, term,
      dependsOn: definition.requires.map((dependency) => `${spec.id}:${dependency}`),
      description: `${spec.scope}: candidate ${term} description; not an empirical finding.`,
      attributes: attributes[term]
    });
  }
  Object.keys(requested).forEach(include);
  return {
    id: spec.id,
    payload: {
      schemaVersion: 1, vocabularyVersion: STRUCTURAL_VERSION, outcome: "represented",
      sourceNodeIds: spec.sources ?? [`${spec.id}:observation`], context,
      structures: [...structures.values()], limits: [spec.limit], counterexamples: [spec.counterexample],
      unrepresentableReason: null
    }
  };
}

export const structuralCases = [
  scenario({
    id: "thermostat", scope: "Synthetic thermostat control loop", scale: "one room; one-second samples",
    conditions: "fixed set point; no claim about an actual device", frame: "room temperature relative to set point",
    entities: ["temperature sensor", "heater relay", "room"], distinction: "different roles in the stated control loop",
    relation: "sensor readings are described as inputs to relay switching", baseline: "20 degrees Celsius set point",
    dimension: "temperature error", order: "sample index", sequence: ["below set point", "relay on", "next reading"],
    mapping: "sample temperature, select relay state, then sample again", history: "retain each relay transition and sensor reading",
    limit: "The loop description does not verify wiring or establish stable control.",
    counterexample: "A disconnected heater can preserve the listed sequence without warming the room."
  }, {
    feedback: { path: ["temperature sensor", "heater relay", "room", "next sensor reading"], returnInfluence: "the described heater output changes the next temperature input", mechanismStatus: "hypothesized" }
  }),
  scenario({
    id: "cell-membrane", scope: "Synthetic membrane transport sketch", scale: "one compartment; one tracer assay",
    conditions: "tracer not detected during the stated interval", frame: "inside versus outside the sketched compartment",
    entities: ["inside compartment", "outside compartment"], distinction: "position relative to the membrane",
    relation: "possible transport across a separating membrane", restriction: "the sketch permits some transitions and restricts others",
    baseline: "outside tracer sample", dimension: "tracer detection",
    limit: "Non-detection alone does not establish absence or impermeability.",
    counterexample: "A more sensitive assay could detect transport below the original detection threshold."
  }, {
    boundary: { restrictedTransitions: "movement from outside to inside depends on the sketched membrane selectivity" },
    absence: { status: "not-observed", method: null, coverage: null }
  }),
  scenario({
    id: "recursive-program", scope: "Synthetic recursive list accumulator", scale: "one invocation per list element",
    conditions: "finite list; no claim that arbitrary recursion terminates", frame: "function invocation and argument tuple",
    entities: ["current accumulator", "next accumulator"], distinction: "argument values before and after consuming one element",
    relation: "updated accumulator is passed to the next invocation", baseline: "initial accumulator", dimension: "remaining list length",
    order: "call trace index", sequence: ["consume head", "update accumulator", "recur on tail"],
    mapping: "map an accumulator and nonempty list to an updated accumulator and tail", history: "retain the consumed element at each call",
    equivalence: "same function signature and recurrence rule", differences: ["argument values", "remaining list length"],
    limit: "Recurring call shape does not prove termination or correctness.",
    counterexample: "Passing the unchanged list instead of its tail preserves call shape but can fail to terminate."
  }, {
    recursion: { outputToInput: "the updated accumulator becomes the accumulator argument of the same function", recurrenceCriterion: "same function receives accumulator and remaining-list arguments" }
  }),
  scenario({
    id: "pendulum", scope: "Synthetic ideal pendulum model", scale: "one modeled swing at macroscopic scale",
    conditions: "undamped fixed-length model with a stated energy formula", frame: "pivot-fixed coordinates",
    entities: ["initial modeled state", "later modeled state"], distinction: "angle and angular velocity values",
    relation: "states related by the specified model evolution", baseline: "initial modeled energy", dimension: "model time",
    order: "increasing model time", sequence: ["initial angle and velocity", "later angle and velocity"],
    mapping: "advance the stated ideal model by one time step", history: "retain intervening modeled angle and velocity states",
    equivalence: "equal total modeled mechanical energy within the declared numerical tolerance", differences: ["angle", "angular velocity"],
    limit: "The proposed invariant applies only to the ideal model, not every physical pendulum.",
    counterexample: "Adding damping to the model can make the selected energy decrease."
  }, {
    invariant: { property: "total modeled mechanical energy", transformation: "time evolution under the stated undamped model", context: "fixed-length ideal pendulum without energy exchange", scale: "one modeled swing; macroscopic approximation", criterion: "energy difference no greater than the declared numerical tolerance" }
  }),
  scenario({
    id: "ecosystem", scope: "Synthetic three-population food-web sketch", scale: "population-level seasonal diagram",
    conditions: "arrows summarize the scenario rather than measured interaction strengths", frame: "declared population grouping",
    entities: ["producer population", "grazer population", "predator population"], distinction: "named populations in the sketch",
    relation: "declared feeding links", order: "diagram's producer-to-consumer grouping", sequence: ["producer grouping", "consumer grouping"],
    limit: "Topology and grouping omit rates, adaptive behavior, and environmental drivers.",
    counterexample: "The same arrows with different interaction strengths can yield different dynamics."
  }, {
    network: { topology: "producer to grazer to predator, with each arrow labeled as a feeding link", omittedMechanisms: ["interaction strengths", "seasonal external drivers"] },
    hierarchy: { levels: ["producer grouping", "consumer grouping"], orderingCriterion: "diagram's declared trophic grouping, not a ranking of importance" }
  }),
  scenario({
    id: "market", scope: "Synthetic market-attention simulation", scale: "two simulated attention trajectories over ten ticks",
    conditions: "attention follows visible repost counts in this toy rule", frame: "simulation tick and exposure count",
    entities: ["low-exposure post", "high-exposure post"], distinction: "exposure count at a given tick",
    relation: "toy allocation rule moves attention toward higher visible exposure", baseline: "initial exposure count", dimension: "simulation tick",
    order: "tick index", sequence: ["initial allocation", "reallocation after visible reposts"],
    quantity: "simulated attention share", unit: "fraction of simulated viewers",
    mapping: "apply the toy attention allocation rule once", history: "retain repost counts and allocations at each tick",
    limit: "Popularity in this simulation is not evidence that a post is accurate or valuable.",
    counterexample: "A false claim can gain the same simulated attention as a correct claim."
  }, {
    attractor: { dynamics: "toy reallocation toward posts with higher visible repost counts", trajectories: ["low initial attention moving toward popular post", "high initial attention remaining near popular post"], convergence: "the two toy trajectories approach the same attention allocation" },
    "informational-gravity": { measure: "share of simulated viewers attending to a post", epistemicSupport: "not-implied", status: "experimental" }
  }),
  scenario({
    id: "human-conversation", scope: "Synthetic clarification dialogue", scale: "three turns in one fictional exchange",
    conditions: "participants and goal are supplied by the fixture author", frame: "turn-indexed request and response",
    entities: ["requesting participant", "responding participant"], distinction: "speaker role in the fictional exchange",
    relation: "a clarification response changes the next request", baseline: "initial ambiguous request", dimension: "turn index",
    order: "recorded fictional turn order", sequence: ["ambiguous request", "clarifying question", "revised request"],
    mapping: "use the clarification response to revise the request", history: "retain the ambiguous request as well as its revision",
    alternatives: ["ask a clarifying question", "offer a tentative interpretation"], restriction: "only the stated dialogue choices are considered",
    limit: "A goal-directed dialogue description does not establish consciousness or personhood.",
    counterexample: "A scripted dialogue can exhibit the same turn-selection pattern."
  }, {
    feedback: { path: ["request", "clarification", "revised request"], returnInfluence: "clarification changes the next request", mechanismStatus: "described-not-verified" },
    "agentive-structure": { selectionRule: "ask for clarification when the request has two stated readings", goals: ["resolve the stated ambiguity"], agencyStatus: "interpretation-not-personhood" }
  }),
  scenario({
    id: "neural-circuit", scope: "Synthetic two-site voltage trace", scale: "two labeled recording sites at millisecond resolution",
    conditions: "trace values are fictional; no causal circuit model is supplied", frame: "voltage relative to the declared electrode reference",
    entities: ["site A", "site B"], distinction: "recording site label", baseline: "declared zero-voltage reference",
    dimension: "ordered recording position", order: "site order in the sketch", sequence: ["site A", "site B"],
    quantity: "fictional voltage reading", unit: "millivolts",
    limit: "A signed voltage difference does not identify a mechanism or direction of causal influence.",
    counterexample: "Changing the reference electrode can alter signed readings without changing the named sites."
  }, {
    gradient: { variation: "voltage differs between the two fictional recording sites", dimension: "position along the sketched recording axis" },
    polarity: { directions: ["above the declared voltage reference", "below the declared voltage reference"], baseline: "declared zero-voltage reference" }
  }),
  scenario({
    id: "orbit", scope: "Synthetic circular-orbit coordinate model", scale: "one idealized modeled revolution",
    conditions: "coordinate description only; no claim about an observed orbit", frame: "central-body-fixed coordinates",
    entities: ["original coordinate description", "rotated coordinate description"], distinction: "coordinate orientation",
    relation: "coordinate rotation maps one description to the other", baseline: "chosen angular origin", dimension: "modeled orbital phase",
    order: "increasing model phase", sequence: ["phase zero", "half revolution", "full revolution"],
    mapping: "rotate the coordinate axes while retaining the modeled separation", history: "retain phase progression separately from the endpoint description",
    equivalence: "equal modeled separation after coordinate rotation", differences: ["coordinate components", "chosen angular origin"],
    limit: "Coordinate symmetry and a return criterion do not prove dynamical stability.",
    counterexample: "A perturbed noncircular trajectory can fail the stated return criterion."
  }, {
    symmetry: { transformation: "rotation of coordinate axes about the model origin", criterion: "equal modeled separation from the origin", scope: "coordinate descriptions of the same synthetic circular model" },
    cycle: { path: ["phase zero", "half revolution", "full revolution"], returnCriterion: "equal modeled position modulo one full revolution" }
  }),
  scenario({
    id: "copied-source-misinformation", scope: "Synthetic copied-claim lineage", scale: "three fictional publications",
    conditions: "all three explicitly cite one originating claim", frame: "declared publication lineage",
    sources: ["claim-original", "claim-copy-a", "claim-copy-b"],
    entities: ["originating publication", "first copy", "second copy"], distinction: "publication identity rather than evidential origin",
    relation: "copies repeat the originating claim", baseline: "originating publication", dimension: "declared source lineage",
    limit: "A declared lineage can itself be wrong, and repeated publication is not independent confirmation.",
    counterexample: "An independently obtained observation would need its own attributed source rather than another copy."
  }, {
    independence: { lineages: [
      { observationId: "claim-original", originId: "single-original-claim" },
      { observationId: "claim-copy-a", originId: "single-original-claim" },
      { observationId: "claim-copy-b", originId: "single-original-claim" }
    ], assessment: "shared-origin" }
  }),
  scenario({
    id: "hidden-common-cause", scope: "Synthetic paired-alarm association", scale: "two fictional alarms over one interval",
    conditions: "only simultaneous alarm logs are supplied", frame: "shared log clock",
    entities: ["alarm A", "alarm B"], relation: "both alarms appear in the same time window",
    order: "logged timestamps", sequence: ["first joint alarm window", "later joint alarm window"],
    restriction: "no intervention or independent mechanism measurement is present",
    limit: "Association and temporal order do not distinguish direct influence from a shared driver.",
    counterexample: "A common power fluctuation can trigger both alarms without either causing the other."
  }, {
    causality: { status: "hypothesis", basis: "association", alternativeExplanations: ["hidden common power fluctuation", "coincidental overlap"] }
  }),
  scenario({
    id: "same-endpoint-different-histories", scope: "Synthetic account-balance paths", scale: "two fictional two-step ledgers",
    conditions: "each starts and ends at balance ten with different entries", frame: "ledger entry order",
    entities: ["ledger A", "ledger B"], distinction: "ordered transaction histories", relation: "histories share a final balance",
    baseline: "initial balance ten", dimension: "ledger step", order: "transaction order",
    sequence: ["initial balance ten", "intermediate balance", "final balance ten"],
    mapping: "apply each ledger's two signed entries to the initial balance", history: "A records plus five then minus five; B records minus two then plus two",
    equivalence: "equal final numeric balance", differences: ["intermediate balance", "transaction amounts", "transaction signs in order"],
    limit: "Equal endpoints omit intermediate balances and do not imply equivalent experiences or risks.",
    counterexample: "A minimum-balance constraint can distinguish the paths even when their endpoints match."
  }, {
    "path-dependence": { histories: ["ten to fifteen to ten", "ten to eight to ten"], endpointCriterion: "equal final numeric balance", historyCriterion: "equal ordered signed transaction entries", historyEquivalence: "different-under-criterion" }
  }),
  scenario({
    id: "same-topology-different-mechanisms", scope: "Synthetic plumbing and message-routing analogy", scale: "two three-node diagrams",
    conditions: "diagrams share adjacency but specify different link meanings", frame: "labeled graph adjacency",
    entities: ["plumbing chain", "message-routing chain"], distinction: "physical flow versus message forwarding",
    relation: "both diagrams connect A to B and B to C", equivalence: "matching directed adjacency under the stated node correspondence",
    differences: ["fluid transport versus discrete messages", "pressure constraints versus forwarding rules"],
    limit: "Matching topology does not establish matching mechanisms, quantities, or failure modes.",
    counterexample: "A blocked pipe and a dropped packet can produce different subsequent dynamics."
  }, {
    analogy: { criterion: "matching directed adjacency under A-to-A, B-to-B, C-to-C correspondence", retainedDifferences: ["fluid transport versus discrete messages", "pressure constraints versus forwarding rules"], mechanismEquivalence: "not-implied" }
  }),
  {
    id: "unfamiliar-unrepresentable",
    payload: {
      schemaVersion: 1, vocabularyVersion: STRUCTURAL_VERSION, outcome: "unrepresentable",
      sourceNodeIds: ["unfamiliar:observation"],
      context: { scope: "Synthetic unfamiliar symbol record", scale: "one uninterpreted token stream", conditions: "no mapping or criterion supplied", referenceFrame: "verbatim token positions only" },
      structures: [],
      limits: ["The vocabulary has no justified interpretation of these fictional symbols under the supplied context."],
      counterexamples: ["A subsequently supplied decoding rule could permit a separately attributed interpretation."],
      unrepresentableReason: "No stated criterion connects the unfamiliar token stream to a candidate structural description."
    }
  }
];
