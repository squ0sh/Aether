import assert from "node:assert/strict";
import test from "node:test";
import { STRUCTURAL_TERMS, StructuralValidationError, validateStructuralInterpretation } from "../src/core/structural-vocabulary.js";
import { structuralCases } from "./fixtures/structural-cases.js";

const copy = (value) => JSON.parse(JSON.stringify(value));
const fixture = (id) => copy(structuralCases.find((item) => item.id === id).payload);
const record = (payload, term) => payload.structures.find((item) => item.term === term);
const reject = (payload) => assert.throws(() => validateStructuralInterpretation(payload), (error) => error instanceof StructuralValidationError && error.code === "INVALID_STRUCTURE");

const checks = {
  thermostat(p) {
    assert.deepEqual(record(p, "feedback").attributes.path, ["temperature sensor", "heater relay", "room", "next sensor reading"]);
    assert.equal(record(p, "feedback").attributes.mechanismStatus, "hypothesized");
  },
  "cell-membrane"(p) {
    assert.match(record(p, "boundary").attributes.restrictedTransitions, /membrane selectivity/);
    assert.deepEqual(record(p, "absence").attributes, { status: "not-observed", method: null, coverage: null });
  },
  "recursive-program"(p) {
    assert.match(record(p, "recursion").attributes.outputToInput, /accumulator argument of the same function/);
    assert.deepEqual(record(p, "equivalence").attributes.retainedDifferences, ["argument values", "remaining list length"]);
  },
  pendulum(p) {
    const invariant = record(p, "invariant").attributes;
    assert.equal(invariant.property, "total modeled mechanical energy");
    assert.match(invariant.context, /ideal pendulum without energy exchange/);
    assert.match(p.counterexamples[0], /damping/);
  },
  ecosystem(p) {
    assert.deepEqual(record(p, "network").attributes.omittedMechanisms, ["interaction strengths", "seasonal external drivers"]);
    assert.match(record(p, "hierarchy").attributes.orderingCriterion, /not a ranking of importance/);
  },
  market(p) {
    assert.equal(record(p, "informational-gravity").attributes.epistemicSupport, "not-implied");
    assert.equal(record(p, "informational-gravity").attributes.status, "experimental");
    assert.match(record(p, "attractor").attributes.dynamics, /toy reallocation/);
  },
  "human-conversation"(p) {
    assert.deepEqual(record(p, "agentive-structure").attributes.goals, ["resolve the stated ambiguity"]);
    assert.equal(record(p, "agentive-structure").attributes.agencyStatus, "interpretation-not-personhood");
  },
  "neural-circuit"(p) {
    assert.equal(record(p, "magnitude").attributes.unitOrScale, "millivolts");
    assert.equal(record(p, "polarity").attributes.baseline, "declared zero-voltage reference");
    assert.equal(record(p, "order").attributes.causality, "not-implied");
  },
  orbit(p) {
    assert.equal(record(p, "cycle").attributes.returnCriterion, "equal modeled position modulo one full revolution");
    assert.match(record(p, "symmetry").attributes.transformation, /rotation of coordinate axes/);
  },
  "copied-source-misinformation"(p) {
    const independence = record(p, "independence").attributes;
    assert.equal(independence.lineages.length, 3);
    assert.equal(new Set(independence.lineages.map((item) => item.originId)).size, 1);
    assert.equal(independence.assessment, "shared-origin");
  },
  "hidden-common-cause"(p) {
    assert.deepEqual(record(p, "causality").attributes, { status: "hypothesis", basis: "association", alternativeExplanations: ["hidden common power fluctuation", "coincidental overlap"] });
  },
  "same-endpoint-different-histories"(p) {
    const paths = record(p, "path-dependence").attributes;
    assert.deepEqual(paths.histories, ["ten to fifteen to ten", "ten to eight to ten"]);
    assert.equal(paths.historyEquivalence, "different-under-criterion");
    assert.notEqual(paths.endpointCriterion, paths.historyCriterion);
  },
  "same-topology-different-mechanisms"(p) {
    const analogy = record(p, "analogy").attributes;
    assert.equal(analogy.mechanismEquivalence, "not-implied");
    assert.ok(analogy.retainedDifferences.includes("fluid transport versus discrete messages"));
  },
  "unfamiliar-unrepresentable"(p) {
    assert.equal(p.outcome, "unrepresentable");
    assert.deepEqual(p.structures, []);
    assert.match(p.unrepresentableReason, /No stated criterion/);
  }
};

for (const { id, payload } of structuralCases) {
  test(`synthetic ${id} preserves its stated distinction, limits, and uncertainty`, () => {
    const before = JSON.stringify(payload);
    const output = validateStructuralInterpretation(payload);
    checks[id](output);
    assert.deepEqual(output, payload);
    assert.notEqual(output, payload);
    assert.equal(JSON.stringify(payload), before);
    assert.ok(output.limits[0].length > 30 && output.counterexamples[0].length > 30);
    assert.ok(Object.isFrozen(output.structures) && Object.isFrozen(output.context));
    assert.deepEqual(validateStructuralInterpretation(copy(output)), output);
  });
}

const adversaries = [
  ["thermostat", "does not promote a described feedback mechanism to verified", (p) => { record(p, "feedback").attributes.mechanismStatus = "verified"; }],
  ["cell-membrane", "does not turn non-detection into observed absence without method and coverage", (p) => { record(p, "absence").attributes.status = "observed-absent"; }],
  ["recursive-program", "requires a recurrence criterion", (p) => { record(p, "recursion").attributes.recurrenceCriterion = "unknown"; }],
  ["pendulum", "requires the invariant's transformation scope", (p) => { delete record(p, "invariant").attributes.transformation; }],
  ["ecosystem", "retains omitted mechanisms instead of treating topology as complete", (p) => { record(p, "network").attributes.omittedMechanisms = []; }],
  ["market", "does not make attention epistemic support", (p) => { record(p, "informational-gravity").attributes.epistemicSupport = "proven-by-popularity"; }],
  ["human-conversation", "does not infer personhood from a selection rule", (p) => { record(p, "agentive-structure").attributes.agencyStatus = "personhood-proven"; }],
  ["neural-circuit", "does not make ordered traces causal proof", (p) => { record(p, "order").attributes.causality = "established"; }],
  ["orbit", "requires a symmetry equivalence criterion", (p) => { record(p, "symmetry").attributes.criterion = ""; }],
  ["copied-source-misinformation", "does not relabel copies as distinct declared origins", (p) => { record(p, "independence").attributes.assessment = "distinct-declared-origins"; }],
  ["hidden-common-cause", "does not promote association to established cause", (p) => { record(p, "causality").attributes.status = "established"; }],
  ["same-endpoint-different-histories", "does not infer equal histories from equal endpoints", (p) => { record(p, "path-dependence").attributes.historyEquivalence = "same-because-endpoint-matches"; }],
  ["same-topology-different-mechanisms", "does not infer identical mechanism from analogy", (p) => { record(p, "analogy").attributes.mechanismEquivalence = "implied"; }],
  ["unfamiliar-unrepresentable", "does not repair a vocabulary failure with a guessed primitive", (p) => { p.structures = [copy(record(fixture("thermostat"), "relation"))]; }]
];

for (const [id, description, mutate] of adversaries) {
  test(`synthetic ${id} ${description}`, () => {
    const input = fixture(id); mutate(input);
    const before = JSON.stringify(input);
    reject(input);
    assert.equal(JSON.stringify(input), before);
  });
}

test("the authored domains exercise every candidate and derived recipe", () => {
  const exercised = new Set(structuralCases.flatMap(({ payload }) => payload.structures.map((item) => item.term)));
  assert.deepEqual([...exercised].sort(), Object.keys(STRUCTURAL_TERMS).sort());
  assert.equal(structuralCases.length, 14);
});

test("every invariant obligation is explicit, not an unknown placeholder", () => {
  for (const key of ["property", "transformation", "context", "scale", "criterion"]) {
    const missing = fixture("pendulum"); delete record(missing, "invariant").attributes[key]; reject(missing);
    const unknown = fixture("pendulum"); record(unknown, "invariant").attributes[key] = "unknown"; reject(unknown);
  }
});

test("declared distinct origins and unknown origins remain different from proven independence", () => {
  const distinct = fixture("copied-source-misinformation");
  const attributes = record(distinct, "independence").attributes;
  attributes.lineages.forEach((item, index) => { item.originId = `declared-origin-${index}`; });
  attributes.assessment = "distinct-declared-origins";
  assert.equal(record(validateStructuralInterpretation(distinct), "independence").attributes.assessment, "distinct-declared-origins");
  attributes.assessment = "independence-proven"; reject(distinct);
  attributes.lineages[1].originId = null;
  attributes.assessment = "unknown";
  assert.equal(record(validateStructuralInterpretation(distinct), "independence").attributes.assessment, "unknown");
  attributes.assessment = "distinct-declared-origins"; reject(distinct);
});

test("a bounded absence record can state its method and coverage without claiming universal absence", () => {
  const input = fixture("cell-membrane");
  const absence = record(input, "absence").attributes;
  absence.status = "observed-absent";
  absence.method = "fictional tracer assay at the stated detection threshold";
  absence.coverage = "the sampled compartment during the single stated interval only";
  assert.deepEqual(record(validateStructuralInterpretation(input), "absence").attributes, absence);
  absence.coverage = "unknown"; reject(input);
});

test("synthetic causal hypotheses retain alternatives even when an intervention is declared", () => {
  const input = fixture("hidden-common-cause");
  const cause = record(input, "causality").attributes;
  cause.basis = "intervention";
  assert.equal(record(validateStructuralInterpretation(input), "causality").attributes.status, "hypothesis");
  cause.alternativeExplanations = []; reject(input);
});
