import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { LocalFieldStore } from "./field-store.js";
import { LinkedDeletionCoordinator } from "./linked-deletion.js";
import { createConversationField, assertConversationField } from "./conversation-field.js";
import { createProvenance } from "./field.js";
import { captureCompletedTurn } from "./field-capture.js";
import { getConversation, deleteConversation } from "./conversations.js";
import { getExecution } from "./executions.js";

const fail = (message) => { throw Object.assign(new Error(message), { code: "LIVE_FIELD_CONFLICT", statusCode: 409 }); };
export class LiveField {
  constructor({ dataRoot = process.env.AETHER_DATA_DIR || join(process.cwd(), "data"), fieldStore } = {}) {
    this.conversationRoot = join(dataRoot, "conversations");
    this.executionRoot = join(dataRoot, "executions");
    this.store = fieldStore || new LocalFieldStore({ root: join(dataRoot, "fields") });
    this.coordinator = new LinkedDeletionCoordinator({ root: join(dataRoot, "linked-deletions"), conversationRoot: this.conversationRoot, fieldStore: this.store });
  }
  fieldId(conversationId) { return `aether:conversation:${conversationId}`; }
  async status(conversationId) {
    const deletion = await this.coordinator.status(conversationId);
    if (deletion) return { enabled: true, deletion: deletion.phase };
    const saved = await this.store.load(this.fieldId(conversationId));
    if (saved) assertConversationField(saved.snapshot, conversationId);
    return { enabled: !!saved, fieldId: saved ? saved.snapshot.id : null };
  }
  async enable(conversationId, permission) {
    if (permission !== true) fail("Explicit permission is required to capture future messages and delete this dedicated Field with the conversation");
    return this.coordinator.withActiveConversation(conversationId, async () => {
      await getConversation(conversationId, this.conversationRoot);
      // Check privacy readiness before reserving a Field; existing permissions
      // are not silently changed. Review performs the same check at deletion.
      const { lstat } = await import("node:fs/promises");
      const stat = await lstat(this.conversationRoot);
      if (!stat.isDirectory() || stat.isSymbolicLink() || (process.platform !== "win32" && (stat.mode & 0o077))) fail("Conversation directory must be owner-private (0700) before enabling capture");
      const fieldId = this.fieldId(conversationId);
      const saved = await this.store.load(fieldId, { confirmDurability: true });
      if (saved) { assertConversationField(saved.snapshot, conversationId); return { enabled: true, fieldId }; }
      const snapshot = createConversationField({ id: fieldId, initialStateId: `${fieldId}:root`, createdAt: new Date().toISOString(),
        provenance: createProvenance({ sourceType: "human", sourceId: "local-owner", conversationId, method: "explicit opt-in to future capture and dedicated retention" }),
        conversationId, permission: true });
      await this.store.save(snapshot, { requestId: `reserve:${conversationId}` });
      return { enabled: true, fieldId };
    });
  }
  // Called while the coordinator guard is held by chat or retryCapture.
  async capture(conversationId, execution) {
    const saved = await this.store.load(this.fieldId(conversationId), { confirmDurability: true });
    if (!saved) return { enabled: false };
    assertConversationField(saved.snapshot, conversationId);
    if (execution.outcome !== "success" || execution.conversationId !== conversationId || !execution.userMessageId || !execution.assistantMessageId) fail("Capture requires a successful, message-linked execution");
    const reservedAt = saved.snapshot.states.find((state) => state.parentStateIds.length === 0).createdAt;
    if (!Number.isFinite(Date.parse(execution.startedAt)) || Date.parse(execution.startedAt) < Date.parse(reservedAt)) fail("Execution predates capture opt-in; old history is not imported");
    const conversation = await getConversation(conversationId, this.conversationRoot);
    const human = conversation.messages.find((item) => item.id === execution.userMessageId);
    const model = conversation.messages.find((item) => item.id === execution.assistantMessageId);
    if (human?.role !== "user" || model?.role !== "assistant") fail("Capture source messages are missing or mismatched");
    const stateId = `capture:${execution.id}`;
    if (saved.snapshot.states.some((state) => state.id === stateId)) {
      for (const message of [human, model]) {
        const node = saved.snapshot.nodes.find((node) => node.id === `message:${message.id}`);
        if (node?.content.text !== message.content || node?.provenance.messageId !== message.id || node?.provenance.conversationId !== conversationId) fail("Existing capture differs from its source");
      }
      return { enabled: true, captured: true, replayed: true, fieldId: saved.snapshot.id };
    }
    if (saved.headStateIds.length !== 1) fail("Dedicated Field has multiple heads; explicit integration is required before capture");
    const proposal = captureCompletedTurn(saved.snapshot, { parentStateId: saved.headStateIds[0], stateId, createdAt: execution.completedAt,
      conversationId, executionId: execution.id, completed: true, edgeId: `response:${execution.id}`,
      human: { nodeId: `message:${human.id}`, messageId: human.id, sourceId: "local-owner", occurredAt: human.createdAt, text: human.content },
      model: { nodeId: `message:${model.id}`, messageId: model.id, sourceId: execution.providerId, providerId: execution.providerId,
        modelId: execution.modelId, occurredAt: model.createdAt, text: model.content } });
    await this.store.save(proposal, { requestId: stateId });
    return { enabled: true, captured: true, replayed: false, fieldId: saved.snapshot.id };
  }
  async retryCapture(conversationId, executionId) {
    return this.coordinator.withActiveConversation(conversationId, async () => this.capture(conversationId, await getExecution(executionId, this.executionRoot)));
  }
  async deletionReview(conversationId) {
    const journal = await this.coordinator.status(conversationId);
    if (journal) return { linked: true, phase: journal.phase, command: journal.command, warning: "Resume deletion of this conversation and all content in its dedicated Field." };
    const saved = await this.store.load(this.fieldId(conversationId));
    if (!saved) { await getConversation(conversationId, this.conversationRoot); return { linked: false }; }
    const review = await this.coordinator.review(conversationId, saved.snapshot.id);
    return { linked: true, warning: review.warning, nodeCount: review.nodeCount, command: { conversationId, fieldId: saved.snapshot.id,
      requestId: randomUUID(), expectedRevision: review.expectedRevision, conversationDigest: review.conversationDigest } };
  }
  async remove(conversationId, input = {}) {
    if (input.command) {
      if (input.command.conversationId !== conversationId || input.command.fieldId !== this.fieldId(conversationId)) fail("Deletion scope does not match this conversation");
      return this.coordinator.deleteLinked(input.command, { permission: input.permission });
    }
    return this.coordinator.withActiveConversation(conversationId, async () => {
      if (await this.store.load(this.fieldId(conversationId))) fail("Review and explicitly confirm linked deletion before deleting this conversation");
      await deleteConversation(conversationId, this.conversationRoot);
      return { deleted: true };
    });
  }
}
