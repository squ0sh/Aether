import { createField, FieldChangeError } from "./field-operations.js";
import { validateFieldJson, validateFieldSnapshot } from "./field.js";

export const CONVERSATION_SCOPE = "aether:conversation-scope";

// A dedicated Field is an explicit retention boundary, not inferred from text.
export function createConversationField(input) {
  const command = validateFieldJson(input);
  if (!command || typeof command !== "object" || Array.isArray(command) ||
      Object.keys(command).length !== 6 ||
      ["id", "initialStateId", "createdAt", "provenance", "conversationId", "permission"].some((key) => !Object.hasOwn(command, key))) {
    throw new FieldChangeError("Expected Field identity, time, provenance, conversationId, and permission");
  }
  if (command.permission !== true) throw new FieldChangeError("Explicit permission is required for a conversation-dedicated Field");
  if (typeof command.conversationId !== "string" || !command.conversationId.trim()) throw new FieldChangeError("A conversation ID is required");
  const { conversationId, permission, ...base } = command;
  const snapshot = createField({ ...base, extensions: { [CONVERSATION_SCOPE]: { version: 1, conversationId, retention: "delete-with-conversation" } } });
  assertConversationField(snapshot, conversationId);
  return snapshot;
}

export function assertConversationField(input, conversationId) {
  if (typeof conversationId !== "string" || !conversationId.trim()) throw new FieldChangeError("A conversation ID is required");
  const snapshot = validateFieldSnapshot(input);
  const scope = snapshot.extensions[CONVERSATION_SCOPE];
  if (!scope || typeof scope !== "object" || Array.isArray(scope) || Object.keys(scope).length !== 3 ||
      scope.version !== 1 || scope.conversationId !== conversationId || scope.retention !== "delete-with-conversation") {
    throw new FieldChangeError("Field is not explicitly dedicated to this conversation");
  }
  if ([...snapshot.nodes, ...snapshot.edges, ...snapshot.states].some((record) =>
    record.provenance.conversationId !== null && record.provenance.conversationId !== conversationId)) {
    throw new FieldChangeError("Field includes another conversation; scoped deletion is refused");
  }
  return snapshot;
}

export function reviewConversationFieldDeletion(saved, conversationId) {
  if (!saved || !Number.isSafeInteger(saved.revision) || saved.revision < 1) throw new FieldChangeError("Review requires a saved Field revision");
  const snapshot = assertConversationField(saved.snapshot, conversationId);
  return Object.freeze({ fieldId: snapshot.id, conversationId, expectedRevision: saved.revision,
    scope: "entire-dedicated-field", nodeCount: snapshot.nodes.length, edgeCount: snapshot.edges.length,
    stateCount: snapshot.states.length,
    warning: "Deletes all captured text, interpretations, and branches in this dedicated Field. Other stores, exports, backups, and the conversation itself are not deleted by this operation." });
}
