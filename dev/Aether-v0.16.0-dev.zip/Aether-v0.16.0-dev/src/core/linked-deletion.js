import * as fs from "node:fs/promises";
import { constants } from "node:fs";
import { createHash, randomUUID } from "node:crypto";
import { join, resolve } from "node:path";
import { getConversation } from "./conversations.js";
import { reviewConversationFieldDeletion } from "./conversation-field.js";
import { validateFieldJson } from "./field.js";

const canonical = (value) => value === null || typeof value !== "object" ? JSON.stringify(value)
  : Array.isArray(value) ? `[${value.map(canonical).join(",")}]`
    : `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
const hash = (value) => createHash("sha256").update(canonical(value)).digest("hex");
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const fail = (code, message) => { throw Object.assign(new Error(message), { code }); };
const id = (value) => { if (typeof value !== "string" || !value.trim()) fail("LINK_INVALID", "Nonempty IDs are required"); };
const sameKeys = (value, keys) => value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));

// Local coordinator only. All cooperating capture/conversation writers must use
// withActiveConversation; the existing HTTP routes are deliberately not wired in.
export class LinkedDeletionCoordinator {
  constructor({ root, conversationRoot, fieldStore, fileSystem = fs }) {
    if (!root || !conversationRoot || !fieldStore) throw new TypeError("Explicit coordinator root, conversation root, and Field store required");
    this.root = resolve(root);
    this.conversationRoot = resolve(conversationRoot);
    if (this.root === this.conversationRoot || this.root === fieldStore.root) throw new TypeError("Coordinator needs a separate directory");
    this.fieldStore = fieldStore;
    this.io = fileSystem;
  }

  #paths(conversationId) {
    if (!uuid.test(conversationId || "")) fail("LINK_INVALID", "A valid conversation UUID is required");
    const key = hash(conversationId);
    return { key, journal: join(this.root, `${key}.json`), lock: join(this.root, `${key}.lock`) };
  }

  async #privateDirectory(path, create = false) {
    if (create) await this.io.mkdir(path, { recursive: true, mode: 0o700 });
    const stat = await this.io.lstat(path);
    if (!stat.isDirectory() || stat.isSymbolicLink() || (process.platform !== "win32" && (stat.mode & 0o077))) fail("LINK_UNSAFE_PATH", "Coordinator directories must be real and owner-private (0700)");
  }

  async #sync(path) {
    if (process.platform === "win32") return;
    const handle = await this.io.open(path, constants.O_RDONLY);
    try { await handle.sync(); } finally { await handle.close(); }
  }

  async #read(conversationId) {
    const { journal } = this.#paths(conversationId);
    let handle;
    try {
      const stat = await this.io.lstat(journal);
      if (!stat.isFile() || stat.isSymbolicLink()) fail("LINK_UNSAFE_PATH", "Journal must be a regular private file");
      handle = await this.io.open(journal, constants.O_RDONLY | (constants.O_NOFOLLOW || 0));
      const opened = await handle.stat();
      if (opened.size > 65536 || (process.platform !== "win32" && (opened.mode & 0o077))) fail("LINK_UNSAFE_PATH", "Journal exceeds size or permission limits");
      const text = await handle.readFile("utf8");
      let record;
      try { record = JSON.parse(text); } catch { fail("LINK_CORRUPT", "Invalid deletion journal; recovery must be reviewed"); }
      const payload = record?.payload;
      if (!sameKeys(record, ["payload", "checksum"]) || !sameKeys(payload, ["version", "command", "phase"]) ||
          hash(payload) !== record.checksum || payload.version !== 1 ||
          !["pending", "field-deleted", "complete"].includes(payload.phase)) fail("LINK_CORRUPT", "Invalid deletion journal; no automatic reset");
      try { this.#command(payload.command); }
      catch { fail("LINK_CORRUPT", "Invalid command in deletion journal"); }
      if (payload.command.conversationId !== conversationId) fail("LINK_CORRUPT", "Journal conversation mismatch");
      return payload;
    } catch (error) { if (error.code === "ENOENT") return null; throw error; }
    finally { await handle?.close(); }
  }

  #command(input) {
    const value = validateFieldJson(input);
    if (!sameKeys(value, ["conversationId", "fieldId", "requestId", "expectedRevision", "conversationDigest"])) fail("LINK_INVALID", "Invalid deletion command");
    this.#paths(value.conversationId); id(value.fieldId); id(value.requestId);
    if (!Number.isSafeInteger(value.expectedRevision) || value.expectedRevision < 1 || value.expectedRevision >= Number.MAX_SAFE_INTEGER ||
        !/^[0-9a-f]{64}$/.test(value.conversationDigest)) fail("LINK_INVALID", "Reviewed revision and conversation digest required");
    return value;
  }

  async #publish(payload) {
    const { journal, key } = this.#paths(payload.command.conversationId);
    const temporary = join(this.root, `.${key}.${randomUUID()}.incoming`);
    let handle;
    try {
      const encoded = JSON.stringify({ payload, checksum: hash(payload) }) + "\n";
      if (Buffer.byteLength(encoded) > 65536) fail("LINK_INVALID", "Deletion command is too large");
      handle = await this.io.open(temporary, "wx", 0o600);
      await handle.writeFile(encoded); await handle.sync(); await handle.close(); handle = null;
      await this.io.rename(temporary, journal);
      await this.#sync(this.root);
    } finally { await handle?.close(); await this.io.rm(temporary, { force: true }); }
  }

  async #locked(conversationId, callback) {
    const { lock } = this.#paths(conversationId);
    await this.#privateDirectory(this.root, true);
    let handle;
    try { handle = await this.io.open(lock, "wx", 0o600); }
    catch (error) { if (error.code === "EEXIST") fail("LINK_LOCKED", "Conversation is owned by another or interrupted operation; no lock was stolen"); throw error; }
    try { return await callback(); }
    finally { await handle.close(); await this.io.unlink(lock); }
  }

  async withActiveConversation(conversationId, callback) {
    return this.#locked(conversationId, async () => {
      if (await this.#read(conversationId)) fail("LINK_DELETING", "Deletion has begun; new capture and conversation writes are blocked");
      return callback();
    });
  }

  async review(conversationId, fieldId) {
    return this.withActiveConversation(conversationId, async () => {
      await this.#privateDirectory(this.conversationRoot);
      const conversation = await this.#conversation(conversationId);
      const review = reviewConversationFieldDeletion(await this.fieldStore.load(fieldId), conversationId);
      return Object.freeze({ ...review, conversationDigest: hash(conversation),
        warning: "Deletes this conversation and all content in its dedicated Field. External copies and backups are excluded." });
    });
  }

  async status(conversationId) {
    return this.#locked(conversationId, async () => {
      const journal = await this.#read(conversationId);
      return journal ? validateFieldJson(journal) : null;
    });
  }

  async #conversation(conversationId) {
    const stat = await this.io.lstat(join(this.conversationRoot, `${conversationId}.json`));
    if (!stat.isFile() || stat.isSymbolicLink() || (process.platform !== "win32" && (stat.mode & 0o077))) fail("LINK_UNSAFE_PATH", "Conversation must be a regular owner-private file");
    return getConversation(conversationId, this.conversationRoot);
  }

  async #removeConversation(command) {
    await this.#privateDirectory(this.conversationRoot);
    const path = join(this.conversationRoot, `${command.conversationId}.json`);
    try {
      const stat = await this.io.lstat(path);
      if (!stat.isFile() || stat.isSymbolicLink()) fail("LINK_UNSAFE_PATH", "Conversation must be a regular file");
      const conversation = await this.#conversation(command.conversationId);
      if (hash(conversation) !== command.conversationDigest) fail("LINK_CONFLICT", "Conversation changed since review; refusing to erase unreviewed content");
      await this.io.unlink(path);
    } catch (error) { if (error.code !== "ENOENT" && error.statusCode !== 404) throw error; }
    const pattern = new RegExp(`^${command.conversationId}\\.json\\.incoming-[0-9]+$`);
    for (const name of await this.io.readdir(this.conversationRoot)) {
      if (!pattern.test(name)) continue;
      const staging = join(this.conversationRoot, name);
      const stat = await this.io.lstat(staging);
      if (!stat.isFile() || stat.isSymbolicLink()) fail("LINK_UNSAFE_PATH", "Conversation staging must be regular");
      await this.io.unlink(staging);
    }
    await this.#sync(this.conversationRoot);
  }

  async deleteLinked(input, { permission } = {}) {
    if (permission !== true) fail("LINK_PERMISSION_REQUIRED", "Explicit permission to delete both the conversation and its dedicated Field is required");
    const command = this.#command(input);
    return this.#locked(command.conversationId, async () => {
      let journal = await this.#read(command.conversationId);
      if (journal && hash(journal.command) !== hash(command)) fail("LINK_CONFLICT", "Retry the original deletion command; scope cannot be changed");
      try {
        if (!journal) {
          await this.#privateDirectory(this.conversationRoot);
          const conversation = await this.#conversation(command.conversationId);
          if (hash(conversation) !== command.conversationDigest) fail("LINK_CONFLICT", "Conversation changed since review");
          const review = reviewConversationFieldDeletion(await this.fieldStore.load(command.fieldId), command.conversationId);
          if (review.expectedRevision !== command.expectedRevision) fail("LINK_CONFLICT", "Field changed since review");
          journal = { version: 1, command, phase: "pending" };
          await this.#publish(journal);
        }
        // Retry the intent durability barrier before any destructive action.
        await this.#sync(this.root);
        await this.fieldStore.deleteConversationField(command.fieldId, { conversationId: command.conversationId,
          requestId: command.requestId, expectedRevision: command.expectedRevision, permission: true });
        if (journal.phase === "pending") {
          journal = { ...journal, phase: "field-deleted" };
          await this.#publish(journal);
        }
        await this.#removeConversation(command);
        const replayed = journal.phase === "complete";
        await this.#publish({ ...journal, phase: "complete" });
        return Object.freeze({ conversationId: command.conversationId, fieldId: command.fieldId, deleted: true, replayed });
      } catch (error) {
        if (journal) throw Object.assign(new Error("Linked deletion is incomplete or uncertain. Check status and retry the original command; a published intent blocks coordinated writes.", { cause: error }), { code: "LINK_DELETE_UNCERTAIN" });
        throw error;
      }
    });
  }
}
