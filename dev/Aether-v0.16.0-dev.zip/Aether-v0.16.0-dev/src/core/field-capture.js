import { createProvenance, validateFieldJson, validateFieldSnapshot } from "./field.js";
import { applyFieldChange, FieldChangeError } from "./field-operations.js";
import { CONVERSATION_SCOPE, assertConversationField } from "./conversation-field.js";

function shape(value, keys) {
  if (!value || typeof value !== "object" || Array.isArray(value) ||
      Object.keys(value).length !== keys.length || keys.some((key) => !Object.hasOwn(value, key))) {
    throw new FieldChangeError(`Expected capture fields: ${keys.join(", ")}`);
  }
}
function id(value) {
  if (typeof value !== "string" || !value.trim()) throw new FieldChangeError("Capture requires nonempty source IDs");
}
function timestamp(value) {
  if (typeof value !== "string" || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value) {
    throw new FieldChangeError("Capture requires canonical event timestamps");
  }
}

// Raw capture is an explicit proposal, never inference, classification, or I/O.
// Callers must supply actual source IDs, not fabricate missing execution linkage.
export function captureCompletedTurn(input, change) {
  const snapshot = validateFieldSnapshot(input);
  const command = validateFieldJson(change);
  shape(command, ["parentStateId", "stateId", "createdAt", "conversationId", "executionId", "completed", "human", "model", "edgeId"]);
  if (command.completed !== true) throw new FieldChangeError("Only completed turns may be captured");
  id(command.conversationId);
  id(command.executionId);
  if (Object.hasOwn(snapshot.extensions, CONVERSATION_SCOPE)) assertConversationField(snapshot, command.conversationId);
  shape(command.human, ["nodeId", "messageId", "sourceId", "occurredAt", "text"]);
  shape(command.model, ["nodeId", "messageId", "sourceId", "occurredAt", "text", "providerId", "modelId"]);
  if (command.human.messageId === command.model.messageId) throw new FieldChangeError("Human and model messages need distinct IDs");
  for (const event of [command.human, command.model]) {
    id(event.messageId);
    id(event.sourceId);
    timestamp(event.occurredAt);
    if (snapshot.nodes.some((node) => node.extensions["aether:capture"] &&
        node.provenance.conversationId === command.conversationId && node.provenance.messageId === event.messageId)) {
      throw new FieldChangeError("Message already captured; retry the prepared snapshot through storage, not a new capture");
    }
  }
  const recorder = createProvenance({ sourceType: "system", sourceId: "aether:chat-capture", conversationId: command.conversationId,
    executionId: command.executionId, method: "explicit completed-turn capture; not semantic interpretation" });
  const observation = (event, role) => ({ type: "add-node", record: {
    id: event.nodeId, kind: "observation", content: { format: "text/plain", text: event.text },
    provenance: createProvenance({ sourceType: role, sourceId: event.sourceId, conversationId: command.conversationId,
      messageId: event.messageId, executionId: role === "model" ? command.executionId : null,
      providerId: role === "model" ? event.providerId : null, modelId: role === "model" ? event.modelId : null,
      method: "verbatim message capture; not verification of its claims" }),
    extensions: { "aether:capture": { version: 1, role, occurredAt: event.occurredAt } }
  } });
  return applyFieldChange(snapshot, {
    parentStateId: command.parentStateId, stateId: command.stateId, createdAt: command.createdAt, provenance: recorder,
    actions: [observation(command.human, "human"), observation(command.model, "model"),
      { type: "add-edge", record: { id: command.edgeId, from: command.model.nodeId, to: command.human.nodeId, relation: "responds_to",
        context: "Response linkage supplied by the caller; not support or agreement." } }]
  });
}
