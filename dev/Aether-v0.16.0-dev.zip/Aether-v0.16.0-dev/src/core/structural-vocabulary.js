import { validateFieldJson } from "./field.js";

export const STRUCTURAL_VERSION = "aether-structural-v0.1";
export const STRUCTURAL_EXTENSION = "aether:structural";
const recipe = (layer, requires, attributes) => ({ layer, requires, attributes });
// Executable candidate recipes. Attribute types encode representational obligations,
// not evidence that a user's description or mechanism is factually correct.
export const STRUCTURAL_TERMS = validateFieldJson({
  distinction: recipe("candidate", [], { criterion: "defined", entities: "pair" }),
  relation: recipe("candidate", [], { aspect: "text", entities: "pair" }),
  reference: recipe("candidate", [], { frame: "text", baseline: "text", dimension: "text" }),
  possibility: recipe("candidate", [], { alternatives: "pair", modality: ["considered"] }),
  constraint: recipe("candidate", [], { restriction: "text", appliesTo: "list" }),
  magnitude: recipe("candidate", [], { quantity: "text", unitOrScale: "text", reference: "text" }),
  order: recipe("candidate", [], { basis: "text", sequence: "sequence", causality: ["not-implied"] }),
  equivalence: recipe("candidate", [], { criterion: "defined", retainedDifferences: "list" }),
  context: recipe("candidate", [], { scope: "text", scale: "text", conditions: "text" }),
  gradient: recipe("derived", ["magnitude", "order", "reference"], { variation: "text", dimension: "text" }),
  polarity: recipe("derived", ["distinction", "order", "reference"], { directions: "pair", baseline: "text" }),
  change: recipe("derived", ["distinction", "order", "reference"], { configurations: "pair" }),
  transformation: recipe("derived", ["relation", "change"], { mapping: "text", retainedHistory: "text" }),
  boundary: recipe("derived", ["distinction", "constraint", "relation"], { restrictedTransitions: "text" }),
  feedback: recipe("derived", ["relation", "order", "transformation"], { path: "sequence", returnInfluence: "text", mechanismStatus: ["hypothesized", "described-not-verified"] }),
  recursion: recipe("derived", ["transformation", "equivalence", "order"], { outputToInput: "text", recurrenceCriterion: "defined" }),
  symmetry: recipe("derived", ["transformation", "equivalence", "context"], { transformation: "defined", criterion: "defined", scope: "defined" }),
  invariant: recipe("derived", ["transformation", "equivalence", "context"], { property: "defined", transformation: "defined", context: "defined", scale: "defined", criterion: "defined" }),
  attractor: recipe("derived", ["transformation", "order", "magnitude", "context"], { dynamics: "defined", trajectories: "pair", convergence: "text" }),
  independence: recipe("derived", ["distinction", "reference", "relation"], { lineages: "lineages", assessment: ["unknown", "shared-origin", "distinct-declared-origins"] }),
  causality: recipe("derived", ["relation", "order", "constraint", "context"], { status: ["hypothesis"], basis: ["association", "temporal-order", "intervention", "mechanistic-test"], alternativeExplanations: "list" }),
  hierarchy: recipe("derived", ["relation", "order", "context"], { levels: "pair", orderingCriterion: "defined" }),
  network: recipe("derived", ["distinction", "relation", "context"], { topology: "text", omittedMechanisms: "list" }),
  cycle: recipe("derived", ["relation", "order", "equivalence"], { path: "sequence", returnCriterion: "defined" }),
  "path-dependence": recipe("derived", ["transformation", "order", "equivalence", "context"], { histories: "pair", endpointCriterion: "defined", historyCriterion: "defined", historyEquivalence: ["not-inferred", "different-under-criterion"] }),
  "agentive-structure": recipe("derived", ["possibility", "constraint", "feedback", "context"], { selectionRule: "text", goals: "list", agencyStatus: ["interpretation-not-personhood"] }),
  "informational-gravity": recipe("derived", ["attractor", "reference", "context"], { measure: "text", epistemicSupport: ["not-implied"], status: ["experimental"] }),
  analogy: recipe("derived", ["equivalence", "distinction", "relation", "context"], { criterion: "defined", retainedDifferences: "list", mechanismEquivalence: ["not-implied"] }),
  absence: recipe("derived", ["distinction", "reference", "context"], { status: ["not-observed", "observed-absent"], method: "nullable", coverage: "nullable" })
});

export class StructuralValidationError extends Error {
  constructor(path, message) { super(`${path}: ${message}`); this.name = "StructuralValidationError"; this.code = "INVALID_STRUCTURE"; this.path = path; }
}
export const structuralCheck = (condition, path, message) => { if (!condition) throw new StructuralValidationError(path, message); };
export function structuralShape(value, keys, path) {
  structuralCheck(value && typeof value === "object" && !Array.isArray(value), path, "expected an object");
  structuralCheck(Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), path, `expected fields: ${keys.join(", ")}`);
}
function text(value, path, defined = false) {
  structuralCheck(typeof value === "string" && value.trim().length > 0, path, "nonempty text required");
  if (defined) structuralCheck(!/^(unknown|unspecified|n\/a)$/i.test(value.trim()), path, "explicit criterion required; otherwise record unrepresentable");
}
function list(value, path, minimum = 1, unique = true) {
  structuralCheck(Array.isArray(value) && value.length >= minimum, path, `at least ${minimum} entries required`);
  value.forEach((entry, index) => text(entry, `${path}[${index}]`));
  if (unique) structuralCheck(new Set(value).size === value.length, path, "duplicate entries");
}
function attribute(value, type, path, sources) {
  if (Array.isArray(type)) return structuralCheck(type.includes(value), path, `expected one of: ${type.join(", ")}`);
  if (type === "nullable") { if (value !== null) text(value, path); return; }
  if (type === "sequence") return list(value, path, 2, false);
  if (type === "list" || type === "pair") return list(value, path, type === "pair" ? 2 : 1);
  if (type === "lineages") {
    structuralCheck(Array.isArray(value) && value.length > 0, path, "source lineages required");
    const seen = new Set();
    value.forEach((entry, index) => {
      structuralShape(entry, ["observationId", "originId"], `${path}[${index}]`);
      structuralCheck(sources.includes(entry.observationId) && !seen.has(entry.observationId), path, "lineage must name a unique declared source observation");
      seen.add(entry.observationId);
      if (entry.originId !== null) text(entry.originId, path);
    });
    structuralCheck(seen.size === sources.length, path, "lineages must cover every source observation");
    return;
  }
  text(value, path, type === "defined");
}

export function validateStructuralInterpretation(input) {
  const value = validateFieldJson(input);
  structuralShape(value, ["schemaVersion", "vocabularyVersion", "outcome", "sourceNodeIds", "context", "structures", "limits", "counterexamples", "unrepresentableReason"], "$");
  structuralCheck(value.schemaVersion === 1 && value.vocabularyVersion === STRUCTURAL_VERSION, "$", "unsupported structural schema or vocabulary version");
  structuralCheck(["represented", "unrepresentable"].includes(value.outcome), "$.outcome", "unsupported outcome");
  list(value.sourceNodeIds, "$.sourceNodeIds");
  structuralShape(value.context, ["scope", "scale", "conditions", "referenceFrame"], "$.context");
  Object.entries(value.context).forEach(([key, entry]) => text(entry, `$.context.${key}`));
  list(value.limits, "$.limits"); list(value.counterexamples, "$.counterexamples");
  structuralCheck(Array.isArray(value.structures), "$.structures", "structures must be an array");
  if (value.outcome === "unrepresentable") {
    structuralCheck(value.structures.length === 0, "$.structures", "unrepresentable results cannot contain guessed structures");
    text(value.unrepresentableReason, "$.unrepresentableReason");
    return value;
  }
  structuralCheck(value.unrepresentableReason === null && value.structures.length > 0, "$", "represented outcome needs structures and a null failure reason");
  const records = new Map();
  value.structures.forEach((record, index) => {
    const path = `$.structures[${index}]`;
    structuralShape(record, ["id", "term", "dependsOn", "description", "attributes"], path);
    text(record.id, `${path}.id`); text(record.term, `${path}.term`); text(record.description, `${path}.description`);
    structuralCheck(!records.has(record.id), path, "duplicate structure ID"); records.set(record.id, record);
    structuralCheck(Object.hasOwn(STRUCTURAL_TERMS, record.term), `${path}.term`, "unknown term; use an unrepresentable result instead");
    const definition = STRUCTURAL_TERMS[record.term];
    list(record.dependsOn, `${path}.dependsOn`, 0);
    structuralShape(record.attributes, Object.keys(definition.attributes), `${path}.attributes`);
    for (const [key, type] of Object.entries(definition.attributes)) attribute(record.attributes[key], type, `${path}.attributes.${key}`, value.sourceNodeIds);
    if (record.term === "independence") {
      const origins = record.attributes.lineages.map((item) => item.originId);
      const known = origins.filter((item) => item !== null);
      const expected = new Set(known).size < known.length ? "shared-origin" : origins.length < 2 || known.length < origins.length ? "unknown" : "distinct-declared-origins";
      structuralCheck(record.attributes.assessment === expected, path, "assessment must preserve declared source dependence and unknown origins");
    }
    if (record.term === "absence" && record.attributes.status === "observed-absent") {
      text(record.attributes.method, `${path}.attributes.method`, true);
      text(record.attributes.coverage, `${path}.attributes.coverage`, true);
    }
  });
  const done = new Set(), visiting = new Set();
  function visit(record) {
    if (done.has(record.id)) return;
    structuralCheck(!visiting.has(record.id), record.id, "cyclic derivation recipe"); visiting.add(record.id);
    const definition = STRUCTURAL_TERMS[record.term];
    const dependencies = record.dependsOn.map((id) => {
      structuralCheck(records.has(id), record.id, "missing local dependency");
      return records.get(id);
    });
    structuralCheck(definition.layer !== "candidate" || dependencies.length === 0, record.id, "candidate primitives have no derivation dependencies in v0.1");
    structuralCheck(definition.requires.every((term) => dependencies.some((item) => item.term === term)), record.id, `recipe requires: ${definition.requires.join(", ")}`);
    dependencies.forEach(visit); visiting.delete(record.id); done.add(record.id);
  }
  value.structures.forEach(visit);
  return value;
}
