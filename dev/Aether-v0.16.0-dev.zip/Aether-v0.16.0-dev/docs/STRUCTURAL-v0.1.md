# Aether Structural Vocabulary v0.1 — implementation contract

Status: candidate, falsifiable representational language, not an ontology of reality.
This document and its adversarial fixtures are the contract for the next development
build, v0.16.0-dev. No resident, automatic extraction, autonomous belief update, or truth scoring.

## Candidate core

The nine candidates are distinction (different under a criterion), relation
(connected in a stated respect), reference (frame, baseline and dimension), possibility
(considered alternatives, not claims of physical possibility), constraint (restriction),
magnitude (degree under a unit or scale), order (sequence without implied causation),
equivalence (same under an explicit criterion while retaining differences), and context
(scope, scale and conditions). Their versioned definitions are revisable hypotheses.

Derived descriptions must contain explicit dependency references to their lower-level
recipe ingredients. Those recipes are proposed representation rules, not proofs that
the candidates are universal or logically minimal. Gradient, polarity, change,
transformation, boundary, feedback, recursion, symmetry, invariant, attractor,
independence, causality, hierarchy, network, cycle, path-dependence, agentive-structure,
analogy, absence, and informational-gravity remain derived. Informational gravity is
experimental attention/trajectory attraction, explicitly not epistemic support.

## Representation and API

Structural interpretations are separate `abstraction` Field nodes with an
`aether:structural` extension. The payload has exact fields:

- `schemaVersion: 1`, `vocabularyVersion: "aether-structural-v0.1"`.
- `outcome: "represented" | "unrepresentable"`.
- `sourceNodeIds`: nonempty, unique observation IDs in selected parent history.
- `context`: `{scope, scale, conditions, referenceFrame}` (all explicit text).
- `structures`: records `{id, term, dependsOn, description, attributes}`.
- `limits`, `counterexamples`: nonempty lists of attributed limits and potential tests.
- `unrepresentableReason`: null for represented results; nonempty text otherwise.

Represented results have at least one structure; unrepresentable results have none.
Do not stuff an unknown term into an existing candidate or use invented certainty
to satisfy validation. An unrepresentable record still links to observations,
retains provenance and uncertainty, and records the vocabulary version that failed.

`validateStructuralInterpretation(payload)` validates that boundary and recipes.
`addStructuralInterpretation(snapshot, {parentStateId, stateId, nodeId, createdAt,
provenance, summary, interpretation, revises?})` constructs a proposed successor.
All inputs are strict JSON; getters, cycles, and unknown keys are rejected. No I/O,
clock, model invocation, ID generation, classification, or confidence generation.
Interpretation provenance is supplied anew, never copied as source endorsement.

Revisions reference another structural interpretation in parent history with a new
node ID. Original interpretations and raw observations remain unchanged. Competing
interpretations can branch and integrate without ranking or choosing a winner.
The node's `derivedFrom` exactly mirrors payload source IDs, `confidence` remains
unknown, `status` stays open, and candidate names do not become core Field primitives.

`validateStructuralField(snapshot)` validates structural nodes, their payloads,
source observation types/ancestry and revision targets. Consumers of imported
structural data must call it before interpreting extensions. Generic Field storage
deliberately keeps extensions opaque: marker presence alone is not validation or
evidence of origin. The structural reader is the authoritative processing boundary.
Unknown versions fail explicitly there without mutating stored data.

`readStructuralInterpretations(snapshot, stateId)` returns the selected state's
structural nodes after validating the complete snapshot. Earlier and competing
interpretations remain visible; membership is not a resolved set of beliefs.
Conversation-dedicated Fields additionally enforce their existing conversation
scope, so foreign conversation provenance cannot break scoped deletion review.
Manual interpretation with null conversation provenance remains allowed.

## Executable safeguards

- Equivalence names a criterion and preserves distinguished aspects.
- Analogy explicitly does not imply mechanism equivalence.
- Order does not imply causation; causality is a hypothesis with stated basis and
  alternative explanations, never automatically promoted from association.
- Independence lists declared source origins. Shared origins are not counted as
  independent confirmations; distinct declared origins do not prove independence.
  One source or an unknown origin cannot establish distinct declared origins.
- Attraction/popularity never creates a `supports` edge or updates confidence.
- Endpoint equivalence does not establish equivalent histories.
- Not observed and observed absent are distinct. Observed absence needs a method
  and coverage statement; neither is a universal absence claim.
- Invariants require property, transformation, context, scale, and equivalence
  criterion. Symmetry also names transformation and preserved equivalence.
- Ordered sequences and feedback/cycle paths may revisit a point. Their modeled
  cycles are distinct from the acyclic graph of derivation dependencies.

Exact attribute fields, allowed labels, and candidate derivation recipes are
published as the deeply immutable `STRUCTURAL_TERMS` export in
`src/core/structural-vocabulary.js`. Terms and versions are exact strings. All
recipes are exercised by `test/structural.test.js` and the authored scenarios in
`test/fixtures/structural-cases.js`.

Validation checks explicit structure and metadata; it cannot verify that a stated
mechanism, provenance, measurement, causal test, or counterexample is true. Free-text
claims remain attributed data, including claims that misuse these words. Tests must
not claim semantic understanding just because an input passes its schema.

## Cross-domain/adversarial acceptance

Fixtures cover thermostat, cell membrane, recursive program, pendulum, ecosystem,
market, human conversation, neural circuit, orbit, copied-source misinformation,
hidden common cause, equal endpoints with different paths, and matching topology
with different mechanisms, plus an unfamiliar/unrepresentable case. Each fixture
must encode relevant distinctions and include a stated limit and counterexample.
Paired negative tests remove required criteria, relabel uncertainty as certainty,
or conflate epistemic categories and must be rejected. These are synthetic
representation fixtures, not empirical scientific findings or model evaluations.

After verification and a source-only ZIP, return to the owner and Cal for review
before structural retrieval, live model interpretation, or resident training.
