# Raw capture before interpretation

Post-v0.14.0 development increment, 2026-09-12. This module is not included in the
previously packaged v0.14.0 release. It is now connected through
[explicit opt-in](LIVE-FIELD.md), not enabled automatically for existing chats.

The owner/Cal review reaffirmed the direction with one essential constraint:
interpretation must never overwrite capture. See the
[shared review](https://chatgpt.com/share/6aa388b1-5b60-83e9-90ca-638d4130a56d).

`captureCompletedTurn(snapshot, command)` from `src/core/field-capture.js` constructs
one complete proposed Field snapshot. It does not save, invoke a model, or read
conversations. The command requires:

- `parentStateId`, `stateId`, `createdAt`, `conversationId`, `executionId`, `edgeId`.
- `completed: true`: the caller must attest that inference actually completed.
- `human`: `nodeId`, `messageId`, `sourceId`, `occurredAt`, `text`.
- `model`: the same fields plus `providerId` and `modelId`.

Both messages become observations of what was said, not verification of the
message's claims. Text is preserved verbatim, including whitespace and Unicode;
empty/whitespace-only content is rejected by the existing record contract.
No punctuation-based question detection, hypotheses, summaries, primitive tags,
or numeric confidence are generated. A system-attributed `responds_to` edge goes
from model output to human input; it does not mean support or agreement.

Message timestamps live in `extensions["aether:capture"].occurredAt`; record
`createdAt` is the capture timestamp. The marker also records capture version 1
and source role. Message/source/model IDs are supplied by the caller, never guessed.
The model observation retains execution linkage; the human message is not credited
as model output. Input metadata is validated but not independently authenticated.

The editing layer refuses revisions of capture-marked nodes. Add interpretations
as new attributed nodes with `derivedFrom` pointing to captured records in parent
history. Interpretations can then be revised or branched independently. Existing
records cannot be overwritten in storage. Extensions are not a security boundary:
trusted importers can construct records directly, and imported markers are not
proof that a source event happened. Explicit deletion remains available.

Duplicate conversation/message capture within the supplied snapshot is rejected.
Persist the proposal using `LocalFieldStore.save` and retain the exact proposal
and request ID for uncertain retries. This is not cross-store deduplication or an
atomic conversation/Field transaction.

## Before enabling live capture

The application still needs stable message/execution linkage, explicit opt-in,
and reviewed linked-deletion behavior that survives partial failure and restart.
Do not enable copying live conversation text until deleting a conversation cannot
quietly leave duplicated Field content. Whole-Field deletion is implemented, but
it is not permission to erase unrelated inquiries in a shared Field.

[Conversation-dedicated Fields](CONVERSATION-FIELD.md) now provide explicit scope,
deletion review, and a locked Field-side deletion operation. A separate
[cross-store coordinator](LINKED-DELETION.md) now provides journaled deletion and
a cooperating write guard. Live opt-in and guarded routing are now implemented
in v0.15.0-dev; see [the workflow and limits](LIVE-FIELD.md).

Tool-result capture and a provisional primitive vocabulary remain later steps.
No resident training or automated interpretation is introduced here.
