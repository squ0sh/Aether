# Opt-in live Field capture — v0.15.0-dev

This is the first live integration, for review with the owner and Cal. The packaged
v0.14.0 ZIP is unchanged. Capture is off by default and never bulk-imports old chat.

## Browser workflow

Start or open a conversation, then choose **Enable Field capture** below the chat.
Confirm the explanation: future completed turns are copied verbatim into a dedicated
local Field, and deleting that conversation requires deleting its Field too. The
first turn of a new conversation happens before opt-in. There is no pause/disable
toggle in this first iteration; continuing elsewhere without capture requires a
new conversation. Existing enabled history is retained until explicit deletion.

Both human and model messages are observations of what was said, not verified
claims. Stored text is copied exactly from the persisted conversation; existing
chat input normalization is unchanged. IDs link each capture to its actual messages,
provider, model, and successful execution. No summaries, inferred questions, numeric
confidence, or primitive labels are generated. Field content is not yet selected
as model context or presented as an inquiry editor.

New conversation storage directories are created owner-private (0700). If an
existing directory has broader permissions, opt-in fails with an explanation;
permissions are not silently changed. Owner-reviewed permission adjustment is
required before enabling. Models and runtimes are not changed by this feature.

## API

- `GET /api/conversations/:id/field`: enabled/deletion status.
- `POST /api/conversations/:id/field` with `{"permission":true}`: reserve the
  dedicated Field durably and enable future completed-turn capture.
- Normal JSON and streaming chat return `fieldCapture` on completion.
- `POST /api/conversations/:id/capture-retry` with `{"executionId":"..."}`:
  retry saving an already persisted, linked successful execution, never inference.
- `GET /api/conversations/:id/deletion-review`: review either ordinary deletion
  or deletion of both stores. For an interrupted linked deletion, returns its
  existing command instead of inventing a new request.
- `DELETE /api/conversations/:id` for an enabled conversation requires
  `{"permission":true,"command":<review.command>}`. Unlinked conversations retain
  ordinary deletion. Arbitrary Field IDs cannot be substituted in the command.

The association is the deterministic Field ID `aether:conversation:<UUID>` and its
immutable dedicated-scope record. Opt-in creates the empty Field first, so deletion
works before the first captured turn. Generic/shared Fields are not auto-linked.
All application chat writes and capture publication now use the coordinator guard;
linked deletion uses the same cross-process lock. Reads of a deleting conversation
are refused. Direct file edits or another program bypassing this guard remain out
of scope. No authentication is added; the default server remains loopback-only.

## Saving and recovery

Assistant persistence and execution recording precede capture. A Field failure
reports `AETHER_PERSISTENCE_UNCERTAIN`, `phase: field-capture`, and `executionId`
without failing over to another model. Browser text is preserved and a save-only
retry button appears. Following a browser reload, use the API with the reported
execution ID; automatic pending-capture discovery is not implemented. A successful
replay confirms publication durability without creating duplicate nodes.

This is a recoverable sequence, not a cross-store atomic transaction. A failed
assistant or execution save cannot yet be reconciled automatically into capture;
it remains reported as uncertain. Incomplete streams and executions predating
opt-in are refused. New captures require a single dedicated Field head rather than
silently resolving branches.

The browser requests deletion review before its confirmation dialog. If linked
deletion fails, re-request review and retry its unchanged command. If the conversation
file is already gone, API recovery by conversation ID remains available even if
its sidebar row is absent. There is no automatic lock stealing: follow
[coordinator recovery](LINKED-DELETION.md) for interrupted process locks. Completed
deletion prevents capture retry from restoring the Field. Backups, exports, other
Fields, and content-free execution measurements are not erased.

## Cal review checkpoint

This reaches the concrete initial integration discussed in the planning review:
raw capture remains separate from interpretation, and deletion is explicit and
recoverable. Pause here for owner/Cal review before primitive vocabulary changes,
resident training, automatic interpretation, or broader automation. Full mocked API
tests cover opt-in, JSON/stream capture, save-only retry, incomplete streams, and
reviewed deletion. Real-model and visual-browser acceptance are still required.
