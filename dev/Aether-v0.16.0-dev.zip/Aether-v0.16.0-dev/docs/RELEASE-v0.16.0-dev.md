# Aether v0.16.0-dev — structural interpretation review checkpoint

This development build adds [Structural Vocabulary v0.1](STRUCTURAL-v0.1.md) as a
pure library above the Field. It is a falsifiable representation language, not
an ontology or proof of understanding. Existing chat, runtime routing, opt-in
capture, persistence, and deletion behavior are retained.

## Included

- Nine candidate primitives and explicit derived recipes with required metadata.
- Strict schema/version validation and an explicit `unrepresentable` outcome.
- Separate abstraction nodes linked to source observations in parent history.
- Fresh interpreter provenance, immutable revisions, and competing branches.
- A structural import/reader boundary that rejects stale payloads, unknown
  versions, mismatched sources, and foreign conversation provenance in a
  conversation-dedicated Field.
- Fourteen synthetic cross-domain scenarios with paired adversarial tests.
- Regression coverage for raw-text preservation, store reopen/export/retry,
  deletion tombstones, and the distinction between modeled cycles and recipes.

No dependencies, downloads, data migrations, new endpoints, or interpretation UI
were added. Structural descriptions do not create support edges, rank branches,
or assign confidence. Generic storage preserves opaque extensions; consumers
must call the dedicated structural validator before interpreting them.

## Review

Run `npm run check`, `npm run test:structural`, and `npm test`.
Verification on this Linux checkout: syntax checks passed; all 51 structural
tests passed; the full test runner reported 194 passes, zero failures and zero
skips (including discovery of the fixture module). Tests use synthetic inputs,
temporary stores, and mock runtimes; no live model or browser evaluation is
claimed for this library-only change.

Review the contract and synthetic fixtures with the owner and Cal before adding
structural retrieval, live extraction, or resident training. Passing tests means
the representation safeguards hold for tested inputs; it does not establish the
truth of attributed free text, provenance, mechanisms, or scientific claims.

The source-only ZIP excludes local conversations, Fields, configuration, models,
runtimes, caches, Git history, and previous archives. Keep existing local data
and runtime directories when updating an installation; this ZIP is for source
review, not a backup of the user's installation.
