# Conversation-dedicated retention boundary

Post-v0.14.0 development, 2026-09-12. These library helpers are now used by
[opt-in live capture](LIVE-FIELD.md) and reviewed HTTP deletion in v0.15.0-dev.

## Explicit creation and review

`createConversationField({id, initialStateId, createdAt, provenance, conversationId,
permission: true})` in `src/core/conversation-field.js` creates an empty Field
explicitly dedicated to a single conversation. Its namespaced scope declares
`delete-with-conversation` retention. This declaration is immutable during normal
saves. It is an intended retention boundary, not a claim that a conversation
exists or proof of authorization from an authenticated user.

Everything subsequently put in this dedicated Field—including interpretations,
branches, and source-neutral notes—is within its whole-Field deletion scope.
Do not use it to store unrelated inquiries. Generic/shared Fields remain supported;
they are not implicitly converted to dedicated Fields. Creating a dedicated Field
does not turn on chat capture, and the capture builder refuses a different
conversation when the dedicated scope is present.

`reviewConversationFieldDeletion(saved, conversationId)` takes a `load` result
and returns a frozen review with Field/conversation IDs, `expectedRevision`,
node/edge/state counts, and a scope warning. It does not delete or publish content.
It refuses unscoped, mismatched, and known mixed-conversation Fields.

## Field-side deletion

`store.deleteConversationField(fieldId, {conversationId, requestId,
expectedRevision, permission: true})` checks the dedicated scope and all records'
explicit conversation provenance under the existing writer lock, against the exact
reviewed revision. Foreign non-null conversation IDs are refused with
`FIELD_SCOPE_CONFLICT`; source-neutral provenance does not exclude a record from
the dedicated Field's declared retention scope. No text-based ownership inference
is attempted. Unlabeled external copies cannot be discovered automatically.

Deletion uses the same atomic marker publication, staging cleanup, and durability
checks as [whole-Field deletion](FIELD-STORAGE.md#explicit-deletion). The retry
digest includes conversation scope as well as request ID. Retry an uncertain
operation with the same method, conversation ID, request ID, reviewed revision,
and explicit permission. Old saves cannot restore a published deletion.

This deletes only the selected dedicated Field and its matching local staging
files. It does not delete the conversation, external references/copies, exports,
backups, other Fields, or execution measurements. It is not secure media erasure.
Explicit generic `deleteField` remains a separate owner-directed operation.

## Remaining live-integration work

The [linked-deletion coordinator](LINKED-DELETION.md) now journals deletion intent,
blocks cooperating writes, and retries partial deletion of both stores. It remains
a separate library; the requirements below still apply when wiring live routes.

A durable coordinator must record the conversation-to-Field linkage and deletion
intent before either store is changed. It must block new capture for a deleting
conversation, recover partial completion after restart, and avoid claiming that
both stores were erased after only one succeeds. It must also handle deletion
before the first capture is published. The existing chat-delete route must not
silently acquire permission to erase unrelated shared Fields.

Live capture stays off until that coordination and an explicit user opt-in are
implemented and tested. These local helpers are preparation, not a cross-store
transaction or completed end-to-end linked deletion.
