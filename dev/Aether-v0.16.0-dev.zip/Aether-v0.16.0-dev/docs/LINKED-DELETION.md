# Recoverable linked deletion coordinator

Post-v0.14.0 development increment. `LinkedDeletionCoordinator` from
`src/core/linked-deletion.js` coordinates deletion of one existing conversation and
one explicitly dedicated Field. It is now wired into [opt-in live capture](LIVE-FIELD.md)
and reviewed deletion in v0.15.0-dev; the text below describes the library contract.

## Interface

Construct with explicit `{root, conversationRoot, fieldStore}`. The journal root
must be separate from the data stores. Existing directories must be real, private
0700 directories on POSIX; the coordinator does not silently change permissions.
New journals use 0600. `fileSystem` is a test-only fault injection seam.

- `review(conversationId, fieldId)` checks dedicated scope and returns counts,
  the Field's `expectedRevision`, a `conversationDigest`, and a scope warning.
- `deleteLinked({conversationId, fieldId, requestId, expectedRevision,
  conversationDigest}, {permission: true})` deletes both reviewed sides. Only the
  five command fields are accepted; do not pass the entire review object.
- `status(conversationId)` returns a frozen journal with the original command and
  phase, or null if no intent has been published. No message text is returned.
- `withActiveConversation(conversationId, callback)` holds the coordinator lock
  across an asynchronous cooperating write, refusing it once intent exists.

Review is not consent or a reservation. Deletion requires explicit permission,
rechecks both reviewed versions, and then durably publishes `pending` intent.
It deletes the Field through its scoped API, journals `field-deleted`, deletes the
conversation and its matching adapter staging files, then journals `complete`.
Completion is acknowledged only after both sides and journal publication succeed.

Retries use the identical command and permission. Field deletion receipts make
repeating an already-finished first step safe. Missing conversation files can be
retried, but a reappearing/changed conversation is not erased without the reviewed
digest matching. Journal key order is not significant. Different scope or request
IDs cannot replace an existing intent. There is no automatic cancellation of a
published deletion, because one side may already be gone.

## Failure and recovery

`LINK_DELETE_UNCERTAIN` means deletion or acknowledgement may be incomplete. Use
`status` and retry its original command after resolving the error. If intent
publication failed before rename, status can be null and neither store was touched.
A durable pending or completed journal blocks new coordinated writes permanently.
Corrupt journals fail closed with `LINK_CORRUPT`, never reset to an active state.

A process crash can leave the exclusive conversation lock, just as a Field crash
can leave its writer lock. `LINK_LOCKED` is not a timeout to bypass: stop/verify all
writers are gone, inspect and preserve recovery metadata, then deliberately move
the specific stale lock aside. The coordinator never steals locks. Once ownership
is available, reopening and retrying resumes from the journal. No unattended
startup recovery or lock-recovery UI is implemented.

The journal contains linkage IDs, a request ID, reviewed revision, conversation
digest, phase, and checksum—not titles, messages, or model output. IDs and digests
are still potentially identifying metadata; journals must remain private and
excluded from version control. Checksums detect accidental damage, not forgery.
POSIX directory sync is used; equivalent Windows crash durability is not promised.

## Integration obligations and limits

Every cooperating conversation write and capture publication must use
`withActiveConversation`. Do not call another coordinator method recursively inside
its callback. Application chat writes and deletion now use this guard through
`LiveField`. All cooperating processes must share the same journal root.
Direct filesystem edits or writes bypassing this boundary cannot be blocked.

Only one explicitly reviewed, existing dedicated Field is handled. Reserve that
Field durably at opt-in before the first capture; deletion before first publication
is not supported without that reservation. Multi-Field/shared-Field linkage needs
separate ownership rules, not silent cascading deletion. Before enabling live use,
persist the association, wire the capture and deletion paths to this coordinator,
and test the API's partial-failure responses and opt-in lifecycle.

Other Fields, external copies, backups, exports, and execution measurements are
outside scope. Ordinary unlink is not secure media erasure. Already returned
in-memory data is not revoked. This is a recoverable sequence across stores, not
an atomic transaction: between steps, the Field may be gone while the conversation
still exists. No successful cross-store completion is reported in that condition.
