# Aether v0.18.0-dev — Context Assembly v0.1

Built narrowly on the v0.17.0-dev source archive for owner/Cal review. The stable
repository-root app, user models, portable runtimes and private data are unchanged.
See the [assembly contract](ASSEMBLY-v0.1.md).

## Implemented

- One new persistent concept: immutable AssemblyEvents in the existing Field.
- Deterministic whole-segment packing with candidate/omission reasons and explicit
  policy order; blocked base context is never silently truncated.
- Exact reconstructable canonical artifacts with source provenance, trust labels,
  SHA-256 and complete UTF-8 payload accounting.
- Explicit input/window/output/overhead budgets, unknown counts, and distinctly
  estimated versus caller-attested tokenizer counts.
- Existing raw/summary representations with attributed transformation chains and
  recoverable originals; no generated summarizer or semantic equivalence claim.
- Strict source/branch/schema validation and audit-role exclusions. Historical
  instructions and tool commands remain untrusted inert data.
- Thirty-five authored adversarial scenarios plus focused accounting, validation,
  persistence, deletion and audit-boundary tests.

No dependencies, model downloads, server changes, new endpoints or UI changes.
No automatic live context injection, resident, training, autonomous inference loop,
truth scores, destructive compression, decay or forgetting. Assembly does not
claim submission, provider processing, attention or causal influence. Later
observations can use existing provenance and Field relationships; no separate
delivery/execution-link ontology has been added.

## Compatibility and review

Old source records, raw capture and RetrievalEvents stay unchanged. Dedicated
structural validation now rejects direct audit observations as structural source
evidence, including the RetrievalEvent-source edge case accepted by v0.17. Generic
storage is not migrated or erased. Audit-derived ordinary observations remain
inspectable with incomplete ancestry.

This finishes the requested **library review checkpoint**, not all future Aether
work. Review the event contract and fixtures together before wiring it to a real
provider. The canonical artifact is not yet an adapter HTTP payload, and tests do
not demonstrate live memory quality or provider truncation behavior.

## Verification and package

Verified on Linux with Node v26.8.2: syntax checks passed; all 67 focused assembly,
budget, import/persistence and audit-boundary tests passed, including the 35
numbered scenarios. The full regression runner reported **296 passes, zero failures
and zero skips** (including discovery of two fixture modules). Review also tightened
counter metadata isolation and recursive side-summary lineage; both have regression
coverage. No production adapter or server behavior changed.

Run `npm run check`, `npm run test:assembly` and `npm test`. Tests use authored
synthetic data, temporary stores and mock runtimes; no user model or live server
is required. The source-only ZIP includes code, assets, docs and tests and excludes
models, runtimes, conversations, Fields, node_modules, caches, archives and Git.
