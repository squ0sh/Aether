# Memory & Retrieval v0.1 — v0.17.0-dev library checkpoint

Retrieval is an auditable selection of history, not truth, independent evidence,
or proof that a model used a record. The only new persistent concept is a
`RetrievalEvent`. It is encoded as an immutable observation node carrying
`aether:retrieval`, in the same Field/store and retention boundary as its sources.
No separate attention, salience, or epistemic-transition store is introduced.

## First checkpoint and limits

This is a deterministic, single-Field library. It does not change live chat,
assemble prompts, run models, generate embeddings, or classify free text as fact.
Every event reports working context as `not-applied` with no included IDs. A future
context-assembly boundary must separately distinguish assembled, submitted, and
unknown delivery; even submission is not proof of causal influence on a model.

The baseline searches node records in an explicitly selected state's ancestry,
never unselected sibling branches or other Fields. Edges guide routes but are not
returned as independent candidate nodes. Existing structural v0.1 semantics stay
unchanged, including its observation-only source linkage. New epistemic relation
semantics would require their own reviewed, versioned interpretation contract.

## Event contract

`src/core/retrieval-events.js` provides `validateRetrievalEvent(payload)`,
`validateRetrievalField(snapshot)`, `addRetrievalEvent(snapshot, command)` and
`readRetrievalEvents(snapshot, stateId)`.

The payload has exact JSON fields:

- `schemaVersion: 1`, `vocabularyVersion: "aether-memory-v0.1"`, `fieldStateId`.
- `request: {query, activeQuestionIds, context}`: query/context strings and explicit
  question IDs. Empty query/context is allowed for question or exploratory recall.
- `policy: {id, version, maxCandidates, maxSelected, perRouteLimit, explorationSlots}`.
- `routes`: records `{id, status, consideredCount, matchedCount, returnedRecordIds,
  limit, notes}` (notes is a nonempty list of strings). IDs are lexical, structural, ancestry, contradiction,
  question-linked, exploratory. Status is complete, bounded, or not-applicable.
- `candidatePool`: records `{recordId, reasons, selected, exclusionReason, lineage}`.
  Each reason is `{route, detail, sourceIds}`. Lineage is
  `{rootRecordIds, status}`, status declared-ancestry or incomplete; it does not
  certify independent evidence. Selected candidates have null exclusion reason;
  every discovered but unselected candidate has an explicit reason.
- `selectedRecordIds`: ordered, unique subset of the pool.
- `workingContext: {status: "not-applied", recordIds: []}`.
- `ancestry: {previousRetrievalEventIds, attentionSourceIds}`.
- `limits`: nonempty list of explicit limitations.

Policy bounds: maxCandidates 1..256, maxSelected 0..64 and at most maxCandidates,
perRouteLimit 1..128, explorationSlots 0..16 and at most maxSelected. Policy ID and
version are preserved strings; the baseline engine only executes its known policy.
Routes report discovery before the merged pool cap; returned IDs can therefore be
outside the final pool, with that cap explained in limits. Candidates mean bounded
discovered items, not every item that was searched or may be relevant.

`addRetrievalEvent` command is `{parentStateId, stateId, nodeId, createdAt,
provenance, event}`. Caller supplies identity/time and requester provenance. The
event's fieldStateId must equal parentStateId. Its node has open status, unknown
confidence, no core primitives, no raw capture marker, and no revision target.
Its `derivedFrom` covers every referenced node ID exactly once, sorted by ID.
References must exist in selected parent history with their declared roles;
prior retrieval IDs must be retrieval events, attention IDs must not be events,
and active questions must be questions. Markers alone do not validate content.
Prior RetrievalEvents cannot appear as candidate lineage roots or discovery
reason source IDs; audit ancestry has its own explicit prior-event field.
Imported snapshots must pass the dedicated reader/validator. Generic Field stores
preserve opaque extensions, not semantic guarantees.

## Baseline engine

`src/core/retrieval.js` exports `DEFAULT_RETRIEVAL_POLICY` and
`buildRetrievalDecision(snapshot, {fieldStateId, request, policy, ancestry})`.
It returns an immutable validated payload, not a saved event or model prompt.
Selection order, route caps, deterministic ties and reasons must be documented
in the module. No wall clock, random sampling, or implicit latest state is used.
Semantic/embedding discovery is not implemented or claimed; the route boundary
leaves room for it after review. Structural discovery validates versioned payloads.

Multiple models or repeated copies do not create new evidence. The engine must
not promote status/confidence, use popularity as truth, or treat attention
nominations as commands. Contradictions, open questions, boundary conditions,
source ancestry and alternatives need independent discovery opportunities.
Ancestry records make inherited attention visible without fabricating origin
certainty. An unfamiliar lineage remains incomplete.

## Privacy, history and audit

Queries, contextual details and candidate explanations can contain private text.
Events inherit dedicated conversation scope and are deleted with the Field.
The existing writer guard/tombstones must reject deletion-time saves and replay;
the library creates no external cache or retained prompt copy. Explicit deletion
outranks audit retention; a deleted Field cannot be resurrected to resolve an ID.
Exports/backups and already-returned in-memory values retain existing limitations.

Old events remain immutable under later policy versions. Comparison of repeated
candidate nonselection can demonstrate starvation *within recorded pools*.
Blindness means information never entered a pool; detecting global relevance or
global bias is not claimed by bounded traces. Route coverage, truncation and
unknown semantic relevance must stay visible. No record is deleted or decayed for
low priority, and abstractions never overwrite their sources.

## Acceptance

Synthetic tests cover copied misinformation, attention echo/self-reference,
contradictory evidence despite model preference, old contradictions, novelty and
recency bias, dominant connectivity, analogy boundaries, persistent questions,
different histories, absence distinctions, failed predictions, subsumption,
revisable broader theories, incompatible scopes, source recovery, candidate
starvation, route blindness and policy-history audit. These are representation
tests, not empirical claims of scientific or semantic understanding.

Raw capture text/provenance/status/confidence must remain unchanged; events must
survive reopen/export/retry without granting stale writes permission to bypass
deletion. Return this checkpoint for owner/Cal review before live prompt use.
