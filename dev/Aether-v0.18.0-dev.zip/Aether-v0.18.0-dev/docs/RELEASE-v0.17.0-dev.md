# Aether v0.17.0-dev — Memory & Retrieval v0.1

This is the first library review checkpoint from the owner/Cal handoff, built on
v0.16.0-dev. Its contract is [Memory & Retrieval v0.1](MEMORY-v0.1.md).

## Implemented

- One new persistent concept: immutable RetrievalEvents stored as versioned Field
  observations, with requester provenance and explicit state/history references.
- Six deterministic routes: lexical, structural, ancestry, contradiction,
  question-linked and exploratory. Candidate/selection caps, ordered IDs, policy
  settings, route traces and nonselection reasons survive in each event.
- Source-family diversity preferences without evidence counting or truth scores.
  Repeated attention remains traceable; retrieval events cannot masquerade as
  candidate evidence or declared source roots.
- Explicit `workingContext.status: "not-applied"`. Selection does not imply
  prompt inclusion, execution, or causal influence on a model.
- Dedicated validation of imports, source roles, branch ancestry, immutable
  records and conversation scope. Existing raw capture remains unchanged.
- Reopen/export/retry tests and existing linked deletion protection, including
  pending deletion and tombstones. Private queries and reasons stay in the Field.
- Twenty authored synthetic adversaries plus event/schema/storage tests.

No new dependencies, downloads, live endpoints or UI workflows were added.
No existing local data needs migration. The stable root application in the Git
repository is not replaced by this development source tree.

## Honest limits and next review

This baseline enumerates the selected history; caps bound returned candidates,
not the amount of history loaded or scanned. It is not optimized for million-node
Fields. Literal matching and explicit relationships are not semantic reasoning.
Unknown structural or memory schema versions fail at the reader boundary.

Default policy: 48 candidates, 12 selections, 24 results per route, and 2 reserved
exploration slots. Available exploration slots precede one contradiction and one
question opportunity; remaining slots follow balanced route discovery with a
source-family diversity pass. Small budgets can omit relevant material. These
are revisable policy preferences, not permanent quotas or importance values.

Source ancestry is declared, not independently verified. Unknown/external roots
stay incomplete. Policy and previous-event traces support later inspection of
repeated omissions; this build does not autonomously diagnose global relevance,
policy bias, or retrieval blindness. New policy versions can be stored without
rewriting history; the engine executes only its currently supported version.

Epistemic transitions remain attributed existing Field relationships/revisions;
structural vocabulary v0.1 is not silently expanded. There is no resident,
automatic prompt injection, embedding service, salience database, belief update,
destructive compression, decay or forgetting.

Review this contract and the synthetic fixtures with the owner and Cal before
connecting a context assembler to live chat. That later step needs explicit
delivery-state semantics and the existing deletion/write guard.

## Verification and package

Verified on Linux with Node v26.8.1: syntax checks passed; 34 new retrieval tests
passed; the full runner reported 229 passes, zero failures and zero skips
(including discovery of two fixture modules). Two pre-existing HTTP tests were
made deterministic by awaiting the existing operation-release boundary before
issuing their next write. No live request-handling behavior was changed.

Run `npm run check`, `npm run test:retrieval`, and `npm test` from this source
directory. Tests use synthetic Fields, temporary stores, mock servers and mock
runtimes. Passing them does not establish scientific truth, semantic retrieval
quality, human memory, or live model/browser behavior.

The source-only ZIP includes code, public assets, docs and tests. It excludes
models, runtimes, conversations, Fields, caches, prior archives and Git history.
