# Context Assembly v0.1

This is a library-only review checkpoint. One new persistent concept is introduced:
an **AssemblyEvent**, stored as an immutable attributed observation in the existing
Field, under `aether:assembly`. There is no new database or live API.

The intended sequence remains Field → RetrievalEvent → AssemblyEvent → execution
→ attributed observation → capture → Field. These are distinct claims: retrieval
does not prove assembly, assembly does not prove submission, submission does not
prove full processing, and none of these proves influence or a causal explanation.

## Deterministic construction

`buildContextAssembly(snapshot, command, counter?)` in `context-assembly.js` takes:

```js
{
  fieldStateId: "state-containing-retrieval",
  retrievalEventIds: ["retrieval-observation"],
  target: {
    providerId: null, modelId: null, runtimeId: null, executionId: null,
    attemptId: "caller-allocated-attempt"
  },
  policy: { id: "aether-assembly-baseline", version: "0.1", order: "retrieval" },
  currentSegments: [
    { id: "instructions", role: "system", content: "Current caller instructions" },
    { id: "question", role: "user", content: "Current question" }
  ],
  budget: {
    maxPayloadBytes: 32768, maxInputTokens: null, contextWindowTokens: null,
    reservedOutputTokens: null, providerOverheadTokens: null
  },
  representations: [],
  transformations: []
}
```

Only selected records from the named RetrievalEvents are considered, deduplicated
in event/selection order. There must be 1–16 retrieval references in the selected
Field state's ancestry. `order: "reverse"` is an explicit diagnostic alternative.
The builder executes only the named baseline policy version, not arbitrary
imported policy names. Candidate ordering is a policy, not a relevance verdict.

Current segments are mandatory and never silently truncated. Roles are `system`,
`user`, `conversation-data`, or `tool-data`; callers must not relabel historical
material as current system instructions. After measuring this base artifact, the
builder tries each whole memory representation in order. A candidate that does
not fit is omitted with a reason; later smaller candidates may still fit. If the
base cannot fit, outcome is `blocked`, every candidate is omitted, and no executable
artifact is exposed. No generated summarizer, implicit clipping or semantic
contradiction-balancing mechanism is included.

Every considered record keeps its RetrievalEvent references, selected
representation, transformation path, decision and reason. Ordered memory segments
have stable IDs and the fixed role `historical-data` with trust `untrusted`.
Historical prompt injections, prior model answers, copied evidence, and tool
commands remain attributed data. No historical command is run. Tags alone cannot
guarantee that a future model will resist prompt injection.

## Payload and budgets

`materializeAssembly(snapshot, event)` reconstructs the exact canonical UTF-8 JSON
artifact (`aether-context-json-v0.1`) from current segments and immutable source
references. It verifies bytes and SHA-256. The artifact contains target metadata,
current material, ordered historical representations, source and representation
provenance, source kinds and declared ancestry. Scope/context, declared status and
confidence, primitives, known structural qualifications and transformation limits
are included as attributed data too; no confidence becomes a truth verdict.
Arbitrary extension payloads and the full relationship graph are not silently
copied into the artifact; their immutable source records remain separately
inspectable. It is **not** an adapter-specific
HTTP request or a claim that the provider received these bytes. Existing adapter
prompts and chat behavior are unchanged.

Measurement covers the complete canonical artifact: instructions, conversation
and tool data supplied by the caller, selected memory, summary content, provenance
and JSON serialization overhead. `maxInputTokens` is an optional packing-policy
limit; `contextWindowTokens` is the declared total window. When context window,
output reserve and extra provider/runtime overhead are all known, available input
is their difference, further bounded by `maxInputTokens`. Hidden provider templates
and final provider serialization are not guessed. Latency, compute, cost and
multimodal feasibility are explicitly outside this text-only baseline.

Default token counts and unknown limits stay `null`. With no token limits, the
builder can do byte-bounded packing, explicitly **not** confirmed model-capacity
admission. An unknown token count with a declared numeric token limit blocks
packing. Partly unknown reserves keep capacity unknown, while known contributions
can still establish overflow. Output reserve larger than the window does not turn
back into available capacity: usable capacity reports zero with a warning, while
the exact signed comparison rejects even empty input.

An explicit counter may be supplied as `{kind, method: {id, version, source},
count(text)}`. `estimated` is never promoted to verified. The optional
`UTF8_ESTIMATE_COUNTER` uses `ceil(UTF-8 bytes / 4)`, not a tokenizer or upper bound.
`verified` is a caller-attested tokenizer measurement; the library cannot prove the
counter's honesty or compatibility with the target. Imported token counts retain
that limitation even when the byte digest is independently checked. Counters must
be deterministic, synchronous trusted local dependencies; no counter code is loaded
from Field data. Comparisons include all serialized wrappers, not only memory text.

## Summaries and re-grounding

Raw representations are the default. A caller can select an **existing**, attributed
abstraction/inference instead via `{recordId, representationRecordId}`. Each
transformation descriptor contains `outputRecordId`, exact `sourceRecordIds`,
`method: {id, version}` (unknowns are null), and nonempty `limitations`. Source IDs
must match the output's declared derivation. Intermediate transformations remain
explicit; unrelated or unused descriptors cannot silently invent lineage.

The assembler does not certify semantic equivalence. Qualification loss and
summary-of-summary distortion are inspectable, not automatically detected. The
original records remain recoverable through immutable ancestry within the retained
Field. Source copies or a model echo do not become independent evidence. Ancestry
that reaches audit records or unknown external origins remains incomplete, not a
new evidentiary root. Audit content is not embedded as memory source material.

## Immutable history, execution, and privacy

`addAssemblyEvent(snapshot, {parentStateId, stateId, nodeId, createdAt, provenance,
event})` appends the event using existing Field operations. Its selected Field
state, retrieval references, target/attempt, policy, representations, measurements,
limitations and timestamp are retained. `readAssemblyEvents` is the intentional
typed audit read; `validateAssemblyField` validates imported artifacts and source
roles. Generic opaque Field validation alone is not assembly validation.

The event records `submission.status: "not-attempted"`, processing `unknown` and
influence `unknown`. Later evidence must never edit these at-time facts. Use an
ordinary existing Field observation linked through `derivedFrom: [assemblyNodeId]`
and existing provenance (`executionId`, provider/model, method and references)
for a subsequently observed attempt or failure. Include the exact target attempt
in that attribution, not just the conversation ID. No new DeliveryEvent,
ExecutionLink, WorkingContext, ContextAdequacy, AssemblyBias, CompressionHistory,
ExposureHistory or ReGroundingEvent store is introduced. No live executor or new
automatic execution-link writer is implemented in this checkpoint.

Raw captures, prior RetrievalEvents and earlier assemblies stay unchanged. A
retrieval's `workingContext.status` remains `not-applied`; the later assembly is
its own record, not retroactive mutation. Audit events cannot be candidate evidence,
structural sources, source roots, or revised beliefs. Ordinary later observations
may honestly retain an audit link without inheriting evidentiary independence.

Private current text and traces stay in the dedicated conversation Field, not the
separate prompt-free operational execution log. Existing owner-private storage,
append-only saves, receipts, export and deletion/tombstones apply. Cooperating live
writes must use `LinkedDeletionCoordinator.withActiveConversation` if this library
is later integrated. Deletion overrides reconstructability: old snapshots cannot
be restored into a tombstoned store. Already exported copies/backups and in-memory
caller snapshots are outside that store's deletion boundary.

References cannot borrow another Field or an unselected sibling branch. The event
is introduced directly after its declared parent. Unsupported schemas fail closed
at dedicated readers. A compatibility tightening rejects direct structural source
references to RetrievalEvent observations that v0.17 allowed; stored files are not
rewritten or deleted. Legitimate raw captures and normal structural/retrieval
records require no migration.

## Review boundary

Run `npm run test:assembly`. The 35 numbered synthetic adversaries cover pressure,
contradictions, lossy recursive summaries, hostile history, order/representation
changes, different target capacities, unknown processing, failures/nonexecution,
dependency, repeated omissions, policy changes, immutability, and unfamiliar
phenomena. Separate tests exercise schema imports, byte/token accounting, store
reopening, deletion and audit-role safeguards.

These tests establish software behavior, not scientific truth, cognitive adequacy,
memory quality or causal attribution. Full Field validation and candidate packing
are local, bounded-input review implementations, not million-record indexing.
Long-term bias and exposure are derived inspections of existing events, not
autonomous agents or independent persistent concepts.

**Stop for owner/Cal review before live integration.** A future provider adapter
must explicitly account for its final request/template, preserve trust boundaries,
record only observed delivery facts, and use the existing operation/deletion guard.
