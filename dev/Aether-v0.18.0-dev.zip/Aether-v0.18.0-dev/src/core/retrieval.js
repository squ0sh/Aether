import { validateFieldJson } from "./field.js";
import { isAuditNode } from "./audit-history.js";
import { STRUCTURAL_EXTENSION } from "./structural-vocabulary.js";
import { RETRIEVAL_EXTENSION, RetrievalValidationError, validateRetrievalEvent, validateRetrievalField, retrievalHistory } from "./retrieval-events.js";

export const DEFAULT_RETRIEVAL_POLICY = validateFieldJson({
  id: "aether-memory-baseline", version: "0.1", maxCandidates: 48,
  maxSelected: 12, perRouteLimit: 24, explorationSlots: 2
});

const ROUTES = ["lexical", "structural", "ancestry", "contradiction", "question-linked", "exploratory"];
const MERGE_ORDER = ["contradiction", "question-linked", "ancestry", "structural", "lexical", "exploratory"];
const check = (condition, message) => { if (!condition) throw new RetrievalValidationError(message); };
const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
const sorted = (values) => [...new Set(values)].sort(compare);
const marked = (node) => Object.hasOwn(node.extensions, RETRIEVAL_EXTENSION);
function shape(value, keys, name) {
  check(value !== null && typeof value === "object" && !Array.isArray(value), `${name} must be an object`);
  check(Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), `${name} has missing or unknown fields`);
}
function ids(value, name) {
  check(Array.isArray(value) && value.every((id) => typeof id === "string" && id.trim().length > 0) && new Set(value).size === value.length, `${name} requires unique nonempty IDs`);
}
const tokens = (value) => new Set(value.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []);
const overlap = (query, value) => [...tokens(value)].filter((token) => query.has(token)).length;

// This is bounded RETURN/discovery bookkeeping, not a global-relevance oracle:
// each route enumerates its declared operational matches in the selected history,
// sorts them, then returns at most perRouteLimit. No semantic/embedding search is
// claimed. Ties use UTF-16 code-unit ID order, never wall clock, locale or input order.
// A merged pool reserves available exploration slots, one contradiction and one
// question opportunity, then round-robins routes. Selection repeats that order,
// preferring disjoint declared source families before revisiting a family. Those
// operational preferences are not truth, independence or confidence estimates.
export function buildRetrievalDecision(input, change) {
  const command = validateFieldJson(change);
  shape(command, ["fieldStateId", "request", "policy", "ancestry"], "command");
  check(typeof command.fieldStateId === "string" && command.fieldStateId.trim().length > 0, "fieldStateId is required");
  const { request, policy, ancestry } = command;
  shape(request, ["query", "activeQuestionIds", "context"], "request");
  check(typeof request.query === "string" && typeof request.context === "string", "query and context must be strings");
  ids(request.activeQuestionIds, "activeQuestionIds");
  shape(ancestry, ["previousRetrievalEventIds", "attentionSourceIds"], "ancestry");
  ids(ancestry.previousRetrievalEventIds, "previousRetrievalEventIds");
  ids(ancestry.attentionSourceIds, "attentionSourceIds");
  shape(policy, Object.keys(DEFAULT_RETRIEVAL_POLICY), "policy");
  check(policy.id === DEFAULT_RETRIEVAL_POLICY.id && policy.version === DEFAULT_RETRIEVAL_POLICY.version, "Baseline executes only its known policy ID and version");
  for (const [key, min, max] of [["maxCandidates", 1, 256], ["maxSelected", 0, 64], ["perRouteLimit", 1, 128], ["explorationSlots", 0, 16]]) {
    check(Number.isSafeInteger(policy[key]) && policy[key] >= min && policy[key] <= max, `Invalid policy bound: ${key}`);
  }
  check(policy.maxSelected <= policy.maxCandidates && policy.explorationSlots <= policy.maxSelected, "Selection/exploration bounds exceed their containing budget");
  const snapshot = validateRetrievalField(input);
  const history = retrievalHistory(snapshot, command.fieldStateId);
  const all = new Map(history.nodes.map((node) => [node.id, node]));
  const nodes = history.nodes.filter((node) => !isAuditNode(node)).sort((a, b) => compare(a.id, b.id));
  const eligible = new Map(nodes.map((node) => [node.id, node]));
  for (const id of request.activeQuestionIds) check(eligible.get(id)?.kind === "question", "Active questions must be question nodes in selected history");
  for (const id of ancestry.attentionSourceIds) check(eligible.has(id), "Attention sources must be non-event nodes in selected history");
  for (const id of ancestry.previousRetrievalEventIds) check(all.has(id) && marked(all.get(id)), "Previous retrieval IDs must be events in selected history");
  const edges = history.edges.filter((edge) => eligible.has(edge.from) && eligible.has(edge.to));
  const queryTokens = tokens(`${request.query}\n${request.context}`);
  const routes = new Map(), discoveries = new Map();
  function route(id, matches, { considered = nodes.length, applicable = true, notes } = {}) {
    const limited = applicable ? matches.slice(0, policy.perRouteLimit) : [];
    const returnedRecordIds = limited.map((match) => match.id);
    routes.set(id, { id, status: !applicable ? "not-applicable" : matches.length > limited.length ? "bounded" : "complete",
      consideredCount: applicable ? considered : 0, matchedCount: applicable ? matches.length : 0,
      returnedRecordIds, limit: policy.perRouteLimit,
      notes: [notes || "Operational matches only; no semantic relevance or truth determination."] });
    for (const match of limited) {
      if (!discoveries.has(match.id)) discoveries.set(match.id, []);
      discoveries.get(match.id).push({ route: id, detail: match.detail, sourceIds: sorted(match.sourceIds || [match.id]) });
    }
    return returnedRecordIds;
  }

  const lexicalMatches = nodes.map((node) => ({ id: node.id, score: overlap(queryTokens, `${node.content.text}\n${node.context}`),
    detail: "Exact lowercased word overlap with the supplied query/context; not semantic agreement." }))
    .filter((match) => match.score > 0).sort((a, b) => b.score - a.score || compare(a.id, b.id));
  const lexical = route("lexical", lexicalMatches, { applicable: queryTokens.size > 0,
    notes: "Unicode words are lowercased; distinct overlapping words order matches, then ID. No embeddings or claim verification." });
  const structures = nodes.filter((node) => Object.hasOwn(node.extensions, STRUCTURAL_EXTENSION));
  function textualValues(value) {
    if (typeof value === "string") return [value];
    if (Array.isArray(value)) return value.flatMap(textualValues);
    if (value !== null && typeof value === "object") return Object.values(value).flatMap(textualValues);
    return [];
  }
  const structuralMatches = structures.map((node) => {
    const payload = node.extensions[STRUCTURAL_EXTENSION];
    const description = [payload.context, payload.limits, payload.counterexamples, payload.unrepresentableReason,
      ...payload.structures.map((structure) => [structure.term, structure.description, structure.attributes])];
    return { id: node.id, score: overlap(queryTokens, textualValues(description).join("\n")), sourceIds: payload.sourceNodeIds,
      detail: "Validated versioned structural description discovered by literal payload overlap (or empty-query structural browse); analogy and boundaries remain attributed." };
  }).filter((match) => queryTokens.size === 0 || match.score > 0).sort((a, b) => b.score - a.score || compare(a.id, b.id));
  const structural = route("structural", structuralMatches, { considered: structures.length, applicable: structures.length > 0,
    notes: "Uses the structural validator before matching. Unknown or malformed versions fail explicitly, never become irrelevant silently." });

  const seeds = sorted([...lexical, ...structural, ...request.activeQuestionIds, ...ancestry.attentionSourceIds]);
  const seedSet = new Set(seeds);
  const ancestryMatches = new Map();
  function ancestryMatch(id, sourceId, distance, nominated = false) {
    if (!ancestryMatches.has(id)) ancestryMatches.set(id, { id, distance, sourceIds: [],
      detail: nominated ? "Explicit attention nomination; a traceable discovery opportunity, not a command, evidence or priority guarantee."
        : "Declared derivation/revision ancestor of a discovered or nominated record; source ancestry is not proof of independence." });
    const match = ancestryMatches.get(id);
    match.distance = Math.min(match.distance, distance); match.sourceIds.push(sourceId);
  }
  for (const id of ancestry.attentionSourceIds) ancestryMatch(id, id, 0, true);
  for (const seed of seeds) {
    const pending = [{ id: seed, distance: 0 }], visited = new Set();
    for (let index = 0; index < pending.length; index++) {
      const { id, distance } = pending[index];
      if (visited.has(id)) continue;
      visited.add(id);
      const node = eligible.get(id);
      if (!node) continue; // Retrieval/assembly audit history is not candidate evidence.
      for (const parent of [...node.derivedFrom, ...(node.revises === null ? [] : [node.revises])]) {
        if (!eligible.has(parent)) continue;
        ancestryMatch(parent, seed, distance + 1);
        pending.push({ id: parent, distance: distance + 1 });
      }
    }
  }
  route("ancestry", [...ancestryMatches.values()].sort((a, b) => a.distance - b.distance || compare(a.id, b.id)), { applicable: seeds.length > 0,
    notes: "Resolves declared derivation/revision links from bounded lexical/structural returns and explicit question/attention seeds; prior retrieval IDs are trace-only." });

  const contradictions = new Map();
  for (const edge of edges.filter((edge) => edge.relation === "contradicts")) {
    for (const [id, other] of [[edge.from, edge.to], [edge.to, edge.from]]) {
      if (!contradictions.has(id)) contradictions.set(id, { id, anchored: false, sourceIds: [],
        detail: "Endpoint of an explicit contradicts relationship; disagreement is preserved without deciding who is correct." });
      const match = contradictions.get(id);
      match.anchored ||= seedSet.has(id) || seedSet.has(other); match.sourceIds.push(other);
    }
  }
  route("contradiction", [...contradictions.values()].sort((a, b) => Number(b.anchored) - Number(a.anchored) || compare(a.id, b.id)), {
    notes: "All declared contradiction endpoints in selected history are eligible, including old/nonlexical ones; seeded endpoints order first, then ID. No recency preference." });

  const questions = new Map(), active = new Set(request.activeQuestionIds);
  function questionMatch(id, questionId) {
    if (!questions.has(id)) questions.set(id, { id, active: false, question: eligible.get(id).kind === "question", sourceIds: [],
      detail: "An explicit question or direct relationship to one; unresolved inquiry receives a discovery opportunity without answer or support inference." });
    const match = questions.get(id); match.active ||= active.has(questionId); match.sourceIds.push(questionId);
  }
  for (const node of nodes.filter((node) => node.kind === "question")) questionMatch(node.id, node.id);
  for (const edge of edges) {
    if (eligible.get(edge.from).kind === "question") questionMatch(edge.to, edge.from);
    if (eligible.get(edge.to).kind === "question") questionMatch(edge.from, edge.to);
  }
  route("question-linked", [...questions.values()].sort((a, b) => Number(b.active) - Number(a.active) || Number(b.question) - Number(a.question) || compare(a.id, b.id)), {
    notes: "Active question nominations first, then question nodes before linked nodes, then ID. All questions remain eligible; no automatic resolution or forgetting." });
  const degree = new Map(nodes.map((node) => [node.id, 0]));
  for (const edge of edges) { degree.set(edge.from, degree.get(edge.from) + 1); degree.set(edge.to, degree.get(edge.to) + 1); }
  const exploratory = route("exploratory", nodes.map((node) => ({ id: node.id, degree: degree.get(node.id),
    detail: "Low-connectivity exploration ordered by incident-edge count then ID; not novelty, popularity, truth or causal influence." }))
    .sort((a, b) => a.degree - b.degree || compare(a.id, b.id)), {
    notes: "Explicit low-connectivity route, not random or recency sampling. Bounded returns cannot guarantee discovery of every isolated/relevant record." });

  // Prefer exploratory-only discoveries for reserved slots; if none exist, use
  // the route's normal order. Every chosen item still has its actual route trace.
  const explorationOrder = [...exploratory].sort((a, b) =>
    Number(discoveries.get(a).some((reason) => reason.route !== "exploratory")) - Number(discoveries.get(b).some((reason) => reason.route !== "exploratory")) ||
    exploratory.indexOf(a) - exploratory.indexOf(b));
  const poolIds = [], poolSet = new Set();
  const addPool = (id) => { if (id && !poolSet.has(id) && poolIds.length < policy.maxCandidates) { poolSet.add(id); poolIds.push(id); } };
  explorationOrder.slice(0, policy.explorationSlots).forEach(addPool);
  for (const id of ["contradiction", "question-linked"]) addPool(routes.get(id).returnedRecordIds[0]);
  for (let index = 0; index < policy.perRouteLimit && poolIds.length < policy.maxCandidates; index++) {
    for (const id of MERGE_ORDER) addPool(routes.get(id).returnedRecordIds[index]);
  }

  const lineageCache = new Map();
  function lineage(id, visiting = new Set()) {
    if (lineageCache.has(id)) return lineageCache.get(id);
    if (visiting.has(id) || !eligible.has(id)) return { rootRecordIds: [], status: "incomplete" };
    visiting.add(id);
    const node = eligible.get(id), parents = [...node.derivedFrom, ...(node.revises === null ? [] : [node.revises])];
    let roots = [], complete = true;
    if (!parents.length) {
      roots = [id];
      // A local observation can be a declared origin of a description, never
      // independent confirmation. External/memory origins are not resolved by
      // this Field-only walk and must remain explicitly incomplete.
      complete = node.kind === "observation" && node.provenance.sourceType !== "memory" && node.provenance.references.length === 0;
    }
    for (const parent of parents) {
      const result = lineage(parent, visiting);
      roots.push(...result.rootRecordIds); complete &&= result.status === "declared-ancestry";
    }
    visiting.delete(id);
    const result = { rootRecordIds: sorted(roots.length ? roots : [id]), status: complete ? "declared-ancestry" : "incomplete" };
    lineageCache.set(id, result); return result;
  }
  const candidatePool = poolIds.map((id) => ({ recordId: id, reasons: discoveries.get(id).map((reason) => ({ ...reason })), selected: false,
    exclusionReason: "Selection budget exhausted; nonselection is not a judgment of falsity or irrelevance.", lineage: lineage(id) }));
  const candidates = new Map(candidatePool.map((candidate) => [candidate.recordId, candidate]));
  const selectedRecordIds = [], selected = new Set(), passRoots = new Set();
  const familyAvailable = (id) => !candidates.get(id).lineage.rootRecordIds.some((root) => passRoots.has(root));
  function select(id, routeId, reason) {
    if (!candidates.has(id) || selected.has(id) || selectedRecordIds.length >= policy.maxSelected) return false;
    const candidate = candidates.get(id);
    candidate.selected = true; candidate.exclusionReason = null;
    candidate.reasons.find((entry) => entry.route === routeId).detail += ` Selection: ${reason}; not epistemic support.`;
    selected.add(id); selectedRecordIds.push(id);
    candidate.lineage.rootRecordIds.forEach((root) => passRoots.add(root));
    return true;
  }
  function reserve(order, count, routeId, reason) {
    for (let i = 0; i < count; i++) {
      const available = order.filter((id) => candidates.has(id) && !selected.has(id));
      const id = available.find(familyAvailable) || available[0];
      if (!id || !select(id, routeId, reason)) break;
    }
  }
  reserve(explorationOrder, policy.explorationSlots, "exploratory", "reserved exploration opportunity");
  reserve(routes.get("contradiction").returnedRecordIds, 1, "contradiction", "reserved explicit-disagreement opportunity");
  reserve(routes.get("question-linked").returnedRecordIds, 1, "question-linked", "reserved question opportunity");
  while (selectedRecordIds.length < policy.maxSelected && selected.size < poolIds.length) {
    let progressed = false;
    for (const id of poolIds) {
      if (selected.has(id) || !familyAvailable(id)) continue;
      if (select(id, candidates.get(id).reasons[0].route, "balanced route discovery with declared-source-family deamplification")) progressed = true;
    }
    if (!progressed) passRoots.clear(); // Families may reappear only after this diversity pass is exhausted.
  }
  const selectedRoots = new Set(selectedRecordIds.flatMap((id) => candidates.get(id).lineage.rootRecordIds));
  for (const candidate of candidatePool) if (!candidate.selected && candidate.lineage.rootRecordIds.some((root) => selectedRoots.has(root))) {
    candidate.exclusionReason = "Selection budget exhausted; a selected record shares declared source ancestry. Repeated lineage is not independent confirmation.";
  }
  return validateRetrievalEvent({ schemaVersion: 1, vocabularyVersion: "aether-memory-v0.1", fieldStateId: command.fieldStateId,
    request, policy, routes: ROUTES.map((id) => routes.get(id)), candidatePool, selectedRecordIds,
    workingContext: { status: "not-applied", recordIds: [] }, ancestry,
    limits: [
      "Single selected-state ancestry only; unselected siblings and other Fields were not searched.",
      "Route returns are capped independently; the merged candidate pool is capped separately. Returned route IDs outside the pool were omitted by the merge cap, not judged irrelevant.",
      "Nonselection reasons describe discovered pool members only. Undiscovered relevance, global bias and starvation outside these bounds are unknown.",
      "Literal words, declared relationships and low-connectivity exploration are deterministic heuristics; semantic/embedding retrieval is not implemented.",
      "Lineages trace declared node ancestry only. Missing external origins remain incomplete; shared or distinct local roots never certify independent evidence.",
      "Source-family deamplification and reserved route opportunities affect attention selection, never stored status, confidence, truth or retention.",
      "Previous retrieval IDs are trace-only; they do not automatically nominate prior selections as evidence. No prompt was assembled or submitted and no model influence is claimed."
    ] });
}
