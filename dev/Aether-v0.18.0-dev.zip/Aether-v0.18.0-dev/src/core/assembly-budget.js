import { createHash } from "node:crypto";
import { Buffer } from "node:buffer";
import { validateFieldJson } from "./field.js";

const MAX_INTEGER = Number.MAX_SAFE_INTEGER;
function requireThat(condition, message) {
  if (!condition) throw Object.assign(new TypeError(`Assembly budget: ${message}`), { code: "INVALID_ASSEMBLY_BUDGET" });
}
function shape(value, keys, label) {
  requireThat(value !== null && typeof value === "object" && !Array.isArray(value), `${label} must be an object`);
  requireThat(Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), `${label} has missing or unknown fields`);
}
function integer(value, minimum, maximum, label) {
  requireThat(Number.isSafeInteger(value) && value >= minimum && value <= maximum, `${label} must be an integer ${minimum}..${maximum}`);
}
function method(value, kind) {
  shape(value, ["id", "version", "source"], "counter method");
  for (const key of ["id", "version", "source"]) {
    requireThat(kind === "unknown" ? value[key] === null : typeof value[key] === "string" && value[key].trim().length > 0,
      `counter method.${key} must be ${kind === "unknown" ? "null" : "a nonempty string"}`);
  }
}

export function validateAssemblyBudget(input) {
  const budget = validateFieldJson(input);
  shape(budget, ["maxPayloadBytes", "maxInputTokens", "contextWindowTokens", "reservedOutputTokens", "providerOverheadTokens"], "budget");
  integer(budget.maxPayloadBytes, 1, 16 * 1024 * 1024, "maxPayloadBytes");
  for (const key of ["maxInputTokens", "contextWindowTokens", "reservedOutputTokens", "providerOverheadTokens"]) {
    if (budget[key] !== null) integer(budget[key], 0, MAX_INTEGER, key);
  }
  return budget;
}

export const UNKNOWN_TOKEN_COUNTER = validateFieldJson({ kind: "unknown", method: { id: null, version: null, source: null } });
export const UTF8_ESTIMATE_COUNTER = Object.freeze({
  kind: "estimated",
  method: Object.freeze({ id: "utf8-bytes-divided-by-four", version: "1", source: "Heuristic ceil(UTF-8 bytes / 4); not a model tokenizer or a guaranteed upper bound." }),
  count: (text) => Math.ceil(Buffer.byteLength(text, "utf8") / 4)
});

// Functions are an explicit in-process caller dependency, never JSON metadata.
// Inspect descriptors before reading any supplied property; do not invoke getters.
function captureCounter(input) {
  requireThat(input !== null && typeof input === "object" && !Array.isArray(input) &&
    [Object.prototype, null].includes(Object.getPrototypeOf(input)), "counter must be a plain object");
  const captured = Object.create(null);
  for (const key of Reflect.ownKeys(input)) {
    requireThat(typeof key === "string" && ["kind", "method", "count"].includes(key), "counter has an unknown field");
    const descriptor = Object.getOwnPropertyDescriptor(input, key);
    requireThat(descriptor.enumerable && Object.hasOwn(descriptor, "value"), "counter properties must be enumerable data, not getters");
    captured[key] = descriptor.value;
  }
  requireThat(["estimated", "verified", "unknown"].includes(captured.kind), "counter kind is unsupported");
  const metadata = validateFieldJson({ kind: captured.kind, method: captured.method });
  method(metadata.method, metadata.kind);
  if (metadata.kind === "unknown") requireThat(!Object.hasOwn(captured, "count"), "unknown counter must omit count");
  else requireThat(typeof captured.count === "function", "known counter requires a count function");
  return Object.freeze({ ...metadata, count: captured.count });
}

// Measure the complete caller-provided representation, including wrappers and
// source metadata. Output reserve/extra provider overhead are accounted for below,
// not appended to this text. 'verified' is caller attestation, not an independent
// check of tokenizer identity, implementation, server behavior, or honesty.
export function measureAssemblyPayload(text, counter = UNKNOWN_TOKEN_COUNTER) {
  requireThat(typeof text === "string", "payload must be a string");
  const captured = captureCounter(counter);
  const bytes = Buffer.from(text, "utf8");
  const count = captured.count;
  const value = captured.kind === "unknown" ? null : count(text);
  if (captured.kind !== "unknown") integer(value, 0, MAX_INTEGER, "token counter result");
  return validateFieldJson({ bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex"),
    tokens: { value, kind: captured.kind, method: captured.method } });
}

function validateMeasurement(input) {
  const measurement = validateFieldJson(input);
  shape(measurement, ["bytes", "sha256", "tokens"], "measurement");
  integer(measurement.bytes, 0, MAX_INTEGER, "measurement.bytes");
  requireThat(typeof measurement.sha256 === "string" && /^[a-f0-9]{64}$/.test(measurement.sha256), "measurement.sha256 must be a lowercase SHA-256 digest");
  shape(measurement.tokens, ["value", "kind", "method"], "measurement.tokens");
  const { tokens } = measurement;
  requireThat(["estimated", "verified", "unknown"].includes(tokens.kind), "measurement token kind is unsupported");
  method(tokens.method, tokens.kind);
  if (tokens.kind === "unknown") requireThat(tokens.value === null, "unknown token count must be null");
  else integer(tokens.value, 0, MAX_INTEGER, "measurement.tokens.value");
  return measurement;
}

export function evaluateAssemblyBudget(input, limits) {
  const measurement = validateMeasurement(input), budget = validateAssemblyBudget(limits);
  const { tokens } = measurement;
  const hasContext = budget.contextWindowTokens !== null;
  const completeContext = hasContext && budget.reservedOutputTokens !== null && budget.providerOverheadTokens !== null;
  const contextCapacity = completeContext
    ? BigInt(budget.contextWindowTokens) - BigInt(budget.reservedOutputTokens) - BigInt(budget.providerOverheadTokens) : null;
  const inputCapacity = budget.maxInputTokens === null ? null : BigInt(budget.maxInputTokens);
  const effective = inputCapacity === null ? contextCapacity : contextCapacity === null || inputCapacity < contextCapacity ? inputCapacity : contextCapacity;
  const warnings = [];
  if (tokens.kind === "unknown") warnings.push("Token count is unknown; byte size does not establish model context capacity.");
  if (tokens.kind === "estimated") warnings.push("Token count is a heuristic estimate, not a verified tokenizer count or a guarantee that the target will accept the payload.");
  if (tokens.kind === "verified") warnings.push("Verified count is caller-attested; this library cannot verify tokenizer honesty, target compatibility, or provider processing.");
  if (hasContext && !completeContext) warnings.push("Context capacity remains unknown because output reserve or provider overhead is unknown; known contributions can only establish definite overflow.");
  if (!hasContext) warnings.push("Target context window is unknown; any input limit is a packing policy, not confirmed target capacity.");
  if (!hasContext && (budget.reservedOutputTokens !== null || budget.providerOverheadTokens !== null)) warnings.push("Declared output reserve/provider overhead cannot establish available capacity without a context window.");
  if (!hasContext && inputCapacity === null) warnings.push("No token capacity limit is known; fitting here means byte-bound packing only.");
  if (effective !== null && effective < 0n) warnings.push("Output reserve and provider overhead exceed the context window; even empty input cannot fit. Reported usable input capacity is zero.");
  warnings.push("No submission, provider-side truncation, processing, or model influence is established by this measurement.");

  let tokenReason = null, capacityStatus = "unknown";
  if (tokens.value === null) {
    if (hasContext || inputCapacity !== null) tokenReason = "token-count-unknown";
  } else {
    const count = BigInt(tokens.value);
    const definiteContextOverflow = hasContext && count + BigInt(budget.reservedOutputTokens ?? 0) + BigInt(budget.providerOverheadTokens ?? 0) > BigInt(budget.contextWindowTokens);
    if ((effective !== null && count > effective) || definiteContextOverflow) {
      tokenReason = "token-limit";
      capacityStatus = "exceeds-reported-count";
    } else if (effective !== null && (!hasContext || completeContext)) capacityStatus = "within-reported-count";
  }
  const reason = measurement.bytes > budget.maxPayloadBytes ? "byte-limit" : tokenReason;
  // Signed comparisons stay exact. Usable capacity cannot be negative, and
  // clamping it avoids imprecise JSON numbers for enormous reserve underflow.
  return validateFieldJson({ fits: reason === null, reason, effectiveInputTokenLimit: effective === null ? null : Number(effective < 0n ? 0n : effective), capacityStatus, warnings });
}
