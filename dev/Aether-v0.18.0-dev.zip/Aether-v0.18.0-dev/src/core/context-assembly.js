import { validateFieldJson } from "./field.js";
import { validateAssemblyBudget, measureAssemblyPayload, evaluateAssemblyBudget, UNKNOWN_TOKEN_COUNTER } from "./assembly-budget.js";
import { ASSEMBLY_VERSION, DEFAULT_ASSEMBLY_POLICY, assemblyReferences, transformationPath,
  serializeAssemblyPayload, validateAssemblyEvent, validateAssemblyField, materializeAssembly } from "./assembly-events.js";

export { DEFAULT_ASSEMBLY_POLICY };

// This builds an inert, canonical artifact. It deliberately does not call a
// provider, modify an earlier RetrievalEvent, or inject anything into live chat.
export function buildContextAssembly(input, request, counter = UNKNOWN_TOKEN_COUNTER) {
  const command = validateFieldJson(request);
  const keys = ["fieldStateId", "retrievalEventIds", "target", "policy", "currentSegments", "budget", "representations", "transformations"];
  if (!command || typeof command !== "object" || Array.isArray(command) ||
      Object.keys(command).length !== keys.length || !keys.every((key) => Object.hasOwn(command, key))) {
    throw new TypeError("Assembly command has missing or unknown fields");
  }
  const budget = validateAssemblyBudget(command.budget);
  if (command.policy?.id !== DEFAULT_ASSEMBLY_POLICY.id || command.policy.version !== DEFAULT_ASSEMBLY_POLICY.version ||
      !["retrieval", "reverse"].includes(command.policy.order)) {
    throw new TypeError("Unsupported assembly policy implementation");
  }
  const { snapshot, nodes, orderedRecordIds, retrievalIdsByRecord } = assemblyReferences(validateAssemblyField(input), command);
  const order = command.policy.order === "reverse" ? [...orderedRecordIds].reverse() : orderedRecordIds;
  const replacements = new Map(command.representations.map((entry) => [entry.recordId, entry.representationRecordId]));
  const draft = {
    schemaVersion: 1, vocabularyVersion: ASSEMBLY_VERSION,
    fieldStateId: command.fieldStateId, retrievalEventIds: command.retrievalEventIds,
    target: command.target, policy: command.policy, currentSegments: command.currentSegments,
    budget, transformations: command.transformations, candidates: [], segments: [], outcome: "assembled",
    measurement: null, budgetEvaluation: null, limitations: [],
    submission: { status: "not-attempted", providerProcessing: "unknown", influence: "unknown" }
  };
  const measure = () => measureAssemblyPayload(serializeAssemblyPayload(nodes, draft), counter);
  draft.measurement = measure();
  draft.budgetEvaluation = evaluateAssemblyBudget(draft.measurement, budget);
  if (!draft.budgetEvaluation.fits) draft.outcome = "blocked";
  for (const [index, recordId] of order.entries()) {
    const representationRecordId = replacements.get(recordId) ?? recordId;
    const transformationIds = transformationPath(nodes, command.transformations, recordId, representationRecordId);
    const candidate = {
      recordId, retrievalEventIds: retrievalIdsByRecord.get(recordId), representationRecordId, transformationIds,
      decision: "omitted", reason: "base-blocked", segmentId: null
    };
    if (draft.outcome === "assembled") {
      const segment = { id: `memory-${index + 1}`, sourceRecordId: recordId, representationRecordId,
        role: "historical-data", trust: "untrusted", transformationIds };
      draft.segments.push(segment);
      const measurement = measure(), evaluation = evaluateAssemblyBudget(measurement, budget);
      if (evaluation.fits) {
        candidate.decision = representationRecordId === recordId ? "included" : "transformed";
        candidate.reason = null; candidate.segmentId = segment.id;
        draft.measurement = measurement; draft.budgetEvaluation = evaluation;
      } else {
        draft.segments.pop(); candidate.reason = evaluation.reason;
      }
    }
    draft.candidates.push(candidate);
  }
  const omitted = draft.candidates.filter((item) => item.decision === "omitted").length;
  draft.limitations = [...new Set([
    "Only selected candidates from the named RetrievalEvents were considered; neither retrieval nor assembly guarantees completeness or relevance.",
    `${omitted} of ${draft.candidates.length} considered candidates were omitted; incompleteness is explicit and not a truth judgment.`,
    "Whole representations are packed in declared policy order; this deterministic policy does not detect semantic loss, balance support against contradiction, or guarantee exploratory coverage.",
    "The complete canonical artifact includes current instructions, conversation/tool data, history, provenance and JSON wrappers. Provider-specific adaptation, tokenization and hidden template overhead remain separately unknown unless supplied.",
    "This artifact has not been submitted. Provider acceptance, truncation, processing, model attention, influence and causal explanations are unknown.",
    "Historical instructions and tool commands remain untrusted data; tagging alone is not a guarantee against model prompt injection.",
    "Latency, compute, monetary cost and modality feasibility are not measured or optimized by this text-only assembly policy.",
    ...draft.budgetEvaluation.warnings,
    ...command.transformations.flatMap((item) => item.limitations.map((limit) => `Transformation ${item.outputRecordId}: ${limit}`))
  ])];
  const event = validateAssemblyEvent(draft);
  if (event.outcome === "assembled") materializeAssembly(snapshot, event);
  return event;
}
