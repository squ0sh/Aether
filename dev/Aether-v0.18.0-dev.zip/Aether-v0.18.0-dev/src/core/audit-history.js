// Conservative role classification, not payload validation. Even an unknown or
// malformed own audit marker must not turn into ordinary candidate evidence.
// Dedicated event readers remain responsible for validating each event payload.
export function isAuditNode(record) {
  const extensions = record?.extensions;
  return Boolean(extensions && typeof extensions === "object" &&
    (Object.hasOwn(extensions, "aether:retrieval") || Object.hasOwn(extensions, "aether:assembly")));
}
