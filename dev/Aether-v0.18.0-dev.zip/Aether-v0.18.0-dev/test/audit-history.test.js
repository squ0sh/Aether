import test from "node:test";
import assert from "node:assert/strict";
import { createProvenance, validateFieldSnapshot } from "../src/core/field.js";
import { createField, applyFieldChange } from "../src/core/field-operations.js";
import { isAuditNode } from "../src/core/audit-history.js";
import { buildRetrievalDecision, DEFAULT_RETRIEVAL_POLICY } from "../src/core/retrieval.js";
import { addRetrievalEvent, readRetrievalEvents, validateRetrievalField } from "../src/core/retrieval-events.js";
import { addStructuralInterpretation, readStructuralInterpretations, validateStructuralField } from "../src/core/structural-field.js";

const createdAt = "2026-09-16T00:00:00.000Z";
const provenance = createProvenance({ sourceType: "human", sourceId: "reviewer", method: "synthetic audit-role test" });
const copy = (value) => JSON.parse(JSON.stringify(value));
const decision = (snapshot, stateId, ancestry = { previousRetrievalEventIds: [], attentionSourceIds: [] }) => buildRetrievalDecision(snapshot, {
  fieldStateId: stateId, request: { query: "blue", context: "", activeQuestionIds: ["question"] }, policy: DEFAULT_RETRIEVAL_POLICY, ancestry
});
const remember = (snapshot, event) => addRetrievalEvent(snapshot, {
  parentStateId: event.fieldStateId, stateId: "next-retrieval", nodeId: "next-event", createdAt, provenance, event
});
function fixture() {
  const initial = createField({ id: "audit-field", initialStateId: "root", createdAt, provenance });
  const sources = applyFieldChange(initial, { parentStateId: "root", stateId: "sources", createdAt, provenance, actions: [
    { type: "add-node", record: { id: "raw", kind: "observation", content: { format: "text/plain", text: "The sample appears blue." } } },
    { type: "add-node", record: { id: "question", kind: "question", content: { format: "text/plain", text: "Is the sample blue?" } } }
  ] });
  const retrieved = addRetrievalEvent(sources, { parentStateId: "sources", stateId: "retrieved", nodeId: "retrieval", createdAt, provenance,
    event: decision(sources, "sources") });
  // Deliberately opaque placeholder: role exclusion must not depend on a valid
  // AssemblyEvent payload. The assembly-specific suite owns payload validation.
  const assembled = applyFieldChange(retrieved, { parentStateId: "retrieved", stateId: "assembled", createdAt, provenance, actions: [
    { type: "add-node", record: { id: "assembly", kind: "observation", content: { format: "text/plain", text: "Blue blue blue: audit text is not more evidence." },
      derivedFrom: ["raw", "retrieval"], extensions: { "aether:assembly": { opaqueTestPlaceholder: true } } } },
    { type: "add-edge", record: { id: "audit-question", from: "question", to: "assembly", relation: "responds_to" } },
    { type: "add-edge", record: { id: "audit-contradiction", from: "assembly", to: "raw", relation: "contradicts" } }
  ] });
  return { sources, retrieved, assembled };
}
function interpretation(sourceId) {
  return { schemaVersion: 1, vocabularyVersion: "aether-structural-v0.1", outcome: "unrepresentable", sourceNodeIds: [sourceId],
    context: { scope: "synthetic test", scale: "single record", conditions: "explicit request", referenceFrame: "declared source" },
    structures: [], limits: ["No semantic verification"], counterexamples: ["A missing ordinary observation"], unrepresentableReason: "No structural claim proposed" };
}
const interpret = (snapshot, stateId, sourceId) => addStructuralInterpretation(snapshot, {
  parentStateId: stateId, stateId: "interpreted", nodeId: "interpretation", createdAt, provenance, summary: "Attributed description only", interpretation: interpretation(sourceId)
});

test("audit classification recognizes own retrieval and assembly markers without claiming payload validity", () => {
  for (const marker of ["aether:retrieval", "aether:assembly"]) {
    for (const payload of [null, {}, { version: "unknown" }]) assert.equal(isAuditNode({ extensions: { [marker]: payload } }), true);
    assert.equal(isAuditNode({ extensions: Object.create({ [marker]: {} }) }), false);
  }
  for (const record of [null, undefined, {}, { extensions: null }, { extensions: {} }, { extensions: { "aether:capture": {} } }]) {
    assert.equal(isAuditNode(record), false);
  }
});

test("assembly and retrieval audit nodes cannot enter any retrieval discovery route or change ordinary source ranking", () => {
  const { sources, assembled } = fixture(), before = JSON.stringify(assembled);
  const baseline = decision(sources, "sources"), result = decision(assembled, "assembled", { previousRetrievalEventIds: ["retrieval"], attentionSourceIds: ["raw"] });
  const unseeded = decision(assembled, "assembled");
  assert.deepEqual(unseeded.candidatePool, baseline.candidatePool);
  assert.deepEqual(unseeded.selectedRecordIds, baseline.selectedRecordIds);
  for (const route of result.routes) for (const id of route.returnedRecordIds) assert.ok(!["retrieval", "assembly"].includes(id));
  for (const candidate of result.candidatePool) {
    assert.ok(!["retrieval", "assembly"].includes(candidate.recordId));
    for (const id of [...candidate.lineage.rootRecordIds, ...candidate.reasons.flatMap((reason) => reason.sourceIds)]) {
      assert.ok(!["retrieval", "assembly"].includes(id));
    }
  }
  assert.deepEqual(result.ancestry.previousRetrievalEventIds, ["retrieval"]);
  assert.equal(JSON.stringify(assembled), before);
});

test("audit reads remain explicit and assembly cannot masquerade as previous retrieval or attention", () => {
  const { assembled } = fixture();
  assert.deepEqual(readRetrievalEvents(assembled, "assembled").map((node) => node.id), ["retrieval"]);
  assert.deepEqual(readStructuralInterpretations(assembled, "assembled"), []);
  for (const id of ["retrieval", "assembly"]) {
    assert.throws(() => decision(assembled, "assembled", { previousRetrievalEventIds: [], attentionSourceIds: [id] }), /non-event/);
  }
  assert.throws(() => decision(assembled, "assembled", { previousRetrievalEventIds: ["assembly"], attentionSourceIds: [] }), /Previous retrieval/);
  const event = copy(decision(assembled, "assembled")); event.ancestry.previousRetrievalEventIds = ["assembly"];
  assert.throws(() => remember(assembled, event), /RetrievalEvent/);
});

test("imported retrieval roles reject assembly candidates, attention, reason sources and lineage roots", () => {
  const { assembled } = fixture();
  const mutations = [
    (event) => { event.ancestry.attentionSourceIds = ["assembly"]; },
    (event) => { event.candidatePool[0].lineage.rootRecordIds = ["assembly"]; },
    (event) => { event.candidatePool[0].reasons[0].sourceIds = ["assembly"]; },
    (event) => {
      const original = event.candidatePool[0].recordId;
      event.candidatePool[0].recordId = "assembly";
      event.selectedRecordIds = event.selectedRecordIds.map((id) => id === original ? "assembly" : id);
      for (const route of event.routes) route.returnedRecordIds = route.returnedRecordIds.map((id) => id === original ? "assembly" : id);
    }
  ];
  for (const mutate of mutations) {
    const event = copy(decision(assembled, "assembled")); mutate(event);
    assert.throws(() => remember(assembled, event), /ordinary attributed|prior-event trace|candidate evidence/);
  }
});

test("generic revision operations protect both audit types even when callers remove the marker", () => {
  const { assembled } = fixture(), before = JSON.stringify(assembled);
  for (const targetId of ["retrieval", "assembly"]) {
    assert.throws(() => applyFieldChange(assembled, { parentStateId: "assembled", stateId: "rewrite", createdAt, provenance,
      actions: [{ type: "revise-node", targetId, record: { id: "rewritten", extensions: {}, kind: "observation" } }] }), /Audit events cannot be revised/);
  }
  assert.equal(JSON.stringify(assembled), before);
});

test("structural and retrieval readers reject opaque imported revisions of either audit type", () => {
  for (const targetId of ["retrieval", "assembly"]) {
    const imported = copy(fixture().assembled), previous = imported.nodes.find((node) => node.id === targetId);
    const revision = { ...copy(previous), id: "forged-revision", revises: targetId, extensions: {} };
    imported.nodes.push(revision);
    const parent = imported.states.at(-1);
    imported.states.push({ ...copy(parent), id: "forged-state", parentStateIds: [parent.id], nodeIds: [...parent.nodeIds, revision.id] });
    assert.doesNotThrow(() => validateFieldSnapshot(imported));
    for (const validate of [validateStructuralField, validateRetrievalField]) assert.throws(() => validate(imported), /cannot be revised/);
    assert.throws(() => readStructuralInterpretations(imported, "forged-state"), /cannot be revised/);
    assert.throws(() => readRetrievalEvents(imported, "forged-state"), /cannot be revised/);
  }
});

test("structural sources cannot directly promote audit observations into structural evidence", () => {
  const { assembled } = fixture(), before = JSON.stringify(assembled);
  for (const id of ["retrieval", "assembly"]) assert.throws(() => interpret(assembled, "assembled", id), /observation nodes, not audit history/);
  const valid = interpret(assembled, "assembled", "raw");
  for (const id of ["retrieval", "assembly"]) {
    const imported = copy(valid), record = imported.nodes.at(-1);
    record.derivedFrom = [id]; record.extensions["aether:structural"].sourceNodeIds = [id];
    assert.doesNotThrow(() => validateFieldSnapshot(imported));
    assert.throws(() => validateStructuralField(imported), /not audit history/);
  }
  assert.equal(JSON.stringify(assembled), before);
});

test("co-marking an interpretation or retrieval record as assembly cannot bypass separate audit roles", () => {
  const { assembled } = fixture();
  const structural = copy(interpret(assembled, "assembled", "raw"));
  structural.nodes.at(-1).extensions["aether:assembly"] = {};
  assert.throws(() => validateStructuralField(structural), /separate from raw observations and audit history/);
  const retrieval = copy(assembled);
  retrieval.nodes.find((node) => node.id === "retrieval").extensions["aether:assembly"] = {};
  assert.throws(() => validateRetrievalField(retrieval), /separate from capture, interpretation and assembly/);
});

test("ordinary attributed observations may retain audit provenance but their lineage is incomplete", () => {
  const { assembled } = fixture();
  const output = applyFieldChange(assembled, { parentStateId: "assembled", stateId: "output", createdAt, provenance, actions: [
    { type: "add-node", record: { id: "output-observation", kind: "observation", content: { format: "text/plain", text: "Blue was mentioned in a new attributed output." }, derivedFrom: ["assembly"] } }
  ] });
  const event = decision(output, "output"), candidate = event.candidatePool.find((item) => item.recordId === "output-observation");
  assert.equal(candidate.lineage.status, "incomplete");
  assert.ok(!candidate.lineage.rootRecordIds.includes("assembly"));
  assert.deepEqual(output.nodes.at(-1).derivedFrom, ["assembly"]);
  assert.doesNotThrow(() => interpret(output, "output", "output-observation"));
  assert.equal(output.nodes.at(-1).confidence.value, null);
});
