import test from "node:test";
import assert from "node:assert/strict";
import { buildRetrievalDecision, DEFAULT_RETRIEVAL_POLICY } from "../src/core/retrieval.js";
import { addRetrievalEvent, validateRetrievalEvent } from "../src/core/retrieval-events.js";
import { STRUCTURAL_EXTENSION } from "../src/core/structural-vocabulary.js";
import { authoredAt, author, copy, observation, node, edge, modelAuthor, append, authoredField, structuralCase } from "./fixtures/retrieval-cases.js";

const poolItem = (decision, id) => decision.candidatePool.find((item) => item.recordId === id);
const route = (decision, id) => decision.routes.find((item) => item.id === id);
const rawNode = (fixture, id) => fixture.snapshot.nodes.find((item) => item.id === id);
const interpretedTerm = (fixture, id, term) => rawNode(fixture, id).extensions[STRUCTURAL_EXTENSION].structures.find((item) => item.term === term);
const selected = (decision, id) => decision.selectedRecordIds.includes(id);
const emptyAncestry = () => ({ previousRetrievalEventIds: [], attentionSourceIds: [] });

// Each call asserts immutability and exact reproducibility alongside its specific
// adversary. Discovery/selection is observable; semantic truth is not asserted.
function decide(fixture, request = {}, policy = {}, ancestry = emptyAncestry()) {
  const before = JSON.stringify(fixture.snapshot);
  const command = {
    fieldStateId: fixture.stateId,
    request: { query: "signal", activeQuestionIds: [], context: "", ...request },
    policy: { ...DEFAULT_RETRIEVAL_POLICY, maxCandidates: 64, maxSelected: 16, perRouteLimit: 64, ...policy },
    ancestry
  };
  const result = buildRetrievalDecision(fixture.snapshot, command);
  assert.deepEqual(validateRetrievalEvent(result), result);
  assert.deepEqual(buildRetrievalDecision(fixture.snapshot, command), result);
  assert.equal(JSON.stringify(fixture.snapshot), before);
  assert.ok(Object.isFrozen(result) && Object.isFrozen(result.candidatePool));
  assert.deepEqual(result.workingContext, { status: "not-applied", recordIds: [] });
  assert.equal(result.routes.length, 6);
  for (const candidate of result.candidatePool) {
    assert.equal(candidate.selected, selected(result, candidate.recordId));
    if (candidate.selected) assert.equal(candidate.exclusionReason, null);
    else assert.ok(typeof candidate.exclusionReason === "string" && candidate.exclusionReason.length > 0);
  }
  return result;
}

function remember(fixture, event, id) {
  const stateId = `remembered-${id}`;
  return {
    snapshot: addRetrievalEvent(fixture.snapshot, { parentStateId: fixture.stateId, stateId, nodeId: id, createdAt: authoredAt, provenance: author, event }),
    stateId
  };
}

test("01 copied misinformation retains one declared ancestry instead of becoming independent confirmations", () => {
  const fixture = authoredField("copies", [
    [observation("original", "signal claim from one fictional publication")],
    [node("copy-a", "inference", "signal repeated by model A", { derivedFrom: ["original"], provenance: modelAuthor("A") }), node("copy-b", "inference", "signal repeated by model B", { derivedFrom: ["original"], provenance: modelAuthor("B") })]
  ]);
  const event = decide(fixture);
  for (const id of ["copy-a", "copy-b"]) {
    assert.deepEqual(poolItem(event, id).lineage.rootRecordIds, ["original"]);
    assert.equal(poolItem(event, id).lineage.status, "declared-ancestry");
  }
  assert.equal(fixture.snapshot.edges.length, 0);
  assert.ok(fixture.snapshot.nodes.every((item) => item.status === "open" && item.confidence.value === null));
});

test("02 attention echo records its earlier event without retrieving that event as fresh evidence", () => {
  let fixture = authoredField("attention-echo", [[observation("nominated", "signal attention nomination"), observation("alternative", "signal alternative account")]]);
  const first = decide(fixture, {}, {}, { previousRetrievalEventIds: [], attentionSourceIds: ["nominated"] });
  fixture = remember(fixture, first, "retrieval-first");
  const stored = copy(rawNode(fixture, "retrieval-first"));
  const next = decide(fixture, {}, {}, { previousRetrievalEventIds: ["retrieval-first"], attentionSourceIds: ["nominated"] });
  assert.deepEqual(next.ancestry, { previousRetrievalEventIds: ["retrieval-first"], attentionSourceIds: ["nominated"] });
  assert.equal(poolItem(next, "retrieval-first"), undefined);
  assert.ok(route(next, "ancestry").returnedRecordIds.includes("nominated"));
  assert.deepEqual(rawNode(fixture, "retrieval-first"), stored);
});

test("03 an explicitly contradictory observation has a route despite a confident model preference", () => {
  const fixture = authoredField("wrong-model", [[
    node("preferred-model", "hypothesis", "signal model answer says the switch is closed", { provenance: modelAuthor("favorite"), confidence: { value: 0.99, basis: "fictional model self-assessment" } }),
    observation("contrary-reading", "meter records an open circuit"),
    edge("contrary-link", "contrary-reading", "preferred-model", "contradicts")
  ]]);
  const event = decide(fixture, {}, { maxSelected: 3, explorationSlots: 1 });
  assert.ok(route(event, "contradiction").returnedRecordIds.includes("contrary-reading"));
  assert.ok(selected(event, "contrary-reading"));
  assert.deepEqual(rawNode(fixture, "preferred-model").confidence, { value: 0.99, basis: "fictional model self-assessment" });
  assert.equal(rawNode(fixture, "contrary-reading").confidence.value, null);
});

test("04 old contradictions remain discoverable rather than decaying out of history", () => {
  let fixture = authoredField("old-contradiction", [[node("old-theory", "hypothesis", "former circuit account"), observation("old-counterexample", "older counterexample"), edge("old-conflict", "old-counterexample", "old-theory", "contradicts")]]);
  fixture = append(fixture, [observation("new-note", "signal recent but unrelated comment")], { createdAt: "2026-09-15T00:00:00.000Z" });
  const event = decide(fixture);
  assert.ok(route(event, "contradiction").returnedRecordIds.includes("old-counterexample"));
  assert.ok(selected(event, "old-counterexample"));
  assert.equal(rawNode(fixture, "old-counterexample").createdAt, authoredAt);
});

test("05 novelty and attention nominations do not promote an exciting claim over its explicit limitation", () => {
  const fixture = authoredField("novelty", [[
    node("exciting", "hypothesis", "signal spectacular new universal solution"),
    observation("limitation", "the example fails for the supplied boundary input"),
    edge("limited", "limitation", "exciting", "contradicts")
  ]]);
  const event = decide(fixture, {}, { maxSelected: 3, explorationSlots: 1 }, { previousRetrievalEventIds: [], attentionSourceIds: ["exciting"] });
  assert.ok(selected(event, "limitation"));
  assert.ok(poolItem(event, "exciting"));
  assert.equal(rawNode(fixture, "exciting").status, "open");
  assert.equal(rawNode(fixture, "exciting").confidence.value, null);
});

test("06 recency alone does not change deterministic selection of otherwise identical candidates", () => {
  const fixture = authoredField("recency", [[observation("a-earlier", "signal equally matched account"), observation("b-later", "signal equally matched account"), observation("c-other", "signal equally matched account")]]);
  const event = decide(fixture, {}, { maxSelected: 1, explorationSlots: 0 });
  const changed = copy(fixture);
  rawNode(changed, "a-earlier").createdAt = "2020-01-01T00:00:00.000Z";
  rawNode(changed, "b-later").createdAt = "2030-01-01T00:00:00.000Z";
  const later = decide(changed, {}, { maxSelected: 1, explorationSlots: 0 });
  assert.deepEqual(later.selectedRecordIds, event.selectedRecordIds);
  assert.deepEqual(later.candidatePool.map((item) => item.recordId), event.candidatePool.map((item) => item.recordId));
});

test("07 a highly connected hub does not consume the reserved low-connectivity exploration slot", () => {
  const fixture = authoredField("dominance", [[
    node("hub", "abstraction", "signal repeatedly connected account"),
    ...Array.from({ length: 8 }, (_, i) => observation(`leaf-${i}`, `signal linked note ${i}`)),
    observation("z-isolated", "a quiet unmatched boundary observation"),
    ...Array.from({ length: 8 }, (_, i) => edge(`hub-${i}`, "hub", `leaf-${i}`, "contains"))
  ]]);
  const event = decide(fixture, {}, { maxSelected: 3, explorationSlots: 1 });
  assert.equal(route(event, "exploratory").returnedRecordIds[0], "z-isolated");
  assert.ok(selected(event, "z-isolated"));
  assert.equal(rawNode(fixture, "hub").confidence.value, null);
});

test("08 retrieving an analogy preserves its criterion and differing mechanisms", () => {
  let fixture = authoredField("analogy", [[observation("diagrams", "two authored three-node diagrams")]]);
  fixture = structuralCase(fixture, "same-topology-different-mechanisms", "analogy-reading", ["diagrams"]);
  const original = copy(interpretedTerm(fixture, "analogy-reading", "analogy"));
  const event = decide(fixture, { query: "mechanisms" });
  assert.ok(route(event, "structural").returnedRecordIds.includes("analogy-reading"));
  assert.ok(selected(event, "analogy-reading"));
  assert.equal(original.attributes.mechanismEquivalence, "not-implied");
  assert.ok(original.attributes.retainedDifferences.includes("fluid transport versus discrete messages"));
  assert.deepEqual(interpretedTerm(fixture, "analogy-reading", "analogy"), original);
});

test("09 self-referential attention chains expose the same root instead of inventing new origins", () => {
  const fixture = authoredField("self-reference", [
    [observation("root-observation", "original fictional note")],
    [node("first-summary", "abstraction", "signal summary", { derivedFrom: ["root-observation"] })],
    [node("summary-of-summary", "abstraction", "signal summary of the summary", { derivedFrom: ["first-summary"] })]
  ]);
  const event = decide(fixture, {}, {}, { previousRetrievalEventIds: [], attentionSourceIds: ["summary-of-summary"] });
  assert.deepEqual(poolItem(event, "summary-of-summary").lineage.rootRecordIds, ["root-observation"]);
  assert.deepEqual(poolItem(event, "first-summary").lineage.rootRecordIds, ["root-observation"]);
  assert.ok(route(event, "ancestry").returnedRecordIds.includes("root-observation"));
  assert.equal(fixture.snapshot.edges.length, 0);
});

test("10 an active persistent question is discoverable without a lexical query or fabricated answer", () => {
  const fixture = authoredField("persistent-question", [[
    node("question", "question", "Which boundary condition was omitted?", { status: "unresolved" }),
    node("tentative-answer", "hypothesis", "Perhaps a finite-domain assumption"),
    edge("answer-link", "tentative-answer", "question", "responds_to")
  ]]);
  const event = decide(fixture, { query: "", activeQuestionIds: ["question"] }, { maxSelected: 2, explorationSlots: 0 });
  assert.ok(route(event, "question-linked").returnedRecordIds.includes("question"));
  assert.ok(route(event, "question-linked").returnedRecordIds.includes("tentative-answer"));
  assert.ok(selected(event, "question"));
  assert.equal(rawNode(fixture, "question").status, "unresolved");
});

test("11 equal endpoint retrieval keeps distinct histories and the comparison criteria", () => {
  let fixture = authoredField("path-history", [[observation("ledgers", "two fictional ledgers end at balance ten")]]);
  fixture = structuralCase(fixture, "same-endpoint-different-histories", "history-reading", ["ledgers"]);
  const event = decide(fixture, { query: "histories" });
  assert.ok(route(event, "structural").returnedRecordIds.includes("history-reading"));
  const paths = interpretedTerm(fixture, "history-reading", "path-dependence").attributes;
  assert.deepEqual(paths.histories, ["ten to fifteen to ten", "ten to eight to ten"]);
  assert.equal(paths.historyEquivalence, "different-under-criterion");
  assert.notEqual(paths.endpointCriterion, paths.historyCriterion);
});

test("12 absent and not-observed remain distinct retrieved interpretations with bounded coverage", () => {
  let fixture = authoredField("absence", [[observation("assay", "one fictional tracer assay")]]);
  fixture = structuralCase(fixture, "cell-membrane", "not-observed", ["assay"]);
  fixture = structuralCase(fixture, "cell-membrane", "bounded-absence", ["assay"], (payload) => {
    const absence = payload.structures.find((item) => item.term === "absence");
    absence.attributes = { status: "observed-absent", method: "stated fictional tracer assay", coverage: "one sampled compartment during one interval" };
  });
  const event = decide(fixture, { query: "absence" });
  for (const id of ["not-observed", "bounded-absence"]) assert.ok(route(event, "structural").returnedRecordIds.includes(id));
  assert.equal(interpretedTerm(fixture, "not-observed", "absence").attributes.status, "not-observed");
  assert.equal(interpretedTerm(fixture, "bounded-absence", "absence").attributes.coverage, "one sampled compartment during one interval");
});

test("13 a failed prediction retains its counterexample without silently rewriting the prediction", () => {
  const fixture = authoredField("prediction", [[
    node("prediction", "hypothesis", "signal prediction says output will be one"),
    observation("failed-trial", "the authored trial returned zero"),
    edge("failure", "failed-trial", "prediction", "contradicts")
  ]]);
  const before = copy(rawNode(fixture, "prediction"));
  const event = decide(fixture);
  assert.ok(route(event, "contradiction").returnedRecordIds.includes("failed-trial"));
  assert.ok(selected(event, "failed-trial"));
  assert.deepEqual(rawNode(fixture, "prediction"), before);
  assert.equal(rawNode(fixture, "prediction").status, "open");
});

test("14 a subsuming abstraction does not overwrite the narrow account or its source", () => {
  const fixture = authoredField("subsumption", [
    [observation("original", "fictional measurement in the narrow case")],
    [node("narrow", "hypothesis", "restricted account", { derivedFrom: ["original"] })],
    [node("broad", "abstraction", "summarykey proposed broader account", { derivedFrom: ["narrow"] }), edge("subsumes", "broad", "narrow", "contains")]
  ]);
  const event = decide(fixture, { query: "summarykey" });
  assert.ok(route(event, "ancestry").returnedRecordIds.includes("narrow"));
  assert.ok(route(event, "ancestry").returnedRecordIds.includes("original"));
  assert.deepEqual(poolItem(event, "broad").lineage.rootRecordIds, ["original"]);
  assert.equal(rawNode(fixture, "narrow").content.text, "restricted account");
});

test("15 a broader theory remains revisable and both attributed versions remain candidates", () => {
  let fixture = authoredField("revision", [[node("theory-v1", "hypothesis", "signal theory for all supplied inputs")]]);
  fixture = append(fixture, [{ type: "revise-node", targetId: "theory-v1", record: { id: "theory-v2", content: { format: "text/plain", text: "signal theory only for bounded inputs" } } }]);
  const event = decide(fixture);
  assert.ok(poolItem(event, "theory-v1") && poolItem(event, "theory-v2"));
  assert.equal(rawNode(fixture, "theory-v2").revises, "theory-v1");
  assert.equal(rawNode(fixture, "theory-v1").content.text, "signal theory for all supplied inputs");
  assert.equal(rawNode(fixture, "theory-v1").status, "open");
  assert.equal(rawNode(fixture, "theory-v2").status, "open");
});

test("16 identical query wording does not merge incompatible scopes", () => {
  const fixture = authoredField("scope", [[
    node("cold", "hypothesis", "signal material remains rigid", { context: "fictional low-temperature regime" }),
    node("hot", "hypothesis", "signal material flows", { context: "fictional high-temperature regime" })
  ]]);
  const event = decide(fixture);
  assert.ok(poolItem(event, "cold") && poolItem(event, "hot"));
  assert.equal(rawNode(fixture, "cold").context, "fictional low-temperature regime");
  assert.equal(rawNode(fixture, "hot").context, "fictional high-temperature regime");
  assert.equal(fixture.snapshot.edges.length, 0);
});

test("17 a source remains recoverable through ancestry when only its abstraction matches", () => {
  const fixture = authoredField("source-recovery", [
    [observation("verbatim", "  original wording\nwith spacing and 🔵 retained  ", { extensions: { "aether:capture": { fixture: "raw text marker; no semantic authority" } } })],
    [node("summary", "abstraction", "summarykey compressed account", { derivedFrom: ["verbatim"] })]
  ]);
  const original = JSON.stringify(rawNode(fixture, "verbatim"));
  const event = decide(fixture, { query: "summarykey" });
  assert.ok(!route(event, "lexical").returnedRecordIds.includes("verbatim"));
  assert.ok(route(event, "ancestry").returnedRecordIds.includes("verbatim"));
  assert.ok(selected(event, "verbatim"));
  assert.equal(JSON.stringify(rawNode(fixture, "verbatim")), original);
});

test("18 repeated nonselection exposes bounded candidate starvation without deleting the candidate", () => {
  let fixture = authoredField("starvation", [[observation("a-selected", "signal first tie"), observation("b-starved", "signal second tie"), observation("c-starved", "signal third tie")]]);
  const events = [];
  for (let index = 0; index < 3; index++) {
    const event = decide(fixture, {}, { maxSelected: 1, explorationSlots: 0 }, { previousRetrievalEventIds: index ? [`audit-${index - 1}`] : [], attentionSourceIds: [] });
    events.push(event); fixture = remember(fixture, event, `audit-${index}`);
  }
  const neverSelected = events[0].candidatePool.find((item) => !item.selected).recordId;
  assert.ok(events.every((event) => poolItem(event, neverSelected) && !poolItem(event, neverSelected).selected && poolItem(event, neverSelected).exclusionReason));
  assert.ok(rawNode(fixture, neverSelected));
  assert.deepEqual(rawNode(fixture, "audit-0").extensions["aether:retrieval"], events[0]);
});

test("19 route truncation shows bounded blindness, not a claim that unseen candidates are irrelevant", () => {
  const fixture = authoredField("blindness", [[
    observation("a-visible", "signal first account"), observation("b-hidden", "signal second account"), observation("z-hidden", "signal last account")
  ]]);
  const event = decide(fixture, {}, { maxCandidates: 1, maxSelected: 1, perRouteLimit: 1, explorationSlots: 0 });
  assert.equal(route(event, "lexical").status, "bounded");
  assert.equal(route(event, "lexical").matchedCount, 3);
  assert.equal(route(event, "lexical").returnedRecordIds.length, 1);
  assert.equal(poolItem(event, "z-hidden"), undefined);
  assert.ok(event.limits.some((limit) => /bound|truncat|cap|semantic/i.test(limit)));
  assert.ok(rawNode(fixture, "z-hidden"));
});

test("20 policy settings stay auditable and unsupported future execution cannot rewrite old decisions", () => {
  const fixture = authoredField("policy-history", [[observation("a", "signal first"), observation("b", "signal second")]]);
  const small = decide(fixture, {}, { maxSelected: 1, explorationSlots: 0 });
  const before = JSON.stringify(small);
  const larger = decide(fixture, {}, { maxSelected: 2, explorationSlots: 0 });
  assert.equal(small.policy.maxSelected, 1);
  assert.equal(larger.policy.maxSelected, 2);
  assert.equal(larger.selectedRecordIds.length, 2);
  assert.throws(() => buildRetrievalDecision(fixture.snapshot, { fieldStateId: fixture.stateId, request: { query: "signal", activeQuestionIds: [], context: "" }, policy: { ...DEFAULT_RETRIEVAL_POLICY, version: "future-reviewed-version" }, ancestry: emptyAncestry() }));
  assert.equal(JSON.stringify(small), before);
  assert.throws(() => { small.policy.maxSelected = 2; }, TypeError);
});
