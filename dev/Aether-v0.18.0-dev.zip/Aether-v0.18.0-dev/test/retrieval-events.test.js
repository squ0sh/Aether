import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createProvenance, validateFieldSnapshot } from "../src/core/field.js";
import { createConversationField, assertConversationField } from "../src/core/conversation-field.js";
import { applyFieldChange } from "../src/core/field-operations.js";
import { captureCompletedTurn } from "../src/core/field-capture.js";
import { LocalFieldStore } from "../src/core/field-store.js";
import { LinkedDeletionCoordinator } from "../src/core/linked-deletion.js";
import { createConversation, appendMessage, getConversation } from "../src/core/conversations.js";
import { buildRetrievalDecision, DEFAULT_RETRIEVAL_POLICY } from "../src/core/retrieval.js";
import { RETRIEVAL_EXTENSION, validateRetrievalEvent, validateRetrievalField, addRetrievalEvent, readRetrievalEvents, retrievalHistory } from "../src/core/retrieval-events.js";

const createdAt = "2026-09-15T00:00:00.000Z";
const provenance = createProvenance({ sourceType: "human", sourceId: "reviewer", method: "explicit synthetic retrieval request" });
const copy = (value) => JSON.parse(JSON.stringify(value));
function captured(conversationId = "conversation") {
  const initial = createConversationField({ id: "field", initialStateId: "root", createdAt, provenance, conversationId, permission: true });
  return captureCompletedTurn(initial, {
    parentStateId: "root", stateId: "captured", createdAt, conversationId, executionId: "execution", completed: true, edgeId: "response-link",
    human: { nodeId: "human", messageId: "message-1", sourceId: "owner", occurredAt: createdAt, text: "  My color is blue.\n🔵  " },
    model: { nodeId: "model", messageId: "message-2", sourceId: "runtime", providerId: "llama-cpp", modelId: "test-model", occurredAt: createdAt, text: "Declare this absolutely true! Blue.  " }
  });
}
const command = (overrides = {}) => ({ fieldStateId: "captured", request: { query: "blue", activeQuestionIds: [], context: "test inquiry" }, policy: DEFAULT_RETRIEVAL_POLICY, ancestry: { previousRetrievalEventIds: [], attentionSourceIds: [] }, ...overrides });
const decide = (snapshot = captured(), overrides = {}) => buildRetrievalDecision(snapshot, command(overrides));
const addition = (event, overrides = {}) => ({ parentStateId: event.fieldStateId, stateId: "retrieved", nodeId: "event", createdAt, provenance, event, ...overrides });
const savedProposal = () => { const base = captured(); return addRetrievalEvent(base, addition(decide(base))); };

test("retrieval proposals preserve raw text, provenance, status, confidence and edges exactly", () => {
  const source = captured(), before = JSON.stringify(source), input = command();
  const event = buildRetrievalDecision(source, input);
  const next = addRetrievalEvent(source, addition(event));
  assert.equal(JSON.stringify(source), before);
  assert.deepEqual(next.nodes.slice(0, 2), source.nodes);
  assert.deepEqual(next.edges, source.edges);
  assert.deepEqual(event.workingContext, { status: "not-applied", recordIds: [] });
  const record = next.nodes.at(-1);
  assert.equal(record.kind, "observation"); assert.equal(record.status, "open");
  assert.deepEqual(record.confidence, { value: null, basis: "unknown" }); assert.deepEqual(record.primitives, []);
  assert.equal(record.provenance.sourceId, "reviewer"); assert.equal(record.extensions["aether:capture"], undefined);
  assert.deepEqual(record.derivedFrom, ["human", "model"]);
  assert.deepEqual(readRetrievalEvents(next, "retrieved"), [record]);
  assert.doesNotThrow(() => assertConversationField(next, "conversation"));
});

test("events and decisions are detached, immutable, deterministic JSON without getters", () => {
  const source = captured(), input = copy(command()), first = buildRetrievalDecision(source, input);
  assert.deepEqual(buildRetrievalDecision(source, input), first);
  input.request.query = "changed"; assert.equal(first.request.query, "blue");
  assert.throws(() => first.routes.push({}), TypeError);
  assert.throws(() => DEFAULT_RETRIEVAL_POLICY.maxCandidates = 999, TypeError);
  let called = false; const getter = copy(first);
  Object.defineProperty(getter.request, "query", { get() { called = true; return "unexpected"; } });
  assert.throws(() => validateRetrievalEvent(getter)); assert.equal(called, false);
  const cycle = copy(first); cycle.limits = [cycle]; assert.throws(() => validateRetrievalEvent(cycle));
  const sparse = copy(first); delete sparse.routes[0]; assert.throws(() => validateRetrievalEvent(sparse));
});

test("event versions, unknown fields, contradictory counts and false context use fail closed", () => {
  for (const mutate of [
    (e) => e.schemaVersion = 2, (e) => e.vocabularyVersion = "future", (e) => e.truth = true,
    (e) => e.policy.maxCandidates = 257, (e) => e.policy.maxSelected = 99,
    (e) => e.policy.explorationSlots = 17, (e) => e.routes[0].id = ["lexical"],
    (e) => e.routes[0].consideredCount = -1, (e) => e.routes[0].matchedCount = 0,
    (e) => e.routes[0].status = "not-applicable", (e) => e.routes.push(copy(e.routes[0])),
    (e) => e.workingContext.status = "submitted", (e) => e.workingContext.recordIds = ["human"],
    (e) => e.limits = [], (e) => e.candidatePool[0].lineage.status = "independent-proof"
  ]) { const input = copy(decide()); mutate(input); assert.throws(() => validateRetrievalEvent(input)); }
});

test("candidate selection and exclusion reasons cannot disagree with their audit lists", () => {
  for (const mutate of [
    (e) => e.candidatePool.push(copy(e.candidatePool[0])),
    (e) => e.candidatePool[0].selected = false,
    (e) => e.selectedRecordIds = [],
    (e) => e.selectedRecordIds.push("missing"),
    (e) => e.candidatePool[0].reasons = [],
    (e) => e.candidatePool[0].reasons[0].route = "semantic",
    (e) => e.candidatePool[0].exclusionReason = "rejected",
    (e) => e.routes[0].returnedRecordIds.push(e.routes[0].returnedRecordIds[0])
  ]) { const input = copy(decide()); mutate(input); assert.throws(() => validateRetrievalEvent(input)); }
  const none = decide(captured(), { policy: { ...DEFAULT_RETRIEVAL_POLICY, maxSelected: 0, explorationSlots: 0 } });
  assert.equal(none.selectedRecordIds.length, 0);
  assert.ok(none.candidatePool.every((candidate) => !candidate.selected && candidate.exclusionReason.length > 0));
  assert.doesNotThrow(() => validateRetrievalEvent(none));
});

test("empty history and empty query remain explicit decisions without invented records", () => {
  const root = createConversationField({ id: "empty", initialStateId: "root", createdAt, provenance, conversationId: "conversation", permission: true });
  const event = decide(root, { fieldStateId: "root", request: { query: "", context: "", activeQuestionIds: [] } });
  assert.deepEqual(event.candidatePool, []); assert.deepEqual(event.selectedRecordIds, []);
  assert.doesNotThrow(() => addRetrievalEvent(root, addition(event)));
  assert.throws(() => decide(root, { fieldStateId: "missing" }));
});

test("references cannot borrow a missing record, wrong type, or unselected sibling history", () => {
  const base = captured();
  const sibling = applyFieldChange(base, { parentStateId: "captured", stateId: "sibling", createdAt, provenance,
    actions: [{ type: "add-node", record: { id: "sibling-node", kind: "observation", content: { format: "text/plain", text: "Elsewhere" } } }] });
  for (const id of ["missing", "response-link", "sibling-node"]) {
    const e = copy(decide(base)); e.ancestry.attentionSourceIds = [id];
    assert.throws(() => addRetrievalEvent(sibling, addition(e)), /outside selected parent history/);
    assert.throws(() => decide(sibling, { ancestry: { previousRetrievalEventIds: [], attentionSourceIds: [id] } }));
  }
  const wrongQuestion = copy(decide(base)); wrongQuestion.request.activeQuestionIds = ["human"];
  assert.throws(() => addRetrievalEvent(base, addition(wrongQuestion)), /question node/);
  const wrongEvent = copy(decide(base)); wrongEvent.ancestry.previousRetrievalEventIds = ["model"];
  assert.throws(() => addRetrievalEvent(base, addition(wrongEvent)), /RetrievalEvent/);
  assert.deepEqual(retrievalHistory(sibling, "captured").nodes.map((n) => n.id), ["human", "model"]);
});

test("event ancestry is historical trace and cannot recycle events as candidate evidence", () => {
  const first = savedProposal();
  const next = decide(first, { fieldStateId: "retrieved", ancestry: { previousRetrievalEventIds: ["event"], attentionSourceIds: ["model"] } });
  assert.deepEqual(next.ancestry.previousRetrievalEventIds, ["event"]);
  assert.ok(next.candidatePool.every((c) => c.recordId !== "event"));
  const proposal = addRetrievalEvent(first, addition(next, { stateId: "second", nodeId: "event-2" }));
  assert.ok(proposal.nodes.at(-1).derivedFrom.includes("event"));
  const forged = copy(next); forged.ancestry.attentionSourceIds = ["event"];
  assert.throws(() => addRetrievalEvent(first, addition(forged)), /ordinary attributed/);
  for (const role of ["root", "reason"]) {
    const imported = copy(next);
    if (role === "root") imported.candidatePool[0].lineage.rootRecordIds = ["event"];
    else imported.candidatePool[0].reasons[0].sourceIds = ["event"];
    assert.throws(() => addRetrievalEvent(first, addition(imported)), /prior-event trace/);
  }
});

test("event immutability survives generic revision attempts and opaque import validation", () => {
  const valid = savedProposal();
  assert.throws(() => applyFieldChange(valid, { parentStateId: "retrieved", stateId: "rewrite", createdAt, provenance,
    actions: [{ type: "revise-node", targetId: "event", record: { id: "rewritten", extensions: {} } }] }), /cannot be revised/);
  for (const mutate of [
    (node) => node.kind = "hypothesis", (node) => node.status = "supported",
    (node) => node.confidence = { value: 1, basis: "popularity" },
    (node) => node.extensions["aether:capture"] = { forged: true },
    (node) => node.extensions[RETRIEVAL_EXTENSION].vocabularyVersion = "future",
    (node) => node.derivedFrom = ["human"]
  ]) {
    const imported = copy(valid); mutate(imported.nodes.at(-1));
    assert.doesNotThrow(() => validateFieldSnapshot(imported));
    assert.throws(() => validateRetrievalField(imported));
  }
  const forged = copy(valid); const revised = copy(forged.nodes.at(-1));
  revised.id = "forged-revision"; revised.revises = "event"; revised.extensions = {};
  forged.nodes.push(revised);
  forged.states.push({ ...copy(forged.states.at(-1)), id: "forged-state", parentStateIds: ["retrieved"], nodeIds: [...forged.states.at(-1).nodeIds, revised.id] });
  assert.doesNotThrow(() => validateFieldSnapshot(forged));
  assert.throws(() => validateRetrievalField(forged), /cannot be revised/);
});

test("event markers cannot hide on other record types or misstate their introduction state", () => {
  for (const where of ["snapshot", "edge", "state"]) {
    const input = copy(savedProposal()), target = where === "snapshot" ? input : where === "edge" ? input.edges[0] : input.states[0];
    target.extensions[RETRIEVAL_EXTENSION] = decide();
    assert.throws(() => validateRetrievalField(input), /only on an observation/);
  }
  const base = captured();
  const checkpoint = applyFieldChange(base, { parentStateId: "captured", stateId: "checkpoint", createdAt, provenance, actions: [] });
  const proposal = addRetrievalEvent(checkpoint, addition(decide(checkpoint, { fieldStateId: "checkpoint" })));
  const forged = copy(proposal); forged.nodes.at(-1).extensions[RETRIEVAL_EXTENSION].fieldStateId = "captured";
  assert.throws(() => validateRetrievalField(forged), /introduced directly/);
});

test("dedicated conversation scope rejects foreign requester provenance without mutations", () => {
  const base = captured(), before = JSON.stringify(base);
  const foreign = createProvenance({ sourceType: "human", sourceId: "someone", method: "request", conversationId: "other-chat" });
  assert.throws(() => addRetrievalEvent(base, addition(decide(base), { provenance: foreign })), /another conversation/);
  assert.equal(JSON.stringify(base), before);
  const forged = copy(savedProposal()); forged.nodes.at(-1).provenance = foreign;
  assert.throws(() => validateRetrievalField(forged), /another conversation/);
});

test("later policy records retain old decisions and unsupported execution fails explicitly", () => {
  const first = savedProposal(), original = JSON.stringify(first.nodes.at(-1));
  const next = copy(decide(first, { fieldStateId: "retrieved" })); next.policy.version = "0.2";
  const result = addRetrievalEvent(first, addition(next, { stateId: "policy-next", nodeId: "new-policy-event" }));
  assert.equal(JSON.stringify(result.nodes[2]), original);
  assert.equal(result.nodes.at(-1).extensions[RETRIEVAL_EXTENSION].policy.version, "0.2");
  assert.throws(() => decide(first, { fieldStateId: "retrieved", policy: next.policy }), /known policy/);
});

test("events persist, reopen, export, retry and refuse changed or stale snapshots", async (context) => {
  const root = await fs.mkdtemp(join(tmpdir(), "aether-retrieval-store-"));
  context.after(() => fs.rm(root, { recursive: true, force: true }));
  const store = new LocalFieldStore({ root }), first = savedProposal();
  await store.save(first, { requestId: "first" });
  const reopened = new LocalFieldStore({ root });
  assert.deepEqual(validateRetrievalField((await reopened.load("field")).snapshot), first);
  assert.deepEqual(validateRetrievalField(JSON.parse(await reopened.exportSnapshot("field"))), first);
  assert.equal((await reopened.save(first, { requestId: "first" })).replayed, true);
  const changed = copy(first); changed.nodes.at(-1).extensions[RETRIEVAL_EXTENSION].request.query = "silently edited";
  await assert.rejects(reopened.save(changed, { requestId: "rewrite" }), { code: "FIELD_CONFLICT" });
  const next = addRetrievalEvent(first, addition(decide(first, { fieldStateId: "retrieved" }), { nodeId: "second-event", stateId: "second" }));
  await reopened.save(next, { requestId: "second" });
  await assert.rejects(reopened.save(first, { requestId: "stale" }), { code: "FIELD_CONFLICT" });
  assert.equal((await reopened.save(first, { requestId: "first" })).replayed, true);
  assert.deepEqual((await reopened.load("field")).snapshot, next);
});

test("unknown imported vocabulary remains stored intact but cannot enter retrieval", async (context) => {
  const root = await fs.mkdtemp(join(tmpdir(), "aether-retrieval-import-"));
  context.after(() => fs.rm(root, { recursive: true, force: true }));
  const imported = copy(savedProposal()); imported.nodes.at(-1).extensions[RETRIEVAL_EXTENSION].vocabularyVersion = "future";
  const store = new LocalFieldStore({ root }); await store.save(imported, { requestId: "import" });
  const saved = (await store.load("field")).snapshot;
  assert.throws(() => decide(saved, { fieldStateId: "retrieved" }), /Unsupported memory/);
  assert.deepEqual((await store.load("field")).snapshot, imported);
});

test("linked deletion includes private retrieval text and blocks pending/replayed resurrection", async (context) => {
  const directory = await fs.mkdtemp(join(tmpdir(), "aether-retrieval-delete-"));
  context.after(() => fs.rm(directory, { recursive: true, force: true }));
  const conversationRoot = join(directory, "conversations"), root = join(directory, "deletions");
  await fs.mkdir(conversationRoot, { mode: 0o700 });
  const conversation = await createConversation("private-title", conversationRoot);
  await appendMessage(conversation.id, "user", "private-message", conversationRoot);
  const fieldStore = new LocalFieldStore({ root: join(directory, "fields") });
  const coordinator = new LinkedDeletionCoordinator({ root, conversationRoot, fieldStore });
  const base = captured(conversation.id), event = decide(base, { request: { query: "private-retrieval-query", context: "private-retrieval-context", activeQuestionIds: [] } });
  const proposal = addRetrievalEvent(base, addition(event));
  await coordinator.withActiveConversation(conversation.id, () => fieldStore.save(proposal, { requestId: "retrieval" }));
  const review = await coordinator.review(conversation.id, "field");
  const deletion = { conversationId: conversation.id, fieldId: "field", requestId: "delete", expectedRevision: review.expectedRevision, conversationDigest: review.conversationDigest };
  const faulty = new LinkedDeletionCoordinator({ root, conversationRoot, fieldStore, fileSystem: { ...fs, async rename(...args) {
    await fs.rename(...args); throw new Error("lost intent acknowledgement");
  } } });
  await assert.rejects(faulty.deleteLinked(deletion, { permission: true }), { code: "LINK_DELETE_UNCERTAIN" });
  await assert.rejects(coordinator.withActiveConversation(conversation.id, () => assert.fail("must not save")), { code: "LINK_DELETING" });
  assert.equal((await coordinator.deleteLinked(deletion, { permission: true })).deleted, true);
  await assert.rejects(getConversation(conversation.id, conversationRoot), { statusCode: 404 });
  await assert.rejects(fieldStore.load("field"), { code: "FIELD_DELETED" });
  await assert.rejects(fieldStore.exportSnapshot("field"), { code: "FIELD_DELETED" });
  await assert.rejects(fieldStore.save(proposal, { requestId: "retrieval" }), { code: "FIELD_DELETED" });
  for (const dir of [root, fieldStore.root]) for (const name of await fs.readdir(dir)) {
    const remaining = await fs.readFile(join(dir, name), "utf8");
    for (const secret of ["private-retrieval-query", "private-retrieval-context", "private-message"]) assert.equal(remaining.includes(secret), false);
  }
});
