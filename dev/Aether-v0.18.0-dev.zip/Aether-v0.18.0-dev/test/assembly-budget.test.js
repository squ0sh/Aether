import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import { validateAssemblyBudget, measureAssemblyPayload, evaluateAssemblyBudget, UNKNOWN_TOKEN_COUNTER, UTF8_ESTIMATE_COUNTER } from "../src/core/assembly-budget.js";

const limits = (overrides = {}) => ({ maxPayloadBytes: 4096, maxInputTokens: null, contextWindowTokens: null, reservedOutputTokens: null, providerOverheadTokens: null, ...overrides });
const attested = (count) => ({ kind: "verified", method: { id: "synthetic-count", version: "1", source: "test-only caller attestation; not a real model tokenizer" }, count });
const measured = (count) => measureAssemblyPayload("payload", attested(() => count));

test("counter callback cannot relabel captured measurement metadata through its receiver", () => {
  const counter = { kind: "estimated", method: { id: "heuristic", version: "1", source: "synthetic estimator" },
    count() { assert.equal(this, undefined); return 1; } };
  assert.equal(measureAssemblyPayload("payload", counter).tokens.kind, "estimated");
  const mutating = { ...counter, count() {
    this.kind = "verified"; this.method = { id: "spoof", version: "1", source: "invented" }; return 1;
  } };
  assert.throws(() => measureAssemblyPayload("payload", mutating), TypeError);
});

test("UTF-8 measurement covers exact Unicode, wrappers, and metadata, with detached frozen results", () => {
  const payload = "<system>rules</system>\n<source id=\"n1\">雪🙂e\u0301</source>\n<user>why?</user>";
  let seen;
  const counter = attested((text) => { seen = text; return 23; });
  const result = measureAssemblyPayload(payload, counter);
  assert.equal(seen, payload);
  assert.equal(result.bytes, Buffer.byteLength(payload, "utf8"));
  assert.ok(result.bytes > payload.length);
  assert.equal(result.sha256, createHash("sha256").update(payload, "utf8").digest("hex"));
  assert.equal(result.tokens.value, 23);
  counter.method.id = "changed-after-measurement";
  assert.equal(result.tokens.method.id, "synthetic-count");
  assert.ok(Object.isFrozen(result) && Object.isFrozen(result.tokens) && Object.isFrozen(result.tokens.method));
  assert.throws(() => { result.tokens.value = 0; });
  assert.equal(evaluateAssemblyBudget(result, limits({ maxPayloadBytes: result.bytes - 1 })).reason, "byte-limit");
});

test("byte-only packing leaves unknown token capacity explicit, and the opt-in estimator stays estimated", () => {
  const unknown = measureAssemblyPayload("雪🙂");
  assert.deepEqual(unknown.tokens, { value: null, kind: "unknown", method: { id: null, version: null, source: null } });
  assert.ok(Object.isFrozen(UNKNOWN_TOKEN_COUNTER.method));
  const byteOnly = evaluateAssemblyBudget(unknown, limits());
  assert.equal(byteOnly.fits, true);
  assert.equal(byteOnly.effectiveInputTokenLimit, null);
  assert.equal(byteOnly.capacityStatus, "unknown");
  assert.ok(byteOnly.warnings.some((warning) => /byte-bound/.test(warning)));
  const estimate = measureAssemblyPayload("雪🙂", UTF8_ESTIMATE_COUNTER);
  assert.equal(estimate.tokens.value, 2);
  assert.equal(estimate.tokens.kind, "estimated");
  const assessment = evaluateAssemblyBudget(estimate, limits({ maxInputTokens: 2 }));
  assert.equal(assessment.fits, true);
  assert.equal(assessment.capacityStatus, "within-reported-count");
  assert.ok(assessment.warnings.some((warning) => /heuristic/.test(warning)));
});

test("output reserve and provider overhead reduce context capacity without altering measured text", () => {
  const result = measured(65);
  const budget = limits({ maxInputTokens: 80, contextWindowTokens: 100, reservedOutputTokens: 20, providerOverheadTokens: 15 });
  const assessment = evaluateAssemblyBudget(result, budget);
  assert.equal(assessment.effectiveInputTokenLimit, 65);
  assert.equal(assessment.fits, true);
  assert.equal(assessment.capacityStatus, "within-reported-count");
  assert.equal(evaluateAssemblyBudget(measured(66), budget).reason, "token-limit");
  assert.equal(evaluateAssemblyBudget(result, { ...budget, maxInputTokens: 64 }).reason, "token-limit");
  assert.equal(result.tokens.value, 65);
  assert.ok(Object.isFrozen(assessment) && Object.isFrozen(assessment.warnings));
});

test("unknown count conservatively fails every numeric input or context limit, including zero", () => {
  for (const override of [{ maxInputTokens: 100 }, { contextWindowTokens: 100 }, { maxInputTokens: 0 }, { contextWindowTokens: 0 }]) {
    const assessment = evaluateAssemblyBudget(measureAssemblyPayload(""), limits(override));
    assert.equal(assessment.fits, false);
    assert.equal(assessment.reason, "token-count-unknown");
    assert.equal(assessment.capacityStatus, "unknown");
  }
});

test("partly unknown context overhead reports uncertainty but rejects definite overflow", () => {
  const incomplete = limits({ contextWindowTokens: 100, reservedOutputTokens: null, providerOverheadTokens: 5 });
  const assessment = evaluateAssemblyBudget(measured(95), incomplete);
  assert.equal(assessment.fits, true);
  assert.equal(assessment.effectiveInputTokenLimit, null);
  assert.equal(assessment.capacityStatus, "unknown");
  assert.ok(assessment.warnings.some((warning) => /reserve or provider overhead is unknown/.test(warning)));
  assert.equal(evaluateAssemblyBudget(measured(96), incomplete).reason, "token-limit");
  assert.equal(evaluateAssemblyBudget(measured(101), limits({ contextWindowTokens: 100 })).reason, "token-limit");
  assert.equal(evaluateAssemblyBudget(measured(80), { ...incomplete, maxInputTokens: 79 }).reason, "token-limit");
  assert.equal(evaluateAssemblyBudget(measured(80), { ...incomplete, maxInputTokens: 90 }).effectiveInputTokenLimit, 90);
});

test("zero token budgets and reserves that exceed context do not silently regain capacity", () => {
  const zero = limits({ maxInputTokens: 0, contextWindowTokens: 0, reservedOutputTokens: 0, providerOverheadTokens: 0 });
  assert.equal(evaluateAssemblyBudget(measured(0), zero).fits, true);
  assert.equal(evaluateAssemblyBudget(measured(1), zero).reason, "token-limit");
  const impossible = evaluateAssemblyBudget(measured(0), limits({ contextWindowTokens: 0, reservedOutputTokens: 1, providerOverheadTokens: 0 }));
  assert.equal(impossible.fits, false);
  assert.equal(impossible.effectiveInputTokenLimit, 0);
  assert.ok(impossible.warnings.some((warning) => /even empty input/.test(warning)));
  const enormous = limits({ contextWindowTokens: Number.MAX_SAFE_INTEGER, reservedOutputTokens: Number.MAX_SAFE_INTEGER, providerOverheadTokens: Number.MAX_SAFE_INTEGER });
  assert.equal(evaluateAssemblyBudget(measured(0), enormous).reason, "token-limit");
  for (const contextWindowTokens of [0, 1]) {
    const result = evaluateAssemblyBudget(measured(0), { ...enormous, contextWindowTokens });
    assert.equal(result.effectiveInputTokenLimit, 0);
    assert.equal(result.reason, "token-limit");
  }
});

test("budget validation requires exact JSON fields and finite safe integer bounds", () => {
  const original = limits();
  const valid = validateAssemblyBudget(original);
  original.maxPayloadBytes = 1;
  assert.equal(valid.maxPayloadBytes, 4096);
  assert.ok(Object.isFrozen(valid));
  for (const value of [0, -1, 1.5, 16777217, Infinity, "1024"]) assert.throws(() => validateAssemblyBudget(limits({ maxPayloadBytes: value })));
  for (const key of ["maxInputTokens", "contextWindowTokens", "reservedOutputTokens", "providerOverheadTokens"]) {
    for (const value of [-1, 0.5, Number.MAX_SAFE_INTEGER + 1, Infinity, "0", undefined]) assert.throws(() => validateAssemblyBudget(limits({ [key]: value })));
  }
  assert.throws(() => validateAssemblyBudget({ ...limits(), arbitrary: true }));
  const missing = limits(); delete missing.maxInputTokens;
  assert.throws(() => validateAssemblyBudget(missing));
});

test("counter descriptors and nested method metadata cannot execute getters", () => {
  let reads = 0;
  for (const key of ["kind", "method", "count"]) {
    const counter = attested(() => 1);
    Object.defineProperty(counter, key, { enumerable: true, get() { reads++; return key === "kind" ? "verified" : 1; } });
    assert.throws(() => measureAssemblyPayload("text", counter));
  }
  const nested = attested(() => 1);
  Object.defineProperty(nested.method, "source", { enumerable: true, get() { reads++; return "injected"; } });
  assert.throws(() => measureAssemblyPayload("text", nested));
  const budget = limits();
  Object.defineProperty(budget, "maxInputTokens", { enumerable: true, get() { reads++; return 1; } });
  assert.throws(() => validateAssemblyBudget(budget));
  assert.equal(reads, 0);
});

test("invalid callback results, unknown-counter callbacks, and spoofed metadata fail explicitly", () => {
  for (const result of [-1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, "2", null, undefined, {}, Promise.resolve(2)]) {
    assert.throws(() => measureAssemblyPayload("text", attested(() => result)));
  }
  for (const counter of [null, {}, { ...UNKNOWN_TOKEN_COUNTER, count: () => 1 }, { ...attested(() => 1), kind: "exact" },
    { ...attested(() => 1), method: { id: "x", version: null, source: "test" } },
    { ...attested(() => 1), extra: true }, { ...attested(() => 1), count: 1 }]) {
    assert.throws(() => measureAssemblyPayload("text", counter));
  }
  const counter = attested(() => { counter.kind = "estimated"; counter.method.source = "changed"; return 4; });
  const result = measureAssemblyPayload("text", counter);
  assert.equal(result.tokens.kind, "verified");
  assert.match(result.tokens.method.source, /test-only/);
  assert.ok(evaluateAssemblyBudget(result, limits()).warnings.some((warning) => /caller-attested/.test(warning)));
});

test("evaluation validates imported measurements and preserves independent byte/token diagnostics", () => {
  const original = measured(30);
  for (const measurement of [{ ...original, sha256: "bad" }, { ...original, bytes: -1 },
    { ...original, tokens: { ...original.tokens, kind: "unknown" } },
    { ...original, tokens: { ...original.tokens, value: null } }, { ...original, extra: 1 }]) {
    assert.throws(() => evaluateAssemblyBudget(measurement, limits()));
  }
  const assessment = evaluateAssemblyBudget(original, limits({ maxPayloadBytes: 1, maxInputTokens: 20 }));
  assert.equal(assessment.reason, "byte-limit");
  assert.equal(assessment.capacityStatus, "exceeds-reported-count");
  assert.equal(assessment.fits, false);
});
