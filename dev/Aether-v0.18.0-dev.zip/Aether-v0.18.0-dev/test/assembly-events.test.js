import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createProvenance, validateFieldSnapshot } from "../src/core/field.js";
import { createField, applyFieldChange } from "../src/core/field-operations.js";
import { createConversationField } from "../src/core/conversation-field.js";
import { buildRetrievalDecision, DEFAULT_RETRIEVAL_POLICY } from "../src/core/retrieval.js";
import { addRetrievalEvent } from "../src/core/retrieval-events.js";
import { buildContextAssembly, DEFAULT_ASSEMBLY_POLICY } from "../src/core/context-assembly.js";
import { ASSEMBLY_EXTENSION, validateAssemblyEvent, validateAssemblyField, addAssemblyEvent, readAssemblyEvents, materializeAssembly } from "../src/core/assembly-events.js";
import { LocalFieldStore } from "../src/core/field-store.js";
import { LinkedDeletionCoordinator } from "../src/core/linked-deletion.js";
import { createConversation, appendMessage, getConversation } from "../src/core/conversations.js";
import { authoredField, observation, node, append, structuralCase } from "./fixtures/retrieval-cases.js";

const createdAt = "2026-09-16T00:00:00.000Z";
const provenance = createProvenance({ sourceType: "human", sourceId: "reviewer", method: "synthetic assembly validation" });
const copy = (value) => JSON.parse(JSON.stringify(value));
const budget = { maxPayloadBytes: 65536, maxInputTokens: null, contextWindowTokens: null, reservedOutputTokens: null, providerOverheadTokens: null };
function retrieve(snapshot, stateId) {
  const event = buildRetrievalDecision(snapshot, { fieldStateId: stateId, request: { query: "blue", activeQuestionIds: [], context: "" },
    policy: DEFAULT_RETRIEVAL_POLICY, ancestry: { previousRetrievalEventIds: [], attentionSourceIds: [] } });
  return addRetrievalEvent(snapshot, { parentStateId: stateId, stateId: "retrieved", nodeId: "retrieval", createdAt, provenance, event });
}
function fixture(conversationId = null) {
  const options = { id: "field", initialStateId: "root", createdAt, provenance };
  const initial = conversationId === null ? createField(options) : createConversationField({ ...options, conversationId, permission: true });
  const source = applyFieldChange(initial, { parentStateId: "root", stateId: "sources", createdAt, provenance,
    actions: [observation("raw", "  Blue under this lamp.\n雪🙂  ", { context: "Calibrated lamp only; generalization unknown.", status: "open" })] });
  return retrieve(source, "sources");
}
const command = (changes = {}) => ({ fieldStateId: "retrieved", retrievalEventIds: ["retrieval"],
  target: { providerId: null, modelId: null, runtimeId: null, executionId: null, attemptId: "prepared-attempt" },
  policy: DEFAULT_ASSEMBLY_POLICY, currentSegments: [{ id: "question", role: "user", content: "private-current-question" }],
  budget, representations: [], transformations: [], ...changes });
const addition = (event, changes = {}) => ({ parentStateId: event.fieldStateId, stateId: "assembled", nodeId: "assembly", createdAt, provenance, event, ...changes });
function prepared(base = fixture()) {
  const event = buildContextAssembly(base, command());
  return { base, event, snapshot: addAssemblyEvent(base, addition(event)) };
}
const transform = (outputRecordId, sourceRecordIds) => ({ outputRecordId, sourceRecordIds, method: { id: null, version: null }, limitations: ["Authored transformation; fidelity unknown."] });

test("assembly reconstructs exact Unicode and qualifications with stable canonical property ordering", () => {
  const { base, event, snapshot } = prepared(), text = materializeAssembly(snapshot, event), payload = JSON.parse(text);
  assert.equal(payload.history[0].content, base.nodes[0].content.text);
  assert.equal(payload.history[0].representationContext, base.nodes[0].context);
  assert.equal(payload.history[0].sourceContext, base.nodes[0].context);
  assert.equal(payload.history[0].representationStatus, "open");
  assert.deepEqual(payload.history[0].representationConfidence, { value: null, basis: "unknown" });
  const reorder = (value) => Array.isArray(value) ? value.map(reorder) : value && typeof value === "object"
    ? Object.fromEntries(Object.entries(value).reverse().map(([key, entry]) => [key, reorder(entry)])) : value;
  const again = buildContextAssembly(reorder(base), reorder(command()));
  assert.equal(materializeAssembly(base, again), text);
  assert.equal(again.measurement.sha256, event.measurement.sha256);
  assert.equal(event.measurement.bytes, Buffer.byteLength(text));
  assert.deepEqual(readAssemblyEvents(snapshot, "assembled").map((item) => item.id), ["assembly"]);
  assert.deepEqual(snapshot.nodes.slice(0, base.nodes.length), base.nodes);
});

test("assembly preserves versioned structural limits and counterexamples as attributed payload", () => {
  let f = authoredField("field", [[observation("raw", "blue boundary observation")]]);
  f = structuralCase(f, "cell-membrane", "structure", ["raw"]);
  const base = retrieve(f.snapshot, f.stateId), event = buildContextAssembly(base, command());
  const segment = JSON.parse(materializeAssembly(base, event)).history.find((item) => item.sourceRecordId === "structure");
  assert.ok(segment);
  assert.deepEqual(segment.structuralInterpretation, base.nodes.find((item) => item.id === "structure").extensions["aether:structural"]);
  assert.ok(segment.structuralInterpretation.limits.length && segment.structuralInterpretation.counterexamples.length);
});

test("assembly payload rejects unknown schemas, false execution claims, forged roles and inconsistent traces", () => {
  const { event } = prepared();
  for (const mutate of [
    (e) => e.schemaVersion = 2, (e) => e.vocabularyVersion = "future", (e) => e.extra = true,
    (e) => e.submission.status = "submitted", (e) => e.submission.providerProcessing = "complete",
    (e) => e.submission.influence = "proved", (e) => e.target.attemptId = null,
    (e) => e.segments[0].role = "system", (e) => e.segments[0].trust = "trusted",
    (e) => e.candidates[0].reason = "irrelevant", (e) => e.candidates[0].segmentId = null,
    (e) => e.candidates.push(copy(e.candidates[0])), (e) => e.budgetEvaluation.fits = false,
    (e) => e.limitations = [], (e) => e.currentSegments[0].id = "memory-1"
  ]) { const invalid = copy(event); mutate(invalid); assert.throws(() => validateAssemblyEvent(invalid)); }
  let invoked = false;
  const getter = copy(event); Object.defineProperty(getter.target, "modelId", { get() { invoked = true; return null; } });
  assert.throws(() => validateAssemblyEvent(getter)); assert.equal(invoked, false);
  const cycle = copy(event); cycle.limitations = [cycle]; assert.throws(() => validateAssemblyEvent(cycle));
});

test("assembly binding rejects forged digest, altered text, missing references and wrong retrieval ancestry", () => {
  const { base, event } = prepared();
  for (const mutate of [
    (e) => e.measurement.sha256 = "0".repeat(64), (e) => e.measurement.bytes++,
    (e) => e.currentSegments[0].content = "replaced private prompt",
    (e) => { e.retrievalEventIds = ["raw"]; e.candidates[0].retrievalEventIds = ["raw"]; },
    (e) => { e.candidates[0].recordId = "missing"; e.candidates[0].representationRecordId = "missing";
      e.segments[0].sourceRecordId = "missing"; e.segments[0].representationRecordId = "missing"; }
  ]) { const invalid = copy(event); mutate(invalid); assert.throws(() => materializeAssembly(base, invalid)); }
});

test("unselected sibling representations and cross-Field references cannot enter an assembly", () => {
  const base = fixture();
  const sibling = applyFieldChange(base, { parentStateId: "sources", stateId: "sibling", createdAt, provenance,
    actions: [node("sibling-summary", "abstraction", "Blue", { derivedFrom: ["raw"] })] });
  const changes = { representations: [{ recordId: "raw", representationRecordId: "sibling-summary" }],
    transformations: [transform("sibling-summary", ["raw"])] };
  assert.throws(() => buildContextAssembly(sibling, command(changes)), /selected parent history/);
  assert.throws(() => buildContextAssembly(base, command({ retrievalEventIds: ["another-field-event"] })), /RetrievalEvent/);
  assert.throws(() => buildContextAssembly(base, command({ representations: [{ recordId: "not-selected", representationRecordId: "raw" }] })), /unique selected source/);
});

test("side-summary chains cannot hide undocumented recursive transformations", () => {
  let f = authoredField("field", [[observation("raw", "blue main evidence"), observation("side-raw", "side observation")],
    [node("side-summary", "abstraction", "side summary", { derivedFrom: ["side-raw"] })],
    [node("combined", "abstraction", "combined blue", { derivedFrom: ["raw", "side-summary"] })]]);
  const base = retrieve(f.snapshot, f.stateId);
  const changes = { representations: [{ recordId: "raw", representationRecordId: "combined" }], transformations: [transform("combined", ["raw", "side-summary"])] };
  assert.throws(() => buildContextAssembly(base, command(changes)), /side summary.*missing/);
  changes.transformations.push(transform("side-summary", ["side-raw"]));
  const event = buildContextAssembly(base, command(changes));
  assert.deepEqual(event.candidates.find((item) => item.recordId === "raw").transformationIds, ["combined", "side-summary"]);
  const segment = JSON.parse(materializeAssembly(base, event)).history.find((item) => item.sourceRecordId === "raw");
  assert.equal(segment.transformations.length, 2);
  assert.ok(segment.ancestryRecordIds.includes("side-raw"));
  const wrong = copy(changes); wrong.transformations[0].sourceRecordIds = ["raw"];
  assert.throws(() => buildContextAssembly(base, command(wrong)), /exactly match/);
});

test("assembly readers reject marker misuse, source revision and incorrect introduction states", () => {
  const { snapshot } = prepared();
  for (const mutate of [
    (s) => s.extensions[ASSEMBLY_EXTENSION] = copy(s.nodes.at(-1).extensions[ASSEMBLY_EXTENSION]),
    (s) => s.states[0].extensions[ASSEMBLY_EXTENSION] = {},
    (s) => s.nodes.at(-1).kind = "hypothesis",
    (s) => s.nodes.at(-1).confidence = { value: 1, basis: "arbitrary" },
    (s) => s.nodes.at(-1).derivedFrom = ["raw"],
    (s) => s.nodes.at(-1).extensions["aether:capture"] = { forged: true }
  ]) { const invalid = copy(snapshot); mutate(invalid); assert.throws(() => validateAssemblyField(invalid)); }
  assert.throws(() => applyFieldChange(snapshot, { parentStateId: "assembled", stateId: "revision", createdAt, provenance,
    actions: [{ type: "revise-node", targetId: "assembly", record: { id: "revision-node", extensions: {} } }] }), /cannot be revised/);
  const stripped = copy(snapshot), revised = { ...copy(stripped.nodes.at(-1)), id: "revised", revises: "assembly", extensions: {} };
  stripped.nodes.push(revised);
  stripped.states.push({ ...copy(stripped.states.at(-1)), id: "revision", parentStateIds: ["assembled"], nodeIds: [...stripped.states.at(-1).nodeIds, "revised"] });
  assert.doesNotThrow(() => validateFieldSnapshot(stripped));
  assert.throws(() => validateAssemblyField(stripped), /cannot be revised/);
  const base = fixture(), checkpoint = applyFieldChange(base, { parentStateId: "retrieved", stateId: "checkpoint", createdAt, provenance, actions: [] });
  const event = buildContextAssembly(checkpoint, command({ fieldStateId: "checkpoint" }));
  const introduced = copy(addAssemblyEvent(checkpoint, addition(event)));
  introduced.nodes.at(-1).extensions[ASSEMBLY_EXTENSION].fieldStateId = "retrieved";
  assert.throws(() => validateAssemblyField(introduced), /introduced directly/);
});

test("blocked assembly is auditable but cannot materialize or bypass invalid existing audit history", () => {
  const base = fixture(), event = buildContextAssembly(base, command({ budget: { ...budget, maxPayloadBytes: 1 } }));
  assert.equal(event.outcome, "blocked");
  const snapshot = addAssemblyEvent(base, addition(event));
  assert.equal(readAssemblyEvents(snapshot, "assembled").length, 1);
  assert.throws(() => materializeAssembly(snapshot, event), /Blocked/);
  const invalid = copy(snapshot); invalid.nodes.at(-1).extensions[ASSEMBLY_EXTENSION].vocabularyVersion = "future";
  assert.throws(() => buildContextAssembly(invalid, command({ fieldStateId: "assembled", budget: { ...budget, maxPayloadBytes: 1 } })), /Unsupported assembly/);
});

test("assembly persists privately, reopens, exports, retries, and refuses stale or changed history", async (t) => {
  const root = await fs.mkdtemp(join(tmpdir(), "aether-assembly-store-")); t.after(() => fs.rm(root, { recursive: true, force: true }));
  const store = new LocalFieldStore({ root }), { base, event, snapshot } = prepared();
  await store.save(snapshot, { requestId: "first" });
  const reopened = new LocalFieldStore({ root }), saved = (await reopened.load("field")).snapshot;
  assert.deepEqual(validateAssemblyField(saved), snapshot);
  assert.equal(materializeAssembly(saved, event), materializeAssembly(base, event));
  assert.deepEqual(validateAssemblyField(JSON.parse(await reopened.exportSnapshot("field"))), snapshot);
  assert.equal((await reopened.save(snapshot, { requestId: "first" })).replayed, true);
  const changed = copy(snapshot); changed.nodes.at(-1).extensions[ASSEMBLY_EXTENSION].limitations.push("silently edited");
  await assert.rejects(reopened.save(changed, { requestId: "rewrite" }), { code: "FIELD_CONFLICT" });
  const later = buildContextAssembly(snapshot, command({ fieldStateId: "assembled" }));
  const next = addAssemblyEvent(snapshot, addition(later, { stateId: "later", nodeId: "assembly-2" }));
  await reopened.save(next, { requestId: "second" });
  await assert.rejects(reopened.save(snapshot, { requestId: "stale" }), { code: "FIELD_CONFLICT" });
  if (process.platform !== "win32") {
    assert.equal((await fs.stat(root)).mode & 0o777, 0o700);
    for (const name of await fs.readdir(root)) assert.equal((await fs.stat(join(root, name))).mode & 0o777, 0o600);
  }
});

test("unknown assembly imports stay stored intact but dedicated readers and builders fail closed", async (t) => {
  const root = await fs.mkdtemp(join(tmpdir(), "aether-assembly-import-")); t.after(() => fs.rm(root, { recursive: true, force: true }));
  const imported = copy(prepared().snapshot); imported.nodes.at(-1).extensions[ASSEMBLY_EXTENSION].vocabularyVersion = "future";
  const store = new LocalFieldStore({ root }); await store.save(imported, { requestId: "import" });
  const saved = (await store.load("field")).snapshot;
  assert.throws(() => validateAssemblyField(saved), /Unsupported assembly/);
  assert.throws(() => buildContextAssembly(saved, command({ fieldStateId: "assembled" })), /Unsupported assembly/);
  assert.deepEqual((await store.load("field")).snapshot, imported);
});

test("assembly requester provenance cannot escape dedicated conversation scope", () => {
  const base = fixture("conversation"), event = buildContextAssembly(base, command());
  const foreign = createProvenance({ sourceType: "human", sourceId: "other", method: "request", conversationId: "other-conversation" });
  assert.throws(() => addAssemblyEvent(base, addition(event, { provenance: foreign })), /another conversation/);
});

test("linked deletion erases assembly current text and blocks pending writes and resurrection", async (t) => {
  const directory = await fs.mkdtemp(join(tmpdir(), "aether-assembly-delete-")); t.after(() => fs.rm(directory, { recursive: true, force: true }));
  const conversationRoot = join(directory, "conversations"), root = join(directory, "deletions");
  await fs.mkdir(conversationRoot, { mode: 0o700 });
  const conversation = await createConversation("private-title", conversationRoot);
  await appendMessage(conversation.id, "user", "private-message", conversationRoot);
  const fieldStore = new LocalFieldStore({ root: join(directory, "fields") });
  const coordinator = new LinkedDeletionCoordinator({ root, conversationRoot, fieldStore });
  const { snapshot } = prepared(fixture(conversation.id));
  await coordinator.withActiveConversation(conversation.id, () => fieldStore.save(snapshot, { requestId: "assembly" }));
  const review = await coordinator.review(conversation.id, "field");
  const deletion = { conversationId: conversation.id, fieldId: "field", requestId: "delete", expectedRevision: review.expectedRevision, conversationDigest: review.conversationDigest };
  const faulty = new LinkedDeletionCoordinator({ root, conversationRoot, fieldStore, fileSystem: { ...fs, async rename(...args) {
    await fs.rename(...args); throw new Error("lost intent acknowledgement");
  } } });
  await assert.rejects(faulty.deleteLinked(deletion, { permission: true }), { code: "LINK_DELETE_UNCERTAIN" });
  await assert.rejects(coordinator.withActiveConversation(conversation.id, () => assert.fail("must not save")), { code: "LINK_DELETING" });
  assert.equal((await coordinator.deleteLinked(deletion, { permission: true })).deleted, true);
  await assert.rejects(getConversation(conversation.id, conversationRoot), { statusCode: 404 });
  await assert.rejects(fieldStore.load("field"), { code: "FIELD_DELETED" });
  await assert.rejects(fieldStore.exportSnapshot("field"), { code: "FIELD_DELETED" });
  await assert.rejects(fieldStore.save(snapshot, { requestId: "assembly" }), { code: "FIELD_DELETED" });
  for (const dir of [root, fieldStore.root]) for (const name of await fs.readdir(dir)) {
    const remaining = await fs.readFile(join(dir, name), "utf8");
    for (const secret of ["private-current-question", "private-message", "Blue under this lamp"]) assert.equal(remaining.includes(secret), false);
  }
});
