import { createProvenance } from "../../src/core/field.js";
import { createField, applyFieldChange } from "../../src/core/field-operations.js";
import { addStructuralInterpretation } from "../../src/core/structural-field.js";
import { structuralCases } from "./structural-cases.js";

// All authored scenarios are synthetic. Source labels express declared ancestry,
// never independent evidence, measured scientific facts, or semantic relevance.
export const authoredAt = "2026-09-14T00:00:00.000Z";
export const author = createProvenance({ sourceType: "human", sourceId: "synthetic-reviewer", method: "authored retrieval adversary" });
export const copy = (value) => JSON.parse(JSON.stringify(value));
export const observation = (id, text, extra = {}) => ({ type: "add-node", record: { id, kind: "observation", content: { format: "text/plain", text }, ...extra } });
export const node = (id, kind, text, extra = {}) => observation(id, text, { kind, ...extra });
export const edge = (id, from, to, relation, context = "Explicit fictional relationship; not an automatic truth assessment.") => ({ type: "add-edge", record: { id, from, to, relation, context } });
export const modelAuthor = (modelId) => createProvenance({ sourceType: "model", sourceId: modelId, providerId: "synthetic-provider", modelId, method: "fictional model output" });

export function append(fixture, actions, { stateId = `state-${fixture.snapshot.states.length}`, createdAt = authoredAt } = {}) {
  return {
    snapshot: applyFieldChange(fixture.snapshot, { parentStateId: fixture.stateId, stateId, createdAt, provenance: author, actions }),
    stateId
  };
}

export function authoredField(id, layers) {
  let fixture = { snapshot: createField({ id, initialStateId: "root", createdAt: authoredAt, provenance: author }), stateId: "root" };
  for (const actions of layers) fixture = append(fixture, actions);
  return fixture;
}

export function structuralCase(fixture, caseId, nodeId, sourceIds, mutate = () => {}) {
  const interpretation = copy(structuralCases.find((item) => item.id === caseId).payload);
  interpretation.sourceNodeIds = sourceIds;
  mutate(interpretation);
  const stateId = `structural-state-${fixture.snapshot.states.length}`;
  return {
    snapshot: addStructuralInterpretation(fixture.snapshot, {
      parentStateId: fixture.stateId, stateId, nodeId, createdAt: authoredAt,
      provenance: author, summary: `Candidate reading for synthetic ${caseId}.`, interpretation
    }),
    stateId
  };
}
