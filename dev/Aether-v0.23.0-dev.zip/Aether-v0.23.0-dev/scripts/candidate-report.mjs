import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { benchmarkFingerprint } from '../src/experiment/runner.js';
const [fullPath, focusedPath, soakPath, outputPath] = process.argv.slice(2);
assert.ok(outputPath, 'Usage: full-log focused-log soak-log new-output-json');
const hash = text => createHash('sha256').update(text).digest('hex');
async function testLog(path) {
  const raw = await readFile(path, 'utf8'), counts = {};
  for (const key of ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']) {
    const m = raw.match(new RegExp(`(?:ℹ|#) ${key} (\\d+)`)); assert.ok(m, `Missing ${key}`); counts[key] = Number(m[1]);
  }
  assert.ok(counts.tests > 0); assert.equal(counts.tests, counts.pass);
  for (const key of ['fail', 'cancelled', 'skipped', 'todo']) assert.equal(counts[key], 0);
  return { ...counts, logSha256: hash(raw) };
}
const full = await testLog(fullPath), focused = await testLog(focusedPath), raw = await readFile(soakPath, 'utf8');
const soak = raw.split('\n').filter(x => x.startsWith('{')).map(x => JSON.parse(x)).find(x => x.result === 'passed');
assert.ok(soak); assert.equal(soak.passed, 32); assert.equal(soak.cycles, 32); assert.equal(soak.failed, 0); assert.equal(soak.skipped, 0);
const fingerprint = await benchmarkFingerprint();
assert.deepEqual(fingerprint, JSON.parse(await readFile(new URL('../docs/EXPERIMENT-v0.23.0-benchmark-lock.json', import.meta.url), 'utf8')));
await writeFile(outputPath, JSON.stringify({ release: '0.23.0-dev', full, focused, soak: { ...soak, logSha256: hash(raw) }, benchmarkFingerprint: fingerprint,
  modelDownloads: 0, realModelEvaluations: 0, runtimeProbe: 'trusted Node --version fixture only; no llama.cpp build probed',
  httpEvidence: 'synthetic local endpoints, including a complete 95-case reference pass with five semantic PARTIAL outcomes and a malformed-output run',
  limits: ['Current host only; not a cross-platform execution matrix.', 'Repository model metadata is not independent weight/license verification.', 'No real candidate resource or cognitive performance claim.'] }, null, 2) + '\n', { flag: 'wx' });
