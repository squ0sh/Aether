import { readFile, open } from 'node:fs/promises';
import { validateManifest } from '../src/experiment/manifest.js';
import { runExperiment } from '../src/experiment/runner.js';
const [mode, manifestPath, outputPath, confirmation, ...extra] = process.argv.slice(2);
if (!['plan', 'probe', 'run'].includes(mode) || !manifestPath || extra.length) throw new Error('Usage: plan manifest.json OR probe|run manifest.json new-private-report.json --allow-local-inference');
const manifest = validateManifest(JSON.parse(await readFile(manifestPath, 'utf8')), { ready: mode !== 'plan' });
if (mode === 'plan') {
  if (outputPath || confirmation) throw new Error('plan accepts only a manifest path');
  console.log(JSON.stringify({ valid: true, manifest, execution: 'not-performed', downloads: 'not-performed' }, null, 2));
} else {
  if (!outputPath || confirmation !== '--allow-local-inference') throw new Error('Explicit local-inference flag and new report path required');
  // Reserve before dispatch so an existing report is never overwritten after costly work.
  const output = await open(outputPath, 'wx', 0o600), controller = new AbortController();
  const cancel = () => controller.abort(); process.once('SIGINT', cancel); process.once('SIGTERM', cancel);
  try {
    const report = await runExperiment(manifest, { mode, signal: controller.signal });
    await output.writeFile(JSON.stringify(report, null, 2) + '\n'); await output.sync();
    console.log(JSON.stringify({ report: outputPath, digest: report.experimentDigest, compatibility: report.compatibility, error: report.error }));
    if (report.error || report.benchmark?.results.some(r => r.operational.status === 'fail')) process.exitCode = 1;
  } catch (e) {
    await output.writeFile(JSON.stringify({ version: 'aether-experiment-failure-0.1', error: String(e.message), inferenceMayHaveOccurred: null }) + '\n'); process.exitCode = 1;
    console.error(e.message);
  } finally { process.removeListener('SIGINT', cancel); process.removeListener('SIGTERM', cancel); await output.close(); }
}
