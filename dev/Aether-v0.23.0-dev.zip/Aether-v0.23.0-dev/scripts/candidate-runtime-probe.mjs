import { readFile, open } from 'node:fs/promises';
import { probeRuntime } from '../src/experiment/runtime-probe.js';
const [input, output, confirmation, ...rest] = process.argv.slice(2);
if (!input || !output || confirmation !== '--allow-runtime-execution' || rest.length) throw new Error('Usage: runtime.json new-private-report.json --allow-runtime-execution');
const runtime = JSON.parse(await readFile(input, 'utf8')), file = await open(output, 'wx', 0o600);
const controller = new AbortController(), cancel = () => controller.abort();
process.once('SIGINT', cancel); process.once('SIGTERM', cancel);
try {
  const report = await probeRuntime(runtime, { approved: true, signal: controller.signal });
  await file.writeFile(JSON.stringify(report, null, 2) + '\n'); await file.sync();
  console.log(JSON.stringify({ report: output, status: report.status })); if (report.error) process.exitCode = 1;
} catch (e) { await file.writeFile(JSON.stringify({ error: String(e.message), execution: 'not-confirmed' }) + '\n'); process.exitCode = 1; }
finally { process.removeListener('SIGINT', cancel); process.removeListener('SIGTERM', cancel); await file.close(); }
