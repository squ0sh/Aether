// Offline metadata import. This script never downloads weights or executes runtimes.
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { check } from '../src/benchmark/common.js';
import { validateManifest, EXPERIMENT_VERSION } from '../src/experiment/manifest.js';
import { benchmarkFingerprint } from '../src/experiment/runner.js';
const [metadataDirectory, outputDirectory] = process.argv.slice(2);
check(metadataDirectory && outputDirectory, 'metadata and output directories required');
const specs = [
  ['conventional', 'Qwen/Qwen3-1.7B-GGUF', 'Qwen3-1.7B-Q8_0.gguf', 'conventional', 'Q8_0'],
  ['binary', 'prism-ml/Bonsai-1.7B-gguf', 'Bonsai-1.7B-Q1_0.gguf', 'binary', 'Q1_0'],
  ['ternary', 'prism-ml/Ternary-Bonsai-1.7B-gguf', 'Ternary-Bonsai-1.7B-Q2_0.gguf', 'ternary', 'Q2_0']
];
const candidates = [];
for (const [track, repository, filename, representation, quantization] of specs) {
  const metadata = JSON.parse(await readFile(join(metadataDirectory, track + '.json'), 'utf8'));
  check(metadata.id === repository && /^[a-f0-9]{40}$/.test(metadata.sha), 'unexpected repository/revision');
  const file = metadata.siblings.find(x => x.rfilename === filename); check(file?.lfs?.sha256 && file.size === file.lfs.size && metadata.cardData?.license, 'missing file hash/size/license metadata');
  const manifest = validateManifest({ version: EXPERIMENT_VERSION, id: `${track}-1.7b-development`,
    candidate: { id: `${track}-1.7b`, representation, parameters: null, quantization },
    artifact: { repository, revision: metadata.sha, filename, sha256: file.lfs.sha256, sizeBytes: file.size, license: metadata.cardData.license, licenseSource: `https://huggingface.co/${repository}/blob/${metadata.sha}/README.md`, localPath: null },
    runtime: null, connection: null, protocol: { id: 'json-view-chat-0.1', temperature: 0, seed: 42, maxOutputTokens: 2048 },
    corpus: { benchmarkVersion: 'aether-resident-benchmark-0.1', seed: 'aether-development-0.1', variants: 4, scale: 4, partition: 'development' },
    limits: { caseTimeoutMs: 60000, totalTimeoutMs: 1800000, maxResponseBytes: 262144 },
    approval: { localInference: false, licenseReviewed: false, heldOutIsolationConfirmed: false } });
  await writeFile(join(outputDirectory, `EXPERIMENT-${track}-manifest.json`), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
  candidates.push({ track, nominalScale: '1.7B (marketing label; exact count not verified)', artifact: manifest.artifact, evidence: 'repository-declared metadata; weights not downloaded or independently hashed', metadataSource: `https://huggingface.co/api/models/${repository}?blobs=true`, compatibility: 'not-tested', stage: 'smallest-representative-pending-approval' });
}
await writeFile(join(outputDirectory, 'EXPERIMENT-v0.23.0-catalog.json'), JSON.stringify({ version: 'candidate-catalog-0.1', candidates,
  deferred: ['Conventional SmolLM/tiny baseline: exact artifact selection pending', 'Alignment variants: names missing from handoff; no guessed candidates', 'Bonsai binary 4B/8B and ternary 4B/8B: gated on review of smaller runs; no downloads', '27B: outside experiment one'],
  limitations: ['Q8_0 conventional baseline is not a matched-bit-rate comparison.', 'Q2_0 and PQ2_0 are different artifacts; no automatic substitution.', 'No license acceptance or runtime compatibility follows from repository metadata.'] }, null, 2) + '\n', { flag: 'wx' });
await writeFile(join(outputDirectory, 'EXPERIMENT-v0.23.0-benchmark-lock.json'), JSON.stringify(await benchmarkFingerprint(), null, 2) + '\n', { flag: 'wx' });
