import { createHash } from 'node:crypto';
import { open } from 'node:fs/promises';
import { isAbsolute } from 'node:path';
import { check, shape, text, json, digest, VERSION } from '../benchmark/common.js';

export const EXPERIMENT_VERSION = 'aether-candidate-experiment-0.1';
export const sha = value => check(typeof value === 'string' && /^[a-f0-9]{64}$/.test(value), 'SHA-256 required');
const integer = (v, low, high) => check(Number.isSafeInteger(v) && v >= low && v <= high, `integer ${low}..${high} required`);
export function validateRuntime(input) {
  const r = json(input); shape(r, ['id', 'version', 'revision', 'build', 'source', 'localPath', 'sha256', 'dependencies']);
  for (const k of ['id', 'version', 'revision', 'build']) text(r[k]);
  check(['portable', 'system'].includes(r.source), 'portable or system runtime source required');
  check(isAbsolute(r.localPath), 'absolute runtime path required'); sha(r.sha256);
  check(Array.isArray(r.dependencies) && r.dependencies.length <= 64, 'bounded runtime dependencies required');
  for (const d of r.dependencies) { shape(d, ['localPath', 'sha256']); check(isAbsolute(d.localPath), 'absolute dependency path required'); sha(d.sha256); }
  const paths = [r.localPath, ...r.dependencies.map(d => d.localPath)];
  check(new Set(paths).size === paths.length, 'duplicate runtime/dependency paths');
  return r;
}
export function localEndpoint(input) {
  text(input); const u = new URL(input);
  check(u.protocol === 'http:' && ['127.0.0.1', '[::1]'].includes(u.hostname) && !u.username && !u.password && !u.search && !u.hash && u.pathname === '/', 'explicit loopback HTTP origin required; no credentials, path, query or redirect');
  return u.origin;
}
export function validateManifest(input, { ready = false } = {}) {
  const m = json(input);
  shape(m, ['version', 'id', 'candidate', 'artifact', 'runtime', 'connection', 'protocol', 'corpus', 'limits', 'approval']);
  check(m.version === EXPERIMENT_VERSION, 'unknown experiment version'); text(m.id);
  shape(m.candidate, ['id', 'representation', 'parameters', 'quantization']);
  for (const k of ['id', 'representation', 'quantization']) text(m.candidate[k]);
  check(m.candidate.parameters === null || Number.isSafeInteger(m.candidate.parameters) && m.candidate.parameters > 0, 'parameter count or null required');
  shape(m.artifact, ['repository', 'revision', 'filename', 'sha256', 'sizeBytes', 'license', 'licenseSource', 'localPath']);
  for (const k of ['repository', 'revision', 'filename', 'license', 'licenseSource']) text(m.artifact[k]);
  sha(m.artifact.sha256); integer(m.artifact.sizeBytes, 1, Number.MAX_SAFE_INTEGER);
  check(m.artifact.localPath === null || isAbsolute(m.artifact.localPath), 'absolute artifact path or null required');
  if (m.runtime !== null) {
    validateRuntime(m.runtime);
  }
  if (m.connection !== null) {
    shape(m.connection, ['origin', 'modelId', 'operatorAttestation', 'contextTokens', 'startupDescription']);
    localEndpoint(m.connection.origin); text(m.connection.modelId); text(m.connection.startupDescription);
    check(typeof m.connection.operatorAttestation === 'boolean', 'explicit operator attestation required');
    integer(m.connection.contextTokens, 128, 1048576);
  }
  shape(m.protocol, ['id', 'temperature', 'seed', 'maxOutputTokens']);
  check(m.protocol.id === 'json-view-chat-0.1' && m.protocol.temperature === 0, 'frozen protocol and temperature required');
  integer(m.protocol.seed, 0, 2147483647); integer(m.protocol.maxOutputTokens, 16, 8192);
  shape(m.corpus, ['benchmarkVersion', 'seed', 'variants', 'scale', 'partition']);
  check(m.corpus.benchmarkVersion === VERSION, 'frozen benchmark required'); text(m.corpus.seed);
  integer(m.corpus.variants, 3, 12); integer(m.corpus.scale, 1, 32);
  check(['development', 'held-out'].includes(m.corpus.partition), 'unknown partition');
  shape(m.limits, ['caseTimeoutMs', 'totalTimeoutMs', 'maxResponseBytes']);
  integer(m.limits.caseTimeoutMs, 1, 60000); integer(m.limits.totalTimeoutMs, m.limits.caseTimeoutMs, 3600000); integer(m.limits.maxResponseBytes, 1024, 1048576);
  shape(m.approval, ['localInference', 'licenseReviewed', 'heldOutIsolationConfirmed']);
  for (const v of Object.values(m.approval)) check(typeof v === 'boolean', 'explicit approval flags required');
  if (ready) {
    check(m.approval.localInference && m.approval.licenseReviewed, 'local inference and license review approval required');
    check(m.runtime && m.artifact.localPath && m.connection?.operatorAttestation, 'local pins and explicit server operator attestation required');
    check(m.protocol.maxOutputTokens < m.connection.contextTokens, 'output must fit configured context');
    check(m.corpus.partition !== 'held-out' || m.approval.heldOutIsolationConfirmed, 'held-out operator isolation confirmation required');
  }
  return m;
}
export async function hashFile(path, signal) {
  signal?.throwIfAborted(); const handle = await open(path, 'r');
  try {
    const before = await handle.stat(); check(before.isFile(), 'regular local file required');
    const hash = createHash('sha256'), buffer = Buffer.alloc(1024 * 1024); let size = 0;
    while (true) { signal?.throwIfAborted(); const { bytesRead } = await handle.read(buffer, 0, buffer.length, null); if (!bytesRead) break; hash.update(buffer.subarray(0, bytesRead)); size += bytesRead; }
    const after = await handle.stat(); check(before.size === after.size && before.mtimeMs === after.mtimeMs && size === after.size, 'file changed while hashing');
    return json({ sha256: hash.digest('hex'), sizeBytes: size });
  } finally { await handle.close(); }
}
export async function verifyLocalFiles(manifest, signal) {
  const m = validateManifest(manifest, { ready: true }), records = [];
  for (const [kind, item] of [['model', m.artifact], ['runtime', m.runtime], ...m.runtime.dependencies.map(d => ['dependency', d])]) {
    const observed = await hashFile(item.localPath, signal); check(observed.sha256 === item.sha256, `${kind} hash mismatch`);
    if (kind === 'model') check(observed.sizeBytes === item.sizeBytes, 'model size mismatch');
    records.push({ kind, ...observed });
  }
  return json({ manifestDigest: digest(m), files: records, binding: 'local-files-only; endpoint identity is operator-attested, not authenticated', dependencies: 'only explicitly listed files verified; completeness not established' });
}
