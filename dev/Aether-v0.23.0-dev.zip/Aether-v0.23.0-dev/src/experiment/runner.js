import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { json, digest, check } from '../benchmark/common.js';
import { generateCorpus } from '../benchmark/cases.js';
import { runCorpus, compareCandidates } from '../benchmark/runner.js';
import { validateManifest, verifyLocalFiles, EXPERIMENT_VERSION } from './manifest.js';
import { createEndpointCandidate, SYSTEM_PROMPT } from './transport.js';

export async function benchmarkFingerprint() {
  const entries = [];
  for (const name of ['common', 'cases', 'candidates', 'evaluate', 'resources', 'runner']) {
    const raw = await readFile(new URL(`../benchmark/${name}.js`, import.meta.url));
    entries.push({ file: `${name}.js`, sha256: createHash('sha256').update(raw).digest('hex') });
  }
  return json({ files: entries, digest: digest(entries) });
}
export async function runExperiment(input, { mode = 'probe', signal } = {}) {
  check(['probe', 'run'].includes(mode), 'probe or run required');
  const m = validateManifest(input, { ready: true });
  const combined = AbortSignal.any([AbortSignal.timeout(m.limits.totalTimeoutMs), ...(signal ? [signal] : [])]);
  const baseline = JSON.parse(await readFile(new URL('../../docs/EXPERIMENT-v0.23.0-benchmark-lock.json', import.meta.url), 'utf8'));
  const fingerprint = await benchmarkFingerprint(); check(fingerprint.digest === baseline.digest, 'frozen benchmark changed');
  const localFiles = await verifyLocalFiles(m, combined), candidate = createEndpointCandidate(m, { signal: combined });
  let compatibility = null, benchmark = null, error = null;
  try {
    compatibility = await candidate.probe(combined);
    if (mode === 'run') benchmark = await runCorpus(generateCorpus(m.corpus), candidate, { signal: combined, timeoutMs: m.limits.caseTimeoutMs });
  } catch (e) { error = String(e.message).slice(0, 512); }
  finally { candidate.stop(); }
  const result = json({ version: EXPERIMENT_VERSION, manifest: m, manifestDigest: digest(m), benchmarkFingerprint: fingerprint,
    protocolDigest: digest({ prompt: SYSTEM_PROMPT, protocol: m.protocol }), mode, localFiles, compatibility, benchmark, error,
    observations: candidate.observations(), resources: { modelDiskBytes: m.artifact.sizeBytes, runtimeDiskBytes: localFiles.files.filter(x => x.kind !== 'model').reduce((s, x) => s + x.sizeBytes, 0), peakRAMBytes: null, energyJoules: null, cpuUtilization: null, promptLatencyMs: null, timeToFirstTokenMs: null, throughput: null, configuredContextTokens: m.connection.contextTokens,
      attribution: 'disk from verified local files; context operator-attested; request elapsed time is client roundtrip including transport; usage endpoint-reported' },
    adoption: 'not-performed', training: 'not-performed', limitations: ['Local files are verified, but remote process/model binding remains operator-attested.', 'HTTP abort stops client work, not proof that server inference stopped; transport failure latches off later calls.', 'No retries, grammar repair, tool dispatch or prompt adaptation.', 'Runtime, template, tokenizer and build differences confound weight-format comparisons.', 'Public corpus results are development evidence, not held-out cognition certification.'] });
  return json({ ...result, experimentDigest: digest(result) });
}
export function compareExperiments(a, b) {
  for (const r of [a, b]) {
    const { experimentDigest, ...body } = r;
    check(r.version === EXPERIMENT_VERSION && experimentDigest === digest(body), 'experiment digest mismatch');
    validateManifest(r.manifest, { ready: true });
    check(r.manifestDigest === digest(r.manifest), 'manifest digest mismatch');
    check(r.protocolDigest === digest({ prompt: SYSTEM_PROMPT, protocol: r.manifest.protocol }), 'protocol digest mismatch');
    check(r.benchmarkFingerprint.digest === digest(r.benchmarkFingerprint.files), 'benchmark fingerprint mismatch');
    check(r.benchmark, 'completed benchmark report required');
  }
  check(a.benchmarkFingerprint.digest === b.benchmarkFingerprint.digest && a.protocolDigest === b.protocolDigest, 'different benchmark or prompt protocol');
  check(a.manifest.connection.contextTokens === b.manifest.connection.contextTokens && digest(a.manifest.limits) === digest(b.manifest.limits), 'different context or operational limits');
  return json({ comparison: compareCandidates(a.benchmark, b.benchmark), runtimeChanged: digest(a.manifest.runtime) !== digest(b.manifest.runtime), startupConfigurationChanged: a.manifest.connection.startupDescription !== b.manifest.connection.startupDescription, environmentChanged: digest(a.benchmark.resources.environment) !== digest(b.benchmark.resources.environment),
    causalClaim: 'not-established; model training, templates, tokenizer, runtime and hardware can differ', adoption: 'not-performed' });
}
