import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { dirname, delimiter } from 'node:path';
import { validateRuntime, hashFile } from './manifest.js';
import { check, json, digest } from '../benchmark/common.js';
import { observedEnvironment } from '../benchmark/resources.js';

export function runtimeEnvironment(runtime, env = process.env, platform = process.platform) {
  const out = { ...env };
  if (runtime.source === 'portable') {
    const key = platform === 'linux' ? 'LD_LIBRARY_PATH' : platform === 'darwin' ? 'DYLD_LIBRARY_PATH' : null;
    if (key) out[key] = dirname(runtime.localPath) + (out[key] ? delimiter + out[key] : '');
  }
  return out;
}
export async function probeRuntime(input, { approved = false, signal, timeoutMs = 10000 } = {}) {
  check(approved === true, 'runtime execution approval required');
  check(Number.isSafeInteger(timeoutMs) && timeoutMs > 0 && timeoutMs <= 60000, 'bounded runtime probe timeout required');
  const runtime = validateRuntime(input), files = [];
  for (const item of [runtime, ...runtime.dependencies]) { const observed = await hashFile(item.localPath, signal); check(observed.sha256 === item.sha256, 'runtime/dependency hash mismatch'); files.push(observed); }
  let stdout = '', stderr = '', error = null, exitCode = null, exitSignal = null;
  try {
    const result = await promisify(execFile)(runtime.localPath, ['--version'], { shell: false, env: runtimeEnvironment(runtime), timeout: timeoutMs, killSignal: 'SIGKILL', maxBuffer: 65536, signal, windowsHide: true });
    stdout = result.stdout; stderr = result.stderr; exitCode = 0;
  } catch (e) { stdout = String(e.stdout ?? '').slice(0, 65536); stderr = String(e.stderr ?? '').slice(0, 65536); error = String(e.message).slice(0, 512); exitCode = typeof e.code === 'number' ? e.code : null; exitSignal = typeof e.signal === 'string' ? e.signal : null; }
  const report = json({ version: 'runtime-probe-0.1', runtime, files, environment: observedEnvironment(), commandArguments: ['--version'], stdout, stderr, exitCode, exitSignal, error,
    status: error ? 'failed' : 'version-command-succeeded', limitations: ['Executes only a user-approved trusted binary; not a malicious-code sandbox.', 'No model download/load or inference. Successful version command does not prove ISA, model-format, inference-kernel or memory compatibility.', 'Hash checking is a point-in-time check; protect files against concurrent replacement.', 'Only explicitly listed dependencies are hashed. Runtime metadata and version labels are operator-supplied.'] });
  return json({ ...report, reportDigest: digest(report) });
}
