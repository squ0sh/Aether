# Aether v0.23.0-dev — Experimental candidate runner

Built from v0.22.0-dev, source ZIP SHA-256
`46ce065c6ed9fada1ba3d63e79e89d3c216ca23bd39ac6e02cd4ce9d14cd0e14`.
The existing app and all six benchmark modules are unchanged. New behavior is
confined to the separate experiment library, CLI commands and tests.

## Delivered

- A strict candidate manifest with model/runtime pins, context and output limits,
  fixed protocol, license review and explicit local-inference approval.
- Three disabled planning manifests with exact source revisions, declared hashes
  and sizes: Qwen3-1.7B Q8_0, Bonsai-1.7B Q1_0, Ternary-Bonsai-1.7B Q2_0.
- A separately approved runtime-only `--version` probe before weights are needed,
  with portable sibling-library resolution and untouched system environments.
- A loopback-only model advertisement/generation probe and frozen benchmark
  runner for an operator-started compatible server. No model server is launched.
- Bounded responses/timeouts, cancellation, no automatic retries/tools/repair,
  raw completion retention and failure-latched transport.
- Private, non-overwriting evidence reports and guarded experiment comparisons.

No model downloads, runtime installations/builds, real-model tests, training,
automatic promotion, live-chat changes or repository push were performed.
Larger models and unspecified alignment variants remain deferred.

## Verification

Final results: **602 regression tests passed**, including **32 focused experiment
tests**; zero failures, cancelled or skipped. The separate **32-cycle recovery
soak passed**. No real-model performance or cognitive result is included.

The [generated verification report](EXPERIMENT-v0.23.0-results.json) consumes
completed test and soak logs and refuses failed, missing or skipped results.
The focused suite covers schema/approval/bounds, file pins, endpoint isolation,
redirects, identity mismatch, incomplete output, tool calls, oversize/invalid
responses, cancellation, concurrent requests, raw-output preservation, held-out
approval, CLI non-overwrite/private output, portable library environments and a
weight-free version probe using trusted Node.

A synthetic HTTP server completes the full 95-case frozen corpus: the reference
still yields 90 PASS and five PARTIAL for absent semantic judgments. This tests
the instrument's transport, not model intelligence. The malformed-output fixture
remains an operational failure instead of being silently repaired.

Application/benchmark/experiment syntax checks, full regression tests and the
existing 32-cycle recovery soak are run before packaging. Exact counts and
completed timings are in the verification report, not projected from plans.

## Important review limits

Read the [experiment protocol](EXPERIMENT-v0.23.0.md). Files on disk are hashed,
but correspondence to the separate server process is operator-attested, not
authenticated. Runtime version success is not ISA/model-kernel certification.
Client cancellation does not establish server cancellation. There is no hostile
executable sandbox, hard server RAM limit or authenticated context enforcement.

Only disk sizes and client roundtrip times are measured; token usage is server-
reported. Other resource fields remain unknown. Q8 versus 1-bit versus ternary
is not a controlled bit-width-only comparison. Runtime, training, build, template,
tokenizer and hardware remain potential confounders.

No Ivy Bridge, x86, accelerator or model family becomes an Aether requirement.
Portability remains a design constraint; this release was tested on one host,
not every supported operating system or device.

Next: review the manifests and protocol with Cal, then separately approve the
exact runtime/model acquisition and the first bounded physical experiment.
