# Experimental Candidate Runner v0.1

This is the operational bridge from the frozen v0.22 benchmark to a compatible
local inference server, not a new Aether ontology or a Resident selection policy.
It does not download weights, install/build runtimes, start model servers, train,
change live chat, or select/adopt a model. The initial delivery uses synthetic
HTTP tests and Node's version command only. No Bonsai/Qwen inference result is
claimed.

Source direction: [Cal/user experiment review](https://chatgpt.com/s/t_6aaf114fd6c481918a2da69c349effa4).
The [v0.22 benchmark contract](RESIDENT-BENCHMARK-v0.1.md) still applies unchanged.

## Staged experiment

1. Review the candidate catalog, licenses, exact artifacts and intended budgets.
2. Obtain a trusted compatible runtime separately, pin its executable/dependencies,
   and explicitly approve the runtime-only version probe. This needs no weights.
3. Approve acquisition of only the smallest representative weights separately.
   This release has no downloader; hashes must match before contacting a server.
4. Start the selected server separately, bind it to loopback, configure context,
   disable silent context truncation/shift, and attest which pinned files it uses.
5. Run a bounded compatibility request. Successful text generation is not a
   benchmark pass, nor does a version command prove model-kernel compatibility.
6. Explicitly run the frozen corpus, inspect dimension/contract and operational
   results separately from resources, and review with Cal before expanding.
7. Consider 4B and then 8B only after that review. No automatic advancement;
   27B is outside this experiment. No survivor automatically becomes Resident.

Ivy Bridge is one intended test host, not a required architecture. Candidate
representation/runtime fields accept future implementations. The first transport
is loopback OpenAI-compatible chat HTTP, not a requirement that Aether permanently
use this API. Other adapters can be added without changing the benchmark.

## Candidate manifest and provenance

The catalog and three planning manifests include exact repository revisions,
filenames, repository-declared SHA-256 hashes, sizes and declared licenses from
Hugging Face API metadata. The import script reads saved metadata offline and
never fetches weights. Metadata is not an independent verification of weights
or license suitability; local hashing and explicit license review remain required.

- Conventional: Qwen3-1.7B Q8_0 from Qwen's repository, 1,834,426,016 bytes.
- Binary: Bonsai-1.7B Q1_0, 248,302,272 bytes.
- Ternary: Ternary-Bonsai-1.7B Q2_0, 463,290,464 bytes.

Sources and immutable revisions are in [the catalog](EXPERIMENT-v0.23.0-catalog.json).
These are nominal 1.7B labels, not independently verified exact parameter counts.
The conventional Q8 artifact is a related-model baseline, NOT a matched-bit-rate
or causal experiment. SmolLM/tinier conventional candidates and unspecified
alignment variants remain pending, not guessed. PQ2_0 and Q2_0 differ: neither
filename nor hash may be silently substituted. Runtime support must be probed
for that exact file and build; a family-wide fork requirement is not assumed.

All supplied manifests are intentionally disabled: local model path, runtime and
connection are null; approvals are false. `plan` validates offline without
running a binary, contacting a server or downloading anything:

```sh
npm run experiment:candidate -- plan docs/EXPERIMENT-ternary-manifest.json
```

For a future approved run, make a private copy outside the release tree and fill
in the actual local paths and runtime metadata. Runtime object shape:

```json
{
  "id": "your-runtime-id",
  "version": "observed version",
  "revision": "pinned source commit or release identity",
  "build": "compiler/build options, backend and relevant configuration",
  "source": "portable",
  "localPath": "/absolute/path/to/llama-server",
  "sha256": "REPLACE_WITH_ACTUAL_64_CHARACTER_SHA256",
  "dependencies": []
}
```

List known bundled shared libraries as `{localPath,sha256}` dependency entries.
The tool verifies listed files but cannot establish dependency completeness.
`source: system` leaves the environment unchanged. Portable Linux/macOS probes
prepend the executable directory to LD_LIBRARY_PATH/DYLD_LIBRARY_PATH while
preserving existing values. There is no global environment or system edit.

Save that runtime object separately for the weight-free version probe:

```sh
npm run experiment:runtime -- /absolute/runtime.json /absolute/new-runtime-report.json --allow-runtime-execution
```

Only `--version` is executed, never a shell or arbitrary manifest arguments. It
has a finite timeout, bounded output and recorded exit code/signal. Binaries
must be trusted: this is not a sandbox for hostile executables. Hash checking is
point-in-time and does not protect against concurrent file replacement.

Connection object shape for the later, separately approved inference stage:

```json
{
  "origin": "http://127.0.0.1:8081",
  "modelId": "exact-server-advertised-alias",
  "operatorAttestation": true,
  "contextTokens": 8192,
  "startupDescription": "Record actual runtime flags, backend, threads, context, chat template and thinking configuration; no secrets"
}
```

This example does not recommend a particular context size or port; choose values
the host can sustain. Confirm `approval.localInference` and `licenseReviewed` in
the manifest only after review. A held-out partition also requires operator
isolation confirmation, but a boolean does not create isolation or secrecy.

```sh
npm run experiment:candidate -- probe /absolute/manifest.json /absolute/new-probe.json --allow-local-inference
npm run experiment:candidate -- run /absolute/manifest.json /absolute/new-run.json --allow-local-inference
```

Each command reserves a new owner-private report before work. Existing paths
are never overwritten. Keep reports private: they include local paths, raw
responses, host metadata and startup descriptions. Do not commit live reports
or held-out cases/results. SIGINT/SIGTERM request cancellation; HTTP abort does
not prove the server stopped generating. Inspect the separately managed server
before trying another experiment after timeout/cancellation.

## Fixed protocol and failure handling

The candidate receives only the benchmark's allowlisted view, never expected
answers/assertions. Fixed system instructions describe the output shape. Each
case is a fresh chat request; no preceding answers, evaluation feedback, repair,
automatic retries, tools, grammar forcing or prompt adaptation are supplied.
Temperature, seed and output cap are manifest-pinned. Tokenization/templates and
runtime nondeterminism can still differ. Thinking-mode and startup settings must
be recorded; changing them is another experimental condition.

Only literal loopback HTTP origins are accepted, including IPv6 loopback. DNS
names, remote origins, credentials, URL paths and redirects are refused. Only
the model-list and chat-completion routes are used. The advertised and returned
model identifiers must match the configured alias. This is a consistency check,
NOT authentication of which weights the server actually loaded.

Hash verification happens before endpoint contact. HTTP/body-size/model-identity,
tool-call, incomplete-completion and timeout failures latch the candidate off:
remaining cases become operational failures without further inference. Schema
failures retain raw text and are scored by the frozen evaluator, not repaired.
The compatibility probe is recorded separately and is not scored.

The inherited benchmark caps each call at 60 seconds. Slow CPUs may exceed this;
that is an operational limitation, not proof of poor cognition. Total timeout
includes local file hashing. Context size is operator-attested; this version
does not authenticate server configuration or count tokens through its chat
template. Do not accept silent server-side truncation as a valid comparison.

## Measurement, comparison and interpretation

Model/runtime disk sizes are measured while hashing. Request duration is client
roundtrip time, not isolated model latency. Token usage is explicitly endpoint-
reported; TTFT, prompt latency, peak RAM, CPU utilization, throughput and energy
remain unknown. No resource score is inferred from bits/weight or architecture.
An external, attributed measurement method is needed for those physical metrics
before making performance claims.

`compareExperiments` validates report digests and requires identical benchmark,
protocol, context setting, operational limits and corpus. It preserves dimension
profiles and flags runtime/environment differences. Hashes are not signatures.
Differences in training, tokenizer, template, runtime, build or hardware prevent
causal attribution to ternary/binary representation alone. No automatic ranking,
promotion or adaptation happens. Public seeded cases remain development data;
fresh seeds alone are not genuine held-out evaluation.

The lock records all six unchanged benchmark modules. Existing app, Field,
Resident and UI sources are untouched. Tests run on the current host only;
other hardware/OS support remains a design goal requiring actual verification.
