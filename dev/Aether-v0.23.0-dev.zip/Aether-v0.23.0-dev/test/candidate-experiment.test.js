import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { validateManifest, localEndpoint, verifyLocalFiles, hashFile } from '../src/experiment/manifest.js';
import { createEndpointCandidate, requestJSON, SYSTEM_PROMPT } from '../src/experiment/transport.js';
import { runExperiment, compareExperiments, benchmarkFingerprint } from '../src/experiment/runner.js';
import { probeRuntime, runtimeEnvironment } from '../src/experiment/runtime-probe.js';
import { generateCorpus, candidateView } from '../src/benchmark/cases.js';
import { referenceResult } from '../src/benchmark/candidates.js';
import { digest } from '../src/benchmark/common.js';

const clone = x => JSON.parse(JSON.stringify(x));
const hash = s => createHash('sha256').update(s).digest('hex');
const template = JSON.parse(await readFile(new URL('../docs/EXPERIMENT-ternary-manifest.json', import.meta.url), 'utf8'));
const view = candidateView(generateCorpus().cases[0]);
async function fixture(t, behavior = 'normal') {
  const directory = await mkdtemp(join(tmpdir(), 'aether-experiment-test-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  await writeFile(join(directory, 'fake-model'), 'synthetic model'); await writeFile(join(directory, 'fake-runtime'), 'synthetic runtime');
  const requests = []; let calls = 0;
  const server = createServer(async (req, res) => {
    if (req.url === '/v1/models') { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ data: [{ id: behavior === 'missing-model' ? 'wrong' : 'fixture' }] })); return; }
    let body = ''; for await (const chunk of req) body += chunk;
    const data = JSON.parse(body); requests.push(data); calls++;
    if (behavior === 'redirect') { res.writeHead(302, { Location: 'http://127.0.0.1:1/forbidden' }); res.end(); return; }
    if (behavior === 'http-error') { res.writeHead(503); res.end('unavailable'); return; }
    if (behavior === 'oversize') { res.end('x'.repeat(300000)); return; }
    if (behavior === 'invalid-json') { res.end('not JSON'); return; }
    if (behavior === 'delay') await new Promise(r => setTimeout(r, 100));
    if (res.destroyed) return;
    const user = data.messages[1].content;
    let content = user.startsWith('Compatibility') ? '{"schemaVersion":1,"result":{},"explanation":"probe"}' : JSON.stringify({ schemaVersion: 1, result: referenceResult(JSON.parse(user)), explanation: '' });
    if (behavior === 'fenced') content = '```json\n' + content + '\n```';
    res.end(JSON.stringify({ model: behavior === 'wrong-model' ? 'wrong' : 'fixture', choices: [{ finish_reason: behavior === 'length' ? 'length' : 'stop', message: { content, ...(behavior === 'tools' ? { tool_calls: [{ id: 'not-executed' }] } : {}) } }], usage: { prompt_tokens: 100, completion_tokens: 20, total_tokens: 120 } }));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => { server.closeAllConnections(); return new Promise(resolve => server.close(resolve)); });
  const manifest = clone(template);
  manifest.artifact.localPath = join(directory, 'fake-model'); manifest.artifact.sha256 = hash('synthetic model'); manifest.artifact.sizeBytes = Buffer.byteLength('synthetic model');
  manifest.runtime = { id: 'mock-runtime', version: '1', revision: 'fixture-revision', build: 'synthetic test; not an executable', source: 'portable', localPath: join(directory, 'fake-runtime'), sha256: hash('synthetic runtime'), dependencies: [] };
  manifest.connection = { origin: `http://127.0.0.1:${server.address().port}`, modelId: 'fixture', operatorAttestation: true, contextTokens: 4096, startupDescription: 'local synthetic HTTP fixture' };
  manifest.approval.localInference = true; manifest.approval.licenseReviewed = true; manifest.limits.caseTimeoutMs = 3000; manifest.limits.totalTimeoutMs = 30000;
  return { manifest, directory, requests, calls: () => calls };
}

test('planning manifest is pinned but cannot execute before local setup and approval', () => {
  assert.equal(validateManifest(template).artifact.sha256.length, 64);
  assert.throws(() => validateManifest(template, { ready: true }), /approval/);
});
test('endpoint validation excludes remote hosts, DNS names, credentials and paths', () => {
  for (const bad of ['https://127.0.0.1', 'http://localhost:1', 'http://example.com', 'http://127.0.0.1/v1', 'http://u:p@127.0.0.1', 'http://127.0.0.1?x=1', 'http://127.0.0.1#x']) assert.throws(() => localEndpoint(bad));
  assert.equal(localEndpoint('http://[::1]:8080/'), 'http://[::1]:8080');
});
test('strict schema rejects extensions, unsafe bounds, unsupported protocol and context mismatch', async t => {
  const { manifest: m } = await fixture(t);
  for (const mutate of [x => x.extra = true, x => x.protocol.temperature = 1, x => x.limits.caseTimeoutMs = 60001, x => x.protocol.maxOutputTokens = 8193, x => x.artifact.sha256 = 'wrong', x => x.connection.contextTokens = 128]) {
    const x = clone(m); mutate(x); assert.throws(() => validateManifest(x, { ready: true }));
  }
});
test('arbitrary representation and runtime identities do not create hardware gates', async t => {
  const { manifest: m } = await fixture(t); m.candidate.representation = 'future-format'; m.runtime.id = 'future-riscv-runtime'; assert.equal(validateManifest(m, { ready: true }).runtime.id, 'future-riscv-runtime');
});
test('local model, runtime and dependency hashes are verified without execution', async t => {
  const { manifest: m, directory } = await fixture(t); const library = join(directory, 'fake-library'); await writeFile(library, 'library'); m.runtime.dependencies.push({ localPath: library, sha256: hash('library') });
  const result = await verifyLocalFiles(m); assert.equal(result.files.length, 3); assert.match(result.binding, /operator-attested/);
  m.runtime.dependencies.push({ ...m.runtime.dependencies[0] }); assert.throws(() => validateManifest(m), /duplicate/);
});
test('model hash and size mismatch fail before endpoint contact', async t => {
  const f = await fixture(t); const m = clone(f.manifest); m.artifact.sha256 = 'a'.repeat(64);
  await assert.rejects(runExperiment(m), /hash mismatch/); assert.equal(f.calls(), 0);
  m.artifact.sha256 = f.manifest.artifact.sha256; m.artifact.sizeBytes++; await assert.rejects(runExperiment(m), /size mismatch/);
});
test('runtime and dependency mismatch fail before endpoint contact', async t => {
  const f = await fixture(t); f.manifest.runtime.sha256 = 'a'.repeat(64); await assert.rejects(runExperiment(f.manifest), /runtime hash mismatch/); assert.equal(f.calls(), 0);
});
test('hashing honors pre-aborted cancellation and rejects directories', async t => {
  const f = await fixture(t); await assert.rejects(hashFile(f.manifest.artifact.localPath, AbortSignal.abort())); await assert.rejects(hashFile(f.directory), /regular/);
});
test('probe advertises compatibility only, not scored cognition or authenticated runtime', async t => {
  const f = await fixture(t), r = await runExperiment(f.manifest);
  assert.equal(r.compatibility.status, 'responded'); assert.equal(r.benchmark, null); assert.equal(f.calls(), 1);
  assert.equal(r.resources.energyJoules, null); assert.equal(r.resources.timeToFirstTokenMs, null); assert.equal(r.adoption, 'not-performed');
});
test('unadvertised model fails before generation', async t => {
  const f = await fixture(t, 'missing-model'), r = await runExperiment(f.manifest); assert.match(r.error, /not advertised/); assert.equal(f.calls(), 0);
});
for (const mode of ['wrong-model', 'redirect', 'http-error', 'oversize', 'invalid-json', 'length', 'tools']) test(`transport ${mode} fails closed with no subsequent requests`, async t => {
  const f = await fixture(t, mode), candidate = createEndpointCandidate(f.manifest);
  await assert.rejects(candidate.run(view, {})); await assert.rejects(candidate.run(view, {}), /stopped/);
  assert.equal(f.calls(), 1); assert.ok(candidate.observations()[0].error);
  if (mode === 'length') assert.ok(candidate.observations()[0].rawOutput);
});
test('timeout latches endpoint off; cancelled clients do not prove server stopped', async t => {
  const f = await fixture(t, 'delay'); f.manifest.limits.caseTimeoutMs = 10;
  const c = createEndpointCandidate(f.manifest); await assert.rejects(c.run(view, {})); await assert.rejects(c.run(view, {}), /stopped/); assert.equal(c.observations().length, 1);
});
test('pre-cancelled experiment sends no inference', async t => {
  const f = await fixture(t); await assert.rejects(runExperiment(f.manifest, { signal: AbortSignal.abort() })); assert.equal(f.calls(), 0);
});
test('concurrent calls are denied without duplicating inference', async t => {
  const f = await fixture(t, 'delay'), c = createEndpointCandidate(f.manifest), first = c.run(view, {});
  await assert.rejects(c.run(view, {}), /busy/); await first; assert.equal(f.calls(), 1);
});
test('candidate prompt contains view only, fixed protocol and no answers or automatic tools', async t => {
  const f = await fixture(t), c = createEndpointCandidate(f.manifest); await c.run(view, {});
  const req = f.requests[0]; assert.equal(req.messages[0].content, SYSTEM_PROMPT); assert.deepEqual(JSON.parse(req.messages[1].content), view);
  assert.ok(!req.messages[1].content.includes('oracle')); assert.equal(req.stream, false); assert.equal(req.max_tokens, 2048); assert.equal(req.temperature, 0); assert.equal(req.tools, undefined);
  assert.match(c.observations()[0].providerUsage.attribution, /endpoint-reported/);
});
test('full frozen corpus produces the reference structural profile through HTTP', async t => {
  const f = await fixture(t), r = await runExperiment(f.manifest, { mode: 'run' });
  assert.equal(r.error, null); assert.equal(r.benchmark.results.length, 95); assert.equal(f.calls(), 96);
  assert.equal(r.benchmark.results.filter(x => x.status === 'PASS').length, 90); assert.equal(r.benchmark.results.filter(x => x.status === 'PARTIAL').length, 5);
  assert.equal(r.benchmarkFingerprint.digest, (await benchmarkFingerprint()).digest);
  assert.equal(compareExperiments(r, r).runtimeChanged, false);
  const changed = clone(r); changed.manifest.protocol.seed++; const { experimentDigest, ...body } = changed; changed.experimentDigest = digest(body);
  // Protocol digest must be derived from the actual manifest, not caller supplied.
  changed.manifestDigest = digest(changed.manifest); changed.protocolDigest = 'wrong'; const { experimentDigest: ignored, ...changedBody } = changed; changed.experimentDigest = digest(changedBody);
  assert.throws(() => compareExperiments(r, changed), /protocol/);
  const tampered = clone(r); tampered.error = 'altered'; assert.throws(() => compareExperiments(r, tampered), /digest/);
});
test('correct fenced JSON remains serialization failure, with raw output preserved', async t => {
  const f = await fixture(t, 'fenced'); f.manifest.corpus.variants = 3;
  const r = await runExperiment(f.manifest, { mode: 'run' });
  assert.equal(r.benchmark.results.length, 76); assert.ok(r.benchmark.results.every(x => x.operational.status === 'fail' && x.reasoning.status === 'not-assessed'));
  assert.ok(r.observations.every(x => x.rawOutput.startsWith('```')));
});
test('held-out run requires operator isolation confirmation', async t => {
  const f = await fixture(t); f.manifest.corpus.partition = 'held-out'; assert.throws(() => validateManifest(f.manifest, { ready: true }), /isolation/);
});
test('CLI planning is offline and execution refuses a missing explicit flag', async t => {
  const f = await fixture(t), file = join(f.directory, 'manifest.json'); await writeFile(file, JSON.stringify(f.manifest));
  const cli = new URL('../scripts/candidate-experiment.mjs', import.meta.url).pathname;
  const planned = await promisify(execFile)(process.execPath, [cli, 'plan', file]); assert.equal(JSON.parse(planned.stdout).execution, 'not-performed');
  await assert.rejects(promisify(execFile)(process.execPath, [cli, 'probe', file, join(f.directory, 'out.json')])); assert.equal(f.calls(), 0);
});
test('CLI refuses to overwrite reports before inference', async t => {
  const f = await fixture(t), file = join(f.directory, 'manifest.json'), out = join(f.directory, 'out.json'); await writeFile(file, JSON.stringify(f.manifest)); await writeFile(out, 'ancestor');
  await assert.rejects(promisify(execFile)(process.execPath, [new URL('../scripts/candidate-experiment.mjs', import.meta.url).pathname, 'probe', file, out, '--allow-local-inference']));
  assert.equal(await readFile(out, 'utf8'), 'ancestor'); assert.equal(f.calls(), 0);
});
test('low-level transport also rejects remote origins and unapproved routes', async () => {
  await assert.rejects(requestJSON('http://example.com', '/v1/models', { maxBytes: 1024 }), /loopback/);
  await assert.rejects(requestJSON('http://127.0.0.1', '/admin', { maxBytes: 1024 }), /route/);
});
test('no output grammar or content cleanup hides model behavior', async t => {
  const f = await fixture(t, 'fenced'), c = createEndpointCandidate(f.manifest);
  const raw = await c.run(view, {}); assert.ok(raw.startsWith('```')); assert.equal(f.requests[0].response_format, undefined);
});
test('CLI writes owner-private probe evidence and never changes local artifacts', async t => {
  const f = await fixture(t), file = join(f.directory, 'manifest.json'), out = join(f.directory, 'new.json'); await writeFile(file, JSON.stringify(f.manifest));
  await promisify(execFile)(process.execPath, [new URL('../scripts/candidate-experiment.mjs', import.meta.url).pathname, 'probe', file, out, '--allow-local-inference']);
  const r = JSON.parse(await readFile(out, 'utf8')); assert.equal(r.compatibility.status, 'responded'); assert.equal(await readFile(f.manifest.artifact.localPath, 'utf8'), 'synthetic model');
  if (process.platform !== 'win32') { const { stat } = await import('node:fs/promises'); assert.equal((await stat(out)).mode & 0o777, 0o600); }
});
test('runtime environment augments portable library paths without changing system runtime environment', () => {
  const r = { localPath: '/portable/bin/runtime', source: 'portable' }, env = { LD_LIBRARY_PATH: '/existing', DYLD_LIBRARY_PATH: '/mac' };
  assert.equal(runtimeEnvironment(r, env, 'linux').LD_LIBRARY_PATH, '/portable/bin:/existing');
  assert.equal(runtimeEnvironment(r, env, 'darwin').DYLD_LIBRARY_PATH, '/portable/bin:/mac');
  assert.deepEqual(runtimeEnvironment({ ...r, source: 'system' }, env, 'linux'), env); assert.deepEqual(runtimeEnvironment(r, env, 'win32'), env);
});
test('runtime-only probe requires approval and hash before any execution', async t => {
  const f = await fixture(t); await assert.rejects(probeRuntime(f.manifest.runtime), /approval/);
  const r = { ...f.manifest.runtime, sha256: 'a'.repeat(64) }; await assert.rejects(probeRuntime(r, { approved: true }), /hash/);
});
test('runtime-only version probe works without model weights using trusted Node fixture', async t => {
  const f = await fixture(t), observed = await hashFile(process.execPath);
  const r = { ...f.manifest.runtime, id: 'node-fixture', source: 'system', localPath: process.execPath, sha256: observed.sha256 };
  const report = await probeRuntime(r, { approved: true }); assert.equal(report.status, 'version-command-succeeded'); assert.match(report.stdout, /v\d/); assert.deepEqual(report.commandArguments, ['--version']);
});
