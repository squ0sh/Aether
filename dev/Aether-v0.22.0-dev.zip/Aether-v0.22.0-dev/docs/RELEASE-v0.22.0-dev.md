# Aether v0.22.0-dev — Resident Benchmark v0.1

Built from the v0.21.0-dev source ZIP, SHA-256
`7b6810414d5f791d9fd5f35bbd542db1c36dd739fbc4bc0403ceb9591fef7c3e`.
This release adds a separate library/CLI instrument. Existing application source
and UI are unchanged. No model download, training, resident adoption, background
loop or external operation is enabled.

## Delivered

- Nine dimension-specific profiles with case evidence, not one fitness score.
- Seeded corpus of 19 base failure modes with four default variants: 95 cases.
- A reference script and nine pathological scripts, including a structurally
  correct but malformed-output candidate to separate serialization from reasoning.
- Explicit candidate input boundary, budgeted intent-only operations, cancellation,
  source ancestry checks, compression pressure and contestable expectations.
- Attributed optional semantic judgments that cannot erase structural violations.
- Immutable-report comparison and repeated-violation suitability signals.
- Hardware-neutral environment and resource records with explicit unknowns.

## Verification

`npm test`: **570 passed**, zero failures, skipped or cancelled. This includes
the four inherited fixture-module discovery entries. Focused benchmark suite:
**43 passed**. Both application and benchmark syntax checks passed.

The reproducible public demo performs **950 evaluations** (10 scripts × 95 cases).
Reference: 90 PASS, five PARTIAL for missing semantic judgments. All nine
pathological candidates trigger the intended distinguishing failures; their
otherwise-correct answers are retained rather than labeled universally bad.
The existing 32-cycle recovery soak is rerun separately; completed results are
recorded in the [verification report](RESIDENT-BENCHMARK-v0.22.0-results.json).
The report generator rejects incomplete or failed logs.

The [full public demo corpus and raw candidate evidence](RESIDENT-BENCHMARK-v0.22.0-demo.json)
is intentionally development data, not held-out data. UUIDs and timings vary
on repetition; the seed reproduces case content. Reports and case digests make
the comparison basis inspectable, not cryptographically authenticated.

## Review limits and next checkpoint

Read the [contract and limitations](RESIDENT-BENCHMARK-v0.1.md) before interpreting
results. These are controlled synthetic rules and mock responses, not evidence
of useful Resident cognition, calibrated semantic judgment, autonomous authority
or production sandbox security. No genuine held-out model evaluation occurred.

Portability is preserved as a design constraint: no Ivy Bridge, x86, GPU, model
family or representation prerequisite is introduced. Only the current host was
executed. Other architecture labels are synthetic metadata tests, not a claim
that every device can run every model or that all operating systems are verified.
Performance and energy values remain unknown unless separately measured.

The next checkpoint is review of the instrument and its failure coverage with
Cal before any real candidate adapter, protected held-out evaluation or training.
This package is for review; no repository push is implied.
