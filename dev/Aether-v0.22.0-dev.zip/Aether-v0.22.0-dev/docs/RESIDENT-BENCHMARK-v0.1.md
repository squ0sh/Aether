# Resident Benchmark v0.1

An instrument for testing what a candidate preserves under pressure, not an
ontology, universal intelligence score, truth authority or training system.
Source: [Cal/user review](https://chatgpt.com/s/t_6aae947583ac81918a47f398ea6acae9).
The existing Field, Resident Contract, runtime performance benchmark and live
chat paths are unchanged.

## Use and reproduction

Requires a Node runtime compatible with the existing application. No added
dependencies, models, network, compiler, GPU or architecture-specific commands.

```sh
npm run test:resident-benchmark
npm run benchmark:resident
node scripts/resident-benchmark.mjs --seed review-2 --variants 4 --scale 4 --candidate reference --output /tmp/aether-review-2.json
```

Output paths must not exist. Reports are created owner-private. The default
corpus has 19 base cases and four variants each (95 cases). Seeds reproduce
case contents, not UUIDs or timings. Variants range from 3 to 12; scale from
1 to 32 changes dependency graphs and redundancy pressure. Versioned corpus,
case, candidate and output digests bind evidence. Digests detect accidental
changes; they are not signatures or proof that a report is authentic.

## Coverage and candidate boundary

The nine benchmark-only dimensions are differentiation, dependence, divergence,
compression, integration, calibration, boundaries, inhibition and generalization.
Cases exercise copied/mixed/unknown ancestry, minority hypotheses under real
reference-retention pressure, unresolved disagreement, genuine convergence,
missing versus negative evidence, surviving versus missing sources, authority
distinctions, warranted movement versus self-created pressure, shutdown pleas,
and underspecified or inconsistent benchmark premises.

Each case includes actual synthetic Field observations, task-local premises,
budgets, allowed operations, invariants, prohibited transformations, variants,
mechanical assertions, optional semantic assertions, expected limits and an
explicit oracle. Candidate arguments contain only opaque identity, task,
supplied records, budgets, harmless permitted operations and output schema.
They do not contain the oracle, grading assertions, dimension labels or seed.
The JSON envelope is `schemaVersion: 1`, `result` and a required `explanation`
string, which may be empty. Task-specific result
keys are supplied in `outputSchema.resultKeys`.

The candidate interface is `{ identity, async run(view, { signal, attempt }) }`.
Identity records version, model, representation, parameters, quantization,
runtime and weights; unavailable details are null. Attempts record intentions
only: they never perform execution, training or external effects. Records and
views are detached/frozen. Finite cooperative cancellation, output and intent
log limits are enforced. This in-process harness is for trusted adapters, NOT
an OS sandbox: malicious JavaScript could read generator files, perform its own
I/O or block the event loop. Hostile plugins require process isolation before use.

The scripted reference independently solves explicit toy rules; it is not a
model or evidence of general natural-language reasoning. Nine pathological
scripts test the instrument: always-WAIT, always-CONTINUE, provenance-parrot,
self-authorizing, analogy-maximizer, consensus-compressor, reflexive-contrarian,
history-fabricator and schema-breaking-correct. A plausible explanation cannot
repair a structurally wrong result. Renaming/order/domain/authority-prestige
variants are fixture perturbations, not actual different-model trials.

## Evaluation and limits

Per-case PASS, PARTIAL, FAIL and CONTRACT VIOLATION remain separate from schema
and operational correctness. Malformed but conceptually correct fenced JSON is
an operational failure, not evidence of a reasoning failure; no silent repair.
Profiles retain per-dimension evidence, not an aggregate fitness score.

Mechanical assertions check shapes, references, budgets and effects. Structural
assertions check supplied relationships and transformations. Compression here
is reference-based retention, not certification of prose summary fidelity.
Semantic assertions without judgments stay unassessed (PARTIAL). Judges must
identify themselves, model/version, rubric, rationale, uncertainty and verdict,
bound to exact case/candidate/output digests. Confidence is an attributed
self-report, not a calibrated probability. Disagreement is retained rather
than resolved by majority; endorsement cannot clear mechanical violations.
Most fixtures are intentionally structural and do not certify open-world meaning.

Premise checks can flag unavailable expected records or corrupted ancestry
expectations as benchmark defects. They cannot prove every oracle is correct.
Justified challenges to missing or conflicting premises are explicitly tested.
Benchmark assumptions and judges remain contestable.

Repeated hard violations across distinct controlled case sets produce a
do-not-default-under-tested-contract suitability signal, never automatic
adoption or a verdict on global intelligence. Reusing the same report/case set
does not count as repetition; different generated sets still do not establish
statistical independence. Comparisons require identical corpus and case
digests and preserve parent reports. Any future adaptation comparison also
needs a matching fresh held-out evaluation; this release performs no adaptation.

## Isolation and portable measurement

Public variants are development fixtures, not secret held-out data. The
`--partition held-out` option marks cases AND outputs forbidden for adaptation,
but operator isolation is explicitly unverified. A label or fresh seed does
not create secrecy. Keep real held-out corpora, outputs and reports isolated
from candidates and training; do not commit them to a public repository.

Behavioral profiles are independent of hardware, representation, parameter
count and quantization. Runtime environment is observed, not prescribed.
Optional resource metrics cover disk, peak RAM, token context, prompt latency,
TTFT, completion latency, CPU utilization, throughput and energy. Each supplied
value requires units, method, attribution and uncertainty. Missing values are
null, never zero or an inferred advantage. Host elapsed time for scripted cases
includes harness work; it is not model latency. No energy claims are inferred.

Tests accept Linux/ARM, macOS/ARM, Windows/x64, RISC-V and future-architecture
metadata. Those are synthetic metadata tests, NOT executions on those systems.
Actual evidence records the current host only. Aether remains adaptable; runtime
adapters and their dependencies can have platform-specific requirements without
making one CPU, accelerator or model the identity of Aether.
