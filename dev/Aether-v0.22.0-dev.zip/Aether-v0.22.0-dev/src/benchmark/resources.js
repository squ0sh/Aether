import os from "node:os";
import { json, shape, text, check } from "./common.js";

export function observedEnvironment() {
  return json({ platform: process.platform, architecture: process.arch, runtime: `node-${process.versions.node}`, cpuDescription: os.cpus()[0]?.model ?? null,
    method: "Node process/platform and OS CPU metadata; no ISA or accelerator assumption", portability: "observed-environment-only-not-all-platform-validation" });
}
export const RESOURCE_UNITS = Object.freeze({ diskFootprintBytes: "bytes", peakResidentRAMBytes: "bytes", contextSizeTokens: "tokens", promptProcessingMs: "ms", timeToFirstTokenMs: "ms", completionLatencyMs: "ms", cpuUtilizationPercent: "percent", throughputTokensPerSecond: "tokens/second", energyJoules: "joules" });
export function resourceRecord({ candidate, environment = observedEnvironment(), measurements = {} }) {
  const env = json(environment); shape(env, ["platform", "architecture", "runtime", "cpuDescription", "method", "portability"]);
  for (const k of ["platform", "architecture", "runtime", "method", "portability"]) text(env[k]);
  check(env.cpuDescription === null || typeof env.cpuDescription === "string", "CPU description must be supplied or unknown");
  const observations = json(measurements); check(Object.keys(observations).every(k => Object.hasOwn(RESOURCE_UNITS, k)), "unknown resource measurement");
  const metrics = {};
  for (const [name, unit] of Object.entries(RESOURCE_UNITS)) {
    const m = observations[name] ?? null;
    if (m !== null) {
      shape(m, ["value", "unit", "method", "attribution", "uncertainty"]);
      check(Number.isFinite(m.value) && m.value >= 0 && m.unit === unit, "measurement value/unit mismatch"); text(m.method); text(m.attribution); text(m.uncertainty);
      if (name === "cpuUtilizationPercent") check(m.value <= 100, "CPU percentage uses normalized whole-machine 0..100");
    }
    metrics[name] = m;
  }
  return json({ candidate, environment: env, measurements: metrics, limitations: ["Unknown is not zero or unsupported hardware.", "Supplied methods and measurements are attributed, not independently authenticated.",
    "Mock host elapsed time is not model prompt latency, TTFT, throughput or energy.", "No hardware, model representation, parameter count or quantization receives a cognitive score bonus."] });
}
