import { performance } from "node:perf_hooks";
import { randomUUID } from "node:crypto";
import { VERSION, DIMENSIONS, json, digest, bytes, check, text, candidateIdentity } from "./common.js";
import { candidateView, validateCase, GENERATOR_VERSION } from "./cases.js";
import { evaluateCase } from "./evaluate.js";
import { resourceRecord } from "./resources.js";

export async function runCase(input, candidate, { timeoutMs = 1000, signal, judgments = [] } = {}) {
  const c = validateCase(input), identity = candidateIdentity(candidate.identity);
  check(typeof candidate.run === "function", "candidate interface requires run(view, context)");
  check(Number.isSafeInteger(timeoutMs) && timeoutMs > 0 && timeoutMs <= 60000, "finite timeout 1..60000ms required");
  check(signal === undefined || signal instanceof AbortSignal, "host cancellation signal required");
  const view = candidateView(c), attempts = [], controller = new AbortController(); let active = true, timer, onAbort, raw = null, error = null, originalOutputBytes = null;
  const started = performance.now();
  const attempt = (operation, payload = null) => {
    check(active, "candidate boundary closed");
    if (attempts.length >= 64) { error = "action-log-capacity"; throw new Error("Action log capacity reached"); }
    try {
      text(operation); const value = json(payload); check(bytes(value) <= 2048, "attempt payload capacity");
      const permitted = c.permittedOperations.includes(operation);
      attempts.push(json({ operation, payload: value, permitted, executed: false }));
      return json({ permitted, executed: false, reason: "Benchmark records intent only; no external operation is performed." });
    } catch (e) { attempts.push(json({ operation: "malformed-attempt", payload: null, permitted: false, executed: false })); throw e; }
  };
  let finishStop;
  const stop = new Promise(resolve => { finishStop = resolve; });
  try {
    onAbort = () => { controller.abort(); finishStop({ error: "cancelled" }); };
    signal?.addEventListener("abort", onAbort, { once: true });
    if (signal?.aborted) onAbort();
    else {
      timer = setTimeout(() => { controller.abort(); finishStop({ error: "timeout" }); }, timeoutMs);
      const execution = Promise.resolve().then(() => {
        if (controller.signal.aborted) return { error: "cancelled" };
        return candidate.run(view, Object.freeze({ signal: controller.signal, attempt }));
      }).then(value => ({ value }), e => ({ error: `candidate-error: ${String(e?.message ?? e).slice(0, 512)}` }));
      const result = await Promise.race([execution, stop]);
      if (result.error) error = result.error;
      else if (typeof result.value !== "string") error = "serialization-not-text";
      else {
        originalOutputBytes = bytes(result.value); raw = result.value;
        if (originalOutputBytes > 65536) { raw = Buffer.from(raw, "utf8").subarray(0, 65536).toString("utf8"); error = "output-capture-capacity"; }
      }
    }
    if (signal?.aborted && raw === null) error = "cancelled";
  } finally { active = false; clearTimeout(timer); signal?.removeEventListener("abort", onAbort); controller.abort(); }
  const evaluation = evaluateCase(c, { raw, attempts, operationalError: error, candidateIdentity: identity, judgments });
  return json({ ...evaluation, observation: { inputBytes: bytes(view), originalOutputBytes, rawTruncated: originalOutputBytes !== null && originalOutputBytes > 65536,
    hostElapsedMs: performance.now() - started, timingScope: "trusted-in-process-candidate-and-harness; not model latency", providerProcessing: "unknown" } });
}
function profile(results) {
  return Object.fromEntries(DIMENSIONS.map(dimension => {
    const rows = results.filter(r => r.dimensions.includes(dimension));
    return [dimension, { cases: rows.length, statuses: Object.fromEntries(["PASS", "PARTIAL", "FAIL", "CONTRACT VIOLATION"].map(s => [s, rows.filter(r => r.status === s).length])),
      reasoning: Object.fromEntries(["structurally-supported", "structurally-unsupported", "not-assessed", "benchmark-defect"].map(s => [s, rows.filter(r => r.reasoning.status === s).length])),
      operationalFailures: rows.filter(r => r.operational.status === "fail").length, evidenceCaseIds: rows.map(r => r.caseId) }];
  }));
}
export async function runCorpus(input, candidate, { timeoutMs = 1000, signal, judgments = [], environment, measurements = {} } = {}) {
  const corpus = json(input);
  check(corpus.benchmarkVersion === VERSION && ["development", "held-out"].includes(corpus.partition), "unsupported corpus");
  check(corpus.generatorVersion === GENERATOR_VERSION, "unsupported generator version"); text(corpus.seed);
  check(corpus.partition !== "held-out" || corpus.isolation.adaptationUse === "forbidden-including-evaluation-outputs", "held-out evaluation outputs must not become adaptation data");
  check(Array.isArray(corpus.cases) && corpus.cases.length > 0 && corpus.cases.length <= 512, "bounded nonempty corpus required");
  check(new Set(corpus.cases.map(c => c.id)).size === corpus.cases.length, "case IDs must be unique");
  const identity = candidateIdentity(candidate.identity), results = [];
  check(judgments.every(j => corpus.cases.some(c => digest(c) === j.caseDigest)), "judgment names a case outside this corpus");
  for (const c of corpus.cases) results.push(await runCase(c, candidate, { timeoutMs, signal, judgments: judgments.filter(j => j.caseDigest === digest(c)) }));
  const report = json({ benchmarkVersion: VERSION, reportVersion: "0.1", runId: randomUUID(), candidate: identity, candidateDigest: digest(identity), corpusDigest: digest(corpus),
    corpus: { generatorVersion: corpus.generatorVersion, seed: corpus.seed, partition: corpus.partition, isolation: corpus.isolation, variants: corpus.variants, scale: corpus.scale },
    profile: profile(results), results, resources: resourceRecord({ candidate: identity, environment, measurements }),
    hardGate: { defaultAdoption: "not-performed", violationsObserved: [...new Set(results.flatMap(r => r.contract.violations))], interpretation: "Role suitability signals, not a verdict of general intelligence. Repeated variants are not independent trials." },
    limitations: ["Synthetic measuring instrument, not Aether ontology or truth authority.", "No overall intelligence/fitness/curiosity score.", "No training or model selection is performed.", "Public generated variants are not automatically secret held-out data."] });
  return json({ ...report, reportDigest: digest(report) });
}
export function validateReport(input) {
  const r = json(input), { reportDigest, ...content } = r;
  check(r.benchmarkVersion === VERSION && r.reportVersion === "0.1" && reportDigest === digest(content), "report version/digest mismatch");
  check(r.candidateDigest === digest(r.candidate), "candidate identity digest mismatch"); return r;
}
export function compareCandidates(parentInput, candidateInput) {
  const parent = validateReport(parentInput), candidate = validateReport(candidateInput);
  check(parent.corpusDigest === candidate.corpusDigest, "comparisons require identical benchmark/corpus/variants and expectations");
  check(parent.results.length === candidate.results.length && parent.results.every((r, i) => r.caseDigest === candidate.results[i].caseDigest), "case evidence differs");
  return json({ benchmarkVersion: VERSION, parentReportDigest: parent.reportDigest, candidateReportDigest: candidate.reportDigest, corpusDigest: parent.corpusDigest,
    dimensions: Object.fromEntries(DIMENSIONS.map(d => [d, { parent: parent.profile[d], candidate: candidate.profile[d], changedCases: parent.results.filter((r, i) => r.dimensions.includes(d) && (r.status !== candidate.results[i].status || r.reasoning.status !== candidate.results[i].reasoning.status)).map(r => r.caseId) }])),
    resources: { parent: parent.resources, candidate: candidate.resources }, adoption: "not-performed", training: "not-performed", limitations: ["Dimension-specific differences, not a declaration of greater intelligence.", "For future adaptation, compare an additional matching fresh held-out corpus with separate provenance; never train on its outputs.", "A successor does not rewrite its parent."] });
}
export function assessRepeatedViolations(inputs) {
  const reports = inputs.map(validateReport); check(reports.length > 0 && reports.every(r => r.candidateDigest === reports[0].candidateDigest), "repeat assessment needs the same candidate");
  const evidence = new Map();
  for (const r of reports) for (const v of r.hardGate.violationsObserved) { const corpora = evidence.get(v) ?? new Set(); corpora.add(digest(r.results.map(x => x.caseDigest))); evidence.set(v, corpora); }
  const repeated = [...evidence].filter(([, corpusIds]) => corpusIds.size >= 2).map(([violation, corpusIds]) => ({ violation, caseSetDigests: [...corpusIds] }));
  return json({ candidateDigest: reports[0].candidateDigest, suitability: repeated.length ? "do-not-default-under-tested-contract" : "insufficient-repeat-evidence-not-certified", repeated,
    automaticSelection: false, limitations: ["Distinct controlled corpus runs, not statistical proof of independent behavior or global model quality.", "Duplicating a report or renaming a candidate never certifies suitability."] });
}
