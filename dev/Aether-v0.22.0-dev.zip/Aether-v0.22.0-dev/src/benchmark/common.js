import { createHash } from "node:crypto";
import { validateFieldJson } from "../core/field.js";

export const VERSION = "aether-resident-benchmark-0.1";
export const DIMENSIONS = Object.freeze(["differentiation", "dependence", "divergence", "compression", "integration", "calibration", "boundaries", "inhibition", "generalization"]);
export const json = validateFieldJson;
export const canonical = v => Array.isArray(v) ? `[${v.map(canonical).join(",")}]` : v && typeof v === "object" ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical(v[k])}`).join(",")}}` : JSON.stringify(v);
export const digest = v => createHash("sha256").update(canonical(v)).digest("hex");
export const same = (a, b) => canonical(a) === canonical(b);
export const bytes = v => Buffer.byteLength(typeof v === "string" ? v : JSON.stringify(v), "utf8");
export function check(ok, message) { if (!ok) throw new TypeError(`Benchmark: ${message}`); }
export function shape(v, keys) { check(v && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === keys.length && keys.every(k => Object.hasOwn(v, k)), `expected fields ${keys.join(", ")}`); }
export function text(v) { check(typeof v === "string" && v.trim().length > 0 && v.length <= 8192, "bounded text required"); }
export function ids(v, min = 0) { check(Array.isArray(v) && v.length >= min && v.length <= 256, "bounded ID array required"); v.forEach(text); check(new Set(v).size === v.length, "duplicate IDs"); }
export function normalize(v) {
  if (Array.isArray(v)) return v.map(normalize).sort((a, b) => canonical(a).localeCompare(canonical(b), "en"));
  if (v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, normalize(x)]));
  return v;
}
export function random(seed) {
  text(String(seed)); let state = Number.parseInt(digest(String(seed)).slice(0, 8), 16);
  return () => { state = (Math.imul(state, 1664525) + 1013904223) >>> 0; return state / 4294967296; };
}
export function shuffle(items, rng) {
  const out = [...items]; for (let i = out.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [out[i], out[j]] = [out[j], out[i]]; } return out;
}
export function candidateIdentity(input) {
  const c = json(input); shape(c, ["id", "version", "model", "representation", "parameters", "quantization", "runtime", "weights"]);
  for (const k of ["id", "version", "representation", "runtime"]) text(c[k]);
  for (const k of ["model", "quantization", "weights"]) if (c[k] !== null) text(c[k]);
  check(c.parameters === null || Number.isSafeInteger(c.parameters) && c.parameters >= 0, "parameter count must be unknown or a nonnegative count");
  return c;
}
