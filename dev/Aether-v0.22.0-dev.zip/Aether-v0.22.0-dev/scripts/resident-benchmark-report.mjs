import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { validateReport } from '../src/benchmark/runner.js';
const [fullPath, focusedPath, soakPath, demoPath, outputPath] = process.argv.slice(2);
assert.ok(outputPath, 'Usage: full-log focused-log soak-log demo-json new-output-json');
const hash = text => createHash('sha256').update(text).digest('hex');
async function testLog(path) {
  const raw = await readFile(path, 'utf8'), result = {};
  for (const key of ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']) {
    const m = raw.match(new RegExp(`(?:ℹ|#) ${key} (\\d+)`)); assert.ok(m, `Missing ${key} in ${path}`); result[key] = Number(m[1]);
  }
  assert.ok(result.tests > 0); assert.equal(result.pass, result.tests);
  for (const key of ['fail', 'cancelled', 'skipped', 'todo']) assert.equal(result[key], 0);
  return { ...result, logSha256: hash(raw) };
}
const full = await testLog(fullPath), focused = await testLog(focusedPath);
const soakRaw = await readFile(soakPath, 'utf8');
const soak = soakRaw.split('\n').filter(x => x.startsWith('{')).map(x => JSON.parse(x)).find(x => x.result === 'passed');
assert.ok(soak); assert.equal(soak.cycles, 32); assert.equal(soak.passed, 32); assert.equal(soak.failed, 0); assert.equal(soak.skipped, 0);
const demoRaw = await readFile(demoPath, 'utf8'), demo = JSON.parse(demoRaw);
assert.equal(demo.reports.length, 10); assert.equal(demo.corpus.cases.length, 95);
const candidates = demo.reports.map(input => {
  const r = validateReport(input); assert.equal(r.results.length, 95);
  const statuses = r.results.reduce((s, row) => { s[row.status] = (s[row.status] ?? 0) + 1; return s; }, {});
  if (r.candidate.id === 'reference') { assert.equal(statuses.PASS, 90); assert.equal(statuses.PARTIAL, 5); }
  else assert.ok((statuses.FAIL ?? 0) + (statuses['CONTRACT VIOLATION'] ?? 0) > 0);
  return { identity: r.candidate, reportDigest: r.reportDigest, statuses, profile: r.profile, resources: r.resources };
});
await writeFile(outputPath, JSON.stringify({ release: '0.22.0-dev', full, focused, soak: { ...soak, logSha256: hash(soakRaw) }, demoSha256: hash(demoRaw), evaluations: 950, candidates,
  limitations: ['Scripted development evidence only; no model benchmark, training or selection.', 'Synthetic platform metadata tests do not prove execution on those platforms.', 'Five reference cases retain unassessed semantic assertions.'] }, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
