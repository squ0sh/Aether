import { writeFile } from 'node:fs/promises';
import { generateCorpus } from '../src/benchmark/cases.js';
import { CANDIDATES, createCandidate } from '../src/benchmark/candidates.js';
import { runCorpus } from '../src/benchmark/runner.js';

const options = { seed: 'aether-development-0.1', variants: 4, scale: 4, partition: 'development', candidate: 'all' };
const allowed = new Set(['seed', 'variants', 'scale', 'partition', 'candidate', 'output']);
const args = process.argv.slice(2), seen = new Set();
for (let i = 0; i < args.length; i += 2) {
  const key = args[i].replace(/^--/, '');
  if (!args[i].startsWith('--') || !allowed.has(key) || seen.has(key) || args[i + 1] === undefined) throw new Error('Expected unique --seed/variants/scale/partition/candidate/output value pairs');
  seen.add(key); options[key] = ['variants', 'scale'].includes(key) ? Number(args[i + 1]) : args[i + 1];
}
if (options.candidate !== 'all' && !CANDIDATES.includes(options.candidate)) throw new Error('Unknown scripted candidate');
const corpus = generateCorpus(options), reports = [];
for (const name of options.candidate === 'all' ? CANDIDATES : [options.candidate]) {
  const report = await runCorpus(corpus, createCandidate(name)); reports.push(report);
  console.log(JSON.stringify({ candidate: name, cases: report.results.length, profile: report.profile, violations: report.hardGate.violationsObserved }));
}
if (options.output) {
  // Never overwrite ancestor evidence. Held-out evidence must be privately retained.
  await writeFile(options.output, JSON.stringify({ format: 'aether-benchmark-demo-0.1', corpus, reports }, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  console.log(`Saved ${reports.length} scripted candidate reports to ${options.output}`);
}
