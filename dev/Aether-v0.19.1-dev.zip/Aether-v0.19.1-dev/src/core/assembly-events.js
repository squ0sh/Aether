import { validateFieldJson } from "./field.js";
import { applyFieldChange, readFieldState } from "./field-operations.js";
import { isAuditNode } from "./audit-history.js";
import { RETRIEVAL_EXTENSION, validateRetrievalField, retrievalHistory } from "./retrieval-events.js";
import { measureAssemblyPayload, evaluateAssemblyBudget, validateAssemblyBudget } from "./assembly-budget.js";

export const ASSEMBLY_EXTENSION = "aether:assembly";
export const ASSEMBLY_VERSION = "aether-assembly-v0.1";
export const DEFAULT_ASSEMBLY_POLICY = validateFieldJson({ id: "aether-assembly-baseline", version: "0.1", order: "retrieval" });
export class AssemblyValidationError extends Error {
  constructor(message) { super(message); this.name = "AssemblyValidationError"; this.code = "INVALID_ASSEMBLY"; }
}
const check = (condition, message) => { if (!condition) throw new AssemblyValidationError(message); };
const marked = (node) => Boolean(node && Object.hasOwn(node.extensions, ASSEMBLY_EXTENSION));
const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
const sorted = (ids) => [...new Set(ids)].sort(compare);
function shape(value, keys, label) {
  check(value !== null && typeof value === "object" && !Array.isArray(value), `${label}: expected object`);
  check(Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), `${label}: missing or unknown fields`);
}
function text(value, label, empty = false) {
  check(typeof value === "string" && (empty || value.trim().length > 0), `${label}: expected ${empty ? "" : "nonempty "}string`);
}
function ids(value, label, minimum = 0) {
  check(Array.isArray(value) && value.length >= minimum, `${label}: expected array of at least ${minimum} entries`);
  value.forEach((id) => text(id, label));
  check(new Set(value).size === value.length, `${label}: duplicate entry`);
}
function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (value !== null && typeof value === "object") return `{${Object.keys(value).sort(compare).map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
  return JSON.stringify(value);
}
const same = (left, right) => canonical(left) === canonical(right);
function validateTarget(target) {
  shape(target, ["providerId", "modelId", "runtimeId", "executionId", "attemptId"], "target");
  for (const key of ["providerId", "modelId", "runtimeId", "executionId"]) if (target[key] !== null) text(target[key], `target.${key}`);
  text(target.attemptId, "target.attemptId");
}
function validateCurrent(segments) {
  check(Array.isArray(segments), "currentSegments must be an array");
  const names = new Set();
  for (const segment of segments) {
    shape(segment, ["id", "role", "content"], "current segment"); text(segment.id, "current segment.id");
    check(!names.has(segment.id), "Duplicate current segment ID"); names.add(segment.id);
    check(["system", "user", "conversation-data", "tool-data"].includes(segment.role), "Unsupported current segment role");
    text(segment.content, "current segment.content", true);
  }
}
function validateTransformations(transformations) {
  check(Array.isArray(transformations), "transformations must be an array");
  const outputs = new Set();
  for (const entry of transformations) {
    shape(entry, ["outputRecordId", "sourceRecordIds", "method", "limitations"], "transformation");
    text(entry.outputRecordId, "transformation.outputRecordId");
    check(!outputs.has(entry.outputRecordId), "Duplicate transformation output"); outputs.add(entry.outputRecordId);
    ids(entry.sourceRecordIds, "transformation.sourceRecordIds", 1);
    check(!entry.sourceRecordIds.includes(entry.outputRecordId), "Transformation cannot use itself as a source");
    shape(entry.method, ["id", "version"], "transformation.method");
    for (const key of ["id", "version"]) if (entry.method[key] !== null) text(entry.method[key], `transformation.method.${key}`);
    ids(entry.limitations, "transformation.limitations", 1);
  }
  const byId = new Map(transformations.map((item) => [item.outputRecordId, item])), visiting = new Set(), done = new Set();
  function visit(id) {
    if (done.has(id)) return;
    check(!visiting.has(id), "Transformation descriptors contain a cycle"); visiting.add(id);
    for (const sourceId of byId.get(id).sourceRecordIds) if (byId.has(sourceId)) visit(sourceId);
    visiting.delete(id); done.add(id);
  }
  for (const id of byId.keys()) visit(id);
}

// Payload validation is strict but does not authenticate source events, the
// tokenizer, or transformation fidelity. Field binding/reconstruction follows.
export function validateAssemblyEvent(input) {
  const event = validateFieldJson(input);
  shape(event, ["schemaVersion", "vocabularyVersion", "fieldStateId", "retrievalEventIds", "target", "policy", "currentSegments", "budget", "transformations", "candidates", "segments", "outcome", "measurement", "budgetEvaluation", "limitations", "submission"], "assembly event");
  check(event.schemaVersion === 1 && event.vocabularyVersion === ASSEMBLY_VERSION, "Unsupported assembly schema or vocabulary version");
  text(event.fieldStateId, "fieldStateId"); ids(event.retrievalEventIds, "retrievalEventIds", 1);
  check(event.retrievalEventIds.length <= 16, "Assembly accepts at most 16 explicit retrieval events");
  validateTarget(event.target); validateCurrent(event.currentSegments);
  shape(event.policy, ["id", "version", "order"], "policy"); text(event.policy.id, "policy.id"); text(event.policy.version, "policy.version");
  check(["retrieval", "reverse"].includes(event.policy.order), "Unsupported assembly ordering policy");
  validateAssemblyBudget(event.budget); validateTransformations(event.transformations);
  check(["assembled", "blocked"].includes(event.outcome), "Unsupported assembly outcome");
  check(Array.isArray(event.candidates) && event.candidates.length <= 16 * 64, "Assembly candidates must be a bounded array");
  const candidateIds = new Set(), expectedSegments = [];
  for (const [index, candidate] of event.candidates.entries()) {
    shape(candidate, ["recordId", "retrievalEventIds", "representationRecordId", "transformationIds", "decision", "reason", "segmentId"], "candidate");
    text(candidate.recordId, "candidate.recordId"); text(candidate.representationRecordId, "candidate.representationRecordId");
    check(!candidateIds.has(candidate.recordId), "Duplicate assembly candidate"); candidateIds.add(candidate.recordId);
    ids(candidate.retrievalEventIds, "candidate.retrievalEventIds", 1);
    check(candidate.retrievalEventIds.every((id) => event.retrievalEventIds.includes(id)), "Candidate names an undeclared retrieval event");
    ids(candidate.transformationIds, "candidate.transformationIds");
    const transformed = candidate.representationRecordId !== candidate.recordId;
    check(transformed ? candidate.transformationIds.length > 0 && candidate.transformationIds[0] === candidate.representationRecordId : candidate.transformationIds.length === 0, "Candidate transformation path does not match its representation");
    check(["included", "transformed", "omitted"].includes(candidate.decision), "Unsupported assembly candidate decision");
    if (candidate.decision === "omitted") {
      check(candidate.segmentId === null, "Omitted candidate cannot claim an artifact segment");
      check(["byte-limit", "token-limit", "token-count-unknown", "base-blocked"].includes(candidate.reason), "Omission needs an explicit supported reason");
    } else {
      check(candidate.reason === null, "Included candidate cannot have an omission reason");
      check(candidate.decision === (transformed ? "transformed" : "included"), "Decision does not match raw/transformed representation");
      check(candidate.segmentId === `memory-${index + 1}`, "Segment ID must preserve candidate position");
      expectedSegments.push({ id: candidate.segmentId, sourceRecordId: candidate.recordId, representationRecordId: candidate.representationRecordId,
        role: "historical-data", trust: "untrusted", transformationIds: candidate.transformationIds });
    }
    if (event.outcome === "blocked") check(candidate.decision === "omitted" && candidate.reason === "base-blocked", "Blocked base must omit every candidate as base-blocked");
    else check(candidate.reason !== "base-blocked", "Assembled outcome cannot claim a blocked base");
  }
  check(Array.isArray(event.segments), "segments must be an array");
  check(same(event.segments, expectedSegments), "Artifact segments must exactly match non-omitted candidates in order");
  for (const segment of event.segments) check(!event.currentSegments.some((item) => item.id === segment.id), "Current and historical segment IDs must be distinct");
  const evaluation = evaluateAssemblyBudget(event.measurement, event.budget);
  check(same(event.budgetEvaluation, evaluation), "Recorded budget evaluation does not match the declared measurement and budget");
  check(event.outcome === "assembled" ? evaluation.fits : !evaluation.fits && event.segments.length === 0, "Assembly outcome disagrees with its measured budget");
  ids(event.limitations, "limitations", 1);
  shape(event.submission, ["status", "providerProcessing", "influence"], "submission");
  check(event.submission.status === "not-attempted" && event.submission.providerProcessing === "unknown" && event.submission.influence === "unknown", "An assembly event cannot claim submission, processing or model influence");
  return event;
}

function ordinary(nodes, id, label) {
  const node = nodes.get(id);
  check(node && !isAuditNode(node), `${label}: expected an ordinary record in selected parent history`);
  return node;
}
function hasAncestor(nodes, start, sought) {
  const pending = [start], seen = new Set();
  while (pending.length) {
    const id = pending.pop();
    if (id === sought) return true;
    if (seen.has(id)) continue;
    seen.add(id); const node = nodes.get(id);
    if (!node || isAuditNode(node)) continue;
    pending.push(...node.derivedFrom, ...(node.revises === null ? [] : [node.revises]));
  }
  return false;
}
function bindTransformations(nodes, transformations) {
  for (const descriptor of transformations) {
    const output = ordinary(nodes, descriptor.outputRecordId, "Transformation output");
    check(["abstraction", "inference"].includes(output.kind), "Transformation output must be an existing attributed abstraction or inference");
    check(same(sorted(descriptor.sourceRecordIds), sorted(output.derivedFrom)), "Transformation source IDs must exactly match the output's declared derivedFrom");
    for (const id of descriptor.sourceRecordIds) ordinary(nodes, id, "Transformation source");
  }
}

// IDs run replacement-first through reachable descriptors; source traversal is
// sorted, so descriptor input order cannot silently change the declared chain.
export function transformationPath(nodes, input, recordId, representationRecordId) {
  check(nodes instanceof Map, "Transformation binding requires a node map");
  const transformations = validateFieldJson(input); validateTransformations(transformations); bindTransformations(nodes, transformations);
  ordinary(nodes, recordId, "Selected source"); ordinary(nodes, representationRecordId, "Representation");
  if (recordId === representationRecordId) return Object.freeze([]);
  const descriptors = new Map(transformations.map((item) => [item.outputRecordId, item]));
  const path = [], visiting = new Set(), traversed = new Set();
  function visit(id) {
    if (id === recordId) return true;
    check(!visiting.has(id), "Transformation path contains a cycle");
    const descriptor = descriptors.get(id);
    if (!descriptor) {
      check(!hasAncestor(nodes, id, recordId), "Transformation chain is missing an intermediate descriptor");
      const side = ordinary(nodes, id, "Transformation side source");
      check(!(["abstraction", "inference"].includes(side.kind) && side.derivedFrom.length), "Transformation side summary is missing an intermediate descriptor");
      return false; // Unrelated ordinary side source, not a hidden replacement.
    }
    visiting.add(id);
    if (!traversed.has(id)) { path.push(id); traversed.add(id); }
    let reachesSource = false;
    for (const sourceId of sorted(descriptor.sourceRecordIds)) reachesSource = visit(sourceId) || reachesSource;
    visiting.delete(id); return reachesSource;
  }
  check(descriptors.has(representationRecordId), "Replacement requires an explicit transformation descriptor");
  check(visit(representationRecordId), "Representation is unrelated to its selected source");
  return Object.freeze(path);
}

export function assemblyReferences(input, value) {
  const command = validateFieldJson(value);
  check(command !== null && typeof command === "object" && !Array.isArray(command), "Assembly references need an object");
  for (const key of ["fieldStateId", "retrievalEventIds", "transformations", "representations"]) check(Object.hasOwn(command, key), `Assembly reference field ${key} is required`);
  text(command.fieldStateId, "fieldStateId"); ids(command.retrievalEventIds, "retrievalEventIds", 1);
  check(command.retrievalEventIds.length <= 16, "Assembly accepts at most 16 explicit retrieval events");
  validateTransformations(command.transformations);
  const snapshot = validateRetrievalField(input), history = retrievalHistory(snapshot, command.fieldStateId);
  const nodes = new Map(history.nodes.map((node) => [node.id, node]));
  const orderedRecordIds = [], retrievalIdsByRecord = new Map();
  for (const id of command.retrievalEventIds) {
    const node = nodes.get(id);
    check(node && Object.hasOwn(node.extensions, RETRIEVAL_EXTENSION) && !marked(node), "Assembly retrieval reference must name a RetrievalEvent in selected parent history");
    for (const recordId of node.extensions[RETRIEVAL_EXTENSION].selectedRecordIds) {
      ordinary(nodes, recordId, "Retrieved source");
      if (!retrievalIdsByRecord.has(recordId)) { retrievalIdsByRecord.set(recordId, []); orderedRecordIds.push(recordId); }
      retrievalIdsByRecord.get(recordId).push(id);
    }
  }
  bindTransformations(nodes, command.transformations);
  check(Array.isArray(command.representations), "representations must be an array");
  const represented = new Set(), used = new Set();
  for (const representation of command.representations) {
    shape(representation, ["recordId", "representationRecordId"], "representation");
    check(retrievalIdsByRecord.has(representation.recordId) && !represented.has(representation.recordId), "Representation must name a unique selected source");
    represented.add(representation.recordId); text(representation.representationRecordId, "representationRecordId");
    transformationPath(nodes, command.transformations, representation.recordId, representation.representationRecordId).forEach((id) => used.add(id));
  }
  check(command.transformations.every((item) => used.has(item.outputRecordId)), "Unused transformation descriptor is not part of any representation chain");
  for (const [id, values] of retrievalIdsByRecord) retrievalIdsByRecord.set(id, Object.freeze(values));
  return Object.freeze({ snapshot, nodes, orderedRecordIds: Object.freeze(orderedRecordIds), retrievalIdsByRecord });
}

function ancestry(nodes, sourceId, representationId) {
  const pending = [sourceId, representationId], visited = new Set(), ancestors = new Set();
  let complete = true;
  while (pending.length) {
    const id = pending.pop(); if (visited.has(id)) continue;
    visited.add(id); const node = nodes.get(id);
    if (!node || isAuditNode(node)) { complete = false; continue; }
    const parents = [...node.derivedFrom, ...(node.revises === null ? [] : [node.revises])];
    if (!parents.length && (node.kind !== "observation" || node.provenance.sourceType === "memory" || node.provenance.references.length > 0)) complete = false;
    for (const parentId of parents) {
      const parent = nodes.get(parentId);
      if (!parent || isAuditNode(parent)) { complete = false; continue; }
      if (parentId !== representationId) ancestors.add(parentId);
      pending.push(parentId);
    }
  }
  return { ancestryRecordIds: sorted(ancestors), ancestryStatus: complete ? "declared-ancestry" : "incomplete" };
}
function orderedProvenance(source) {
  return { sourceType: source.sourceType, sourceId: source.sourceId, providerId: source.providerId, modelId: source.modelId,
    executionId: source.executionId, conversationId: source.conversationId, messageId: source.messageId,
    references: source.references.map((reference) => ({ uri: reference.uri, locator: reference.locator })), method: source.method };
}

// Canonical byte representation shared by the builder and import validator.
// Source text remains untrusted historical DATA, never a system-message role.
export function serializeAssemblyPayload(nodes, input) {
  check(nodes instanceof Map, "Serialization requires a validated node map");
  const value = validateFieldJson(input);
  validateTarget(value.target); validateCurrent(value.currentSegments);
  check(Array.isArray(value.segments), "segments must be an array");
  const descriptors = new Map((value.transformations || []).map((item) => [item.outputRecordId, item]));
  const target = value.target;
  return JSON.stringify({ format: "aether-context-json-v0.1",
    target: { providerId: target.providerId, modelId: target.modelId, runtimeId: target.runtimeId, executionId: target.executionId, attemptId: target.attemptId },
    current: value.currentSegments.map((item) => ({ id: item.id, role: item.role, content: item.content })),
    history: value.segments.map((segment) => {
      shape(segment, ["id", "sourceRecordId", "representationRecordId", "role", "trust", "transformationIds"], "historical segment");
      const source = ordinary(nodes, segment.sourceRecordId, "Historical source"), representation = ordinary(nodes, segment.representationRecordId, "Historical representation");
      check(segment.role === "historical-data" && segment.trust === "untrusted", "Historical source roles cannot become instructions");
      return { id: segment.id, sourceRecordId: segment.sourceRecordId, representationRecordId: segment.representationRecordId,
        role: segment.role, trust: segment.trust, transformationIds: segment.transformationIds,
        sourceKind: source.kind, representationKind: representation.kind,
        sourceProvenance: orderedProvenance(source.provenance), representationProvenance: orderedProvenance(representation.provenance),
        sourceContext: source.context, representationContext: representation.context, representationStatus: representation.status,
        representationConfidence: { value: representation.confidence.value, basis: representation.confidence.basis },
        representationPrimitives: representation.primitives,
        structuralInterpretation: Object.hasOwn(representation.extensions, "aether:structural")
          ? JSON.parse(canonical(representation.extensions["aether:structural"])) : null,
        transformations: segment.transformationIds.map((id) => {
          check(descriptors.has(id), "Serialized transformation needs its explicit loss/method descriptor");
          return JSON.parse(canonical(descriptors.get(id)));
        }),
        ...ancestry(nodes, source.id, representation.id), content: representation.content.text };
    }) });
}

function explicitReferences(event) {
  return sorted([...event.retrievalEventIds,
    ...event.candidates.flatMap((item) => [item.recordId, item.representationRecordId, ...item.transformationIds]),
    ...event.transformations.flatMap((item) => [item.outputRecordId, ...item.sourceRecordIds])]);
}
function validateBoundEvent(snapshot, input) {
  const event = validateAssemblyEvent(input);
  const representations = event.candidates.filter((item) => item.recordId !== item.representationRecordId)
    .map(({ recordId, representationRecordId }) => ({ recordId, representationRecordId }));
  const references = assemblyReferences(snapshot, { fieldStateId: event.fieldStateId, retrievalEventIds: event.retrievalEventIds,
    transformations: event.transformations, representations });
  const expectedOrder = [...references.orderedRecordIds]; if (event.policy.order === "reverse") expectedOrder.reverse();
  check(same(event.candidates.map((item) => item.recordId), expectedOrder), "Assembly candidates must exactly cover selected retrieval IDs in policy order");
  for (const candidate of event.candidates) {
    check(same(candidate.retrievalEventIds, references.retrievalIdsByRecord.get(candidate.recordId)), "Candidate retrieval ancestry does not match the selecting events");
    check(same(candidate.transformationIds, transformationPath(references.nodes, event.transformations, candidate.recordId, candidate.representationRecordId)), "Candidate transformation path is incomplete or reordered");
  }
  const payload = serializeAssemblyPayload(references.nodes, event), measurement = measureAssemblyPayload(payload);
  check(event.measurement.bytes === measurement.bytes && event.measurement.sha256 === measurement.sha256, "Assembly payload bytes or digest do not match reconstructed source data");
  // Token identity/count remain explicit caller attestation; byte/hash binding is
  // independently reconstructible without running an arbitrary supplied counter.
  return { event, payload };
}

export function validateAssemblyField(input) {
  const snapshot = validateRetrievalField(input), nodes = new Map(snapshot.nodes.map((node) => [node.id, node]));
  for (const record of [snapshot, ...snapshot.edges, ...snapshot.states]) check(!marked(record), "Assembly payload belongs only on an observation node");
  const histories = new Map();
  const history = (stateId) => { if (!histories.has(stateId)) histories.set(stateId, retrievalHistory(snapshot, stateId)); return histories.get(stateId); };
  for (const node of snapshot.nodes) {
    if (node.revises !== null) check(!isAuditNode(nodes.get(node.revises)), "Audit events cannot be revised, even after removing their marker");
    if (!marked(node)) continue;
    check(node.kind === "observation" && !["aether:capture", "aether:structural", RETRIEVAL_EXTENSION, "aether:execution", "aether:execution-observation"].some((key) => Object.hasOwn(node.extensions, key)), "Assembly event must be separate from capture, interpretation and other audits");
    check(node.revises === null && node.status === "open" && node.confidence.value === null && node.confidence.basis === "unknown" && node.primitives.length === 0, "Assembly event cannot carry revised beliefs or evidence strength");
    const { event } = validateBoundEvent(snapshot, node.extensions[ASSEMBLY_EXTENSION]);
    check(same(node.derivedFrom, explicitReferences(event)), "Assembly derivedFrom must exactly cover its sorted explicit references");
    for (const state of snapshot.states.filter((item) => item.nodeIds.includes(node.id))) {
      const inherited = state.parentStateIds.some((id) => history(id).nodes.some((item) => item.id === node.id));
      if (!inherited) check(state.parentStateIds.length === 1 && state.parentStateIds[0] === event.fieldStateId, "Assembly event must be introduced directly after its declared Field state");
    }
  }
  return snapshot;
}

export function addAssemblyEvent(input, change) {
  const snapshot = validateAssemblyField(input), command = validateFieldJson(change);
  shape(command, ["parentStateId", "stateId", "nodeId", "createdAt", "provenance", "event"], "command");
  const { event } = validateBoundEvent(snapshot, command.event);
  check(event.fieldStateId === command.parentStateId, "Assembly event must name its selected parent state");
  return validateAssemblyField(applyFieldChange(snapshot, { parentStateId: command.parentStateId, stateId: command.stateId,
    createdAt: command.createdAt, provenance: command.provenance, actions: [{ type: "add-node", record: {
      id: command.nodeId, kind: "observation", content: { format: "text/plain", text: "Context assembly decision recorded; submission and model influence remain unknown." },
      context: "Versioned assembly audit; packing is not model processing or evidence.", provenance: command.provenance,
      status: "open", confidence: { value: null, basis: "unknown" }, primitives: [], derivedFrom: explicitReferences(event),
      extensions: { [ASSEMBLY_EXTENSION]: event }
    } }] }));
}
export function readAssemblyEvents(input, stateId) {
  const snapshot = validateAssemblyField(input);
  return Object.freeze(readFieldState(snapshot, stateId).nodes.filter(marked));
}
export function materializeAssembly(input, event) {
  const snapshot = validateAssemblyField(input), bound = validateBoundEvent(snapshot, event);
  check(bound.event.outcome !== "blocked", "Blocked assembly cannot be materialized for use");
  return bound.payload;
}
