# v0.19.2-dev — single-node stabilization checkpoint

Baseline: the reviewed v0.19.1-dev source archive. This release tests repeated
state changes, not whether model claims are true. It remains the controlled mock
Execution & Return library checkpoint, not live automatic memory integration.

## Scope and changes

- Preserve the v0.19.1 HTTP sequencing fix and exclusive-operation guard.
- Add a growing-Field deterministic mock soak with scheduled failures and subprocess
  interruptions, repeated recovery and final historical invariant checks.
- Add exact continuous/fresh-process durable-history comparisons, temporal-gap,
  warm-cache corruption, and concurrent-recovery/termination ownership checks.
- Read fixtures produced by archived v0.15–v0.18 code, without migration or rewriting.
- Reuse successful validation for exact internally validated, detached, deeply frozen
  snapshots using module-private WeakSets. Caller-frozen objects, equal IDs, valid
  hashes and a lower-layer validation do not grant upper-layer validation authority.
  Private WeakMap ancestry indexes avoid re-traversing the same immutable histories.
  Weak keys allow discarded snapshots and their indexes to be reclaimed.

The validation change follows a measured accumulating-history bottleneck. Every
new persisted/imported object still gets full checks; only repeating checks on the
same already validated immutable object is avoided. Failed validation is not cached.
No schema, persistent concept, record meaning or validity rule was relaxed.

No HTTP route, runtime adapter, operation guard, journal format, capture policy,
automatic retry, model download, tool execution, resident, networking or retention
policy was added. There is no new SubmissionEvent/RecoveryEvent ontology.

## Repeatable soak method

`npm run test:soak` creates one private temporary Field and keeps it growing through
32 cycles: two passes through a fixed 16-cycle schedule. It does not reset the Field
between scenarios. Each attempt constructs a new RetrievalEvent and AssemblyEvent,
prepares an ExecutionEvent, and retains observable outcomes/captures when available.

The schedule is success, partial output, inference failure, retry, transport failure,
fallback, cancellation, timeout, capacity rejection, malformed raw response,
durable-response-before-capture process exit, continuation, post-intent process exit,
retry of unknown outcome, failed output publication, success.

Long-lived runner/coordinator instances are interleaved with scheduled reopenings;
recovery runs in a separate process every fourth cycle and after simulated exits.
Each crash waits for the exact child exit. If its temporary orphan lock survives,
recovery must first refuse ownership, then the fixture supervisor releases only that
known dead child's locks. Production never steals an active or merely old lock.

Per-cycle assertions check append-only nodes/edges/states, valid ancestry, audit
exclusion from retrieval candidates, incomplete audit-derived model lineage, model
attribution, distinct partial/complete/unknown outcomes, retry/fallback/continuation
links, unique capture per attempt and exact repeated-recovery idempotency (including
store receipts). A final pass rechecks every earlier attempt after later successes.
Missing legitimate stages remain absent; recovery has no adapter callback to rerun.

Output checkpoints include cycle/mode, elapsed time, nodes/states, stored bytes,
store file count, active Node resource categories and process memory observations.
Expected history/receipt growth is not labeled a leak. Memory samples include GC
timing and live histories; they are observations, not a proof of leak freedom.

## Restart, ownership and compatibility

The restart-equivalence test clones the initial private fixture and runs the same
four deterministic success/partial/failure/retry cycles continuously and in fresh
processes. Caller-supplied IDs and logical times match, permitting exact durable
history and receipt comparison, not just final answer comparison. A separate
five-year-gap test retains unresolved intent without inventing events in the gap.

Existing HTTP tests cover JSON/stream success, failures, persistence uncertainty,
disconnects and automatic failover. New coordinator tests hold work active while
concurrent recovery must fail, then verify cleanup after cancellation, timeout,
capacity rejection and malformed responses. Existing execution tests cover separate
retry/recovery attempts and six actual write/dispatch/response process-exit points.
The HTTP OperationGate and execution coordinator are distinct existing mechanisms;
this release does not imply the mock harness is wired into production runtime leases.

Compatibility fixtures are synthetic data produced now by the actual archived code,
not user data saved on the historical release dates. `test/fixtures/historical/manifest.json`
records producer versions, Git commits and archive/fixture SHA-256 hashes. The generator
imports only those old modules and their old LocalFieldStore to produce original-format
envelopes. Current readers validate them, reconstruct assembly bytes, reopen again,
and retry the old save receipt without changing file bytes. Coverage: Field and
version-1 Capture (v0.15), Structural (v0.16), Retrieval (v0.17), Assembly (v0.18).
To reproduce generation, extract each manifest-named archive under
`HISTORICAL_ROOT/vNN/Aether-v0.NN.0-dev/`, retain its ZIP under `vNN/dev/`, and run
`node scripts/generate-compatibility-fixtures.mjs HISTORICAL_ROOT OUTPUT_DIRECTORY`.

## Verification results

Verified on Linux, Node.js v26.8.2. Machine-readable measurements are in
[STABILIZATION-v0.19.2-results.json](STABILIZATION-v0.19.2-results.json).

- `npm run check` and syntax checks for all new scripts/tests: passed.
- Complete `npm test -- --test-reporter=spec`: **398 passed, 0 failed, 0 skipped**,
  14.33 seconds in this run. This includes 18 new stabilization/compatibility tests;
  as before, Node's aggregate includes the existing fixture-module discovery entries.
- Separate accumulating-history soak: **32 cycles passed, 0 failed, 0 skipped**,
  **161.75 seconds**, including the final repeat-recovery audit. Four scheduled child
  exits occurred; all earlier failed/unknown histories survived later success.
- Unchanged HTTP ownership suite: **22 tests passed on each of ten consecutive
  reruns** (220 checks), including the partial-stream and delayed-cleanup regressions.
- Final history: **218 nodes and 218 states**, including the initial fixture's four
  nodes/states; one Field envelope, **1,819,626 bytes**. Every completed cycle passed
  the no-stale-lock/no-staging/no-unfinished-coordinator-work assertions.
- First cycle took 172 ms; final cycle 8,633 ms. Peak sampled parent RSS was
  320,028,672 bytes (~305 MiB), peak sampled heap use 153,464,504 bytes (~146 MiB).
  Sampled resource categories were only transient filesystem work and one/two
  standard-output pipes; no accumulation of timers or child-process resources was seen.
- An exploratory four-cycle pre-cache pilot took 132.08 seconds; the same pilot
  after successful-validation reuse took 2.85 seconds. These are local observations,
  not controlled benchmark guarantees. The subsequent ancestry index was included
  in the final 32-cycle run. A superseded intermediate 32-cycle pilot was stopped
  after 25 complete cycles and is **not** counted as a completed soak.

The growing-history costs are still material: this finite pass establishes the
stated invariants at the measured size, not constant memory/time or readiness for
thousands of production cycles. No test was removed, skipped or weakened for green
results. The production OperationGate and v0.19.1 HTTP test are unchanged.

## Limits and unresolved behavior

- Finite deterministic mocks are not thousands of real-model cycles, physical
  power-loss certification, hostile-filesystem certification or distributed continuity.
- Snapshot and receipt history legitimately grows; each write still rewrites it.
  Weak validation caches improve repeated checks, not the asymptotic storage design.
- Local timeout/cancellation is not proof an external runtime stopped. Trusted mock
  adapters cooperate; production wiring still needs its real cancellation contract.
- Crash recovery requiring reviewed orphan-lock release remains a documented manual/
  supervised boundary. No unattended production lock takeover is implemented.
- Existing closed histories stay closed; later knowledge is appended, never used to
  retroactively resolve an unknown earlier observation.
- Compatible representative fixtures do not prove compatibility with every possible
  old snapshot, future schema or unsupported opaque extension.

No v0.20 direction is selected here. Review this checkpoint with Cal and pause for
the agreed first-principles “What is Aether?” discussion before expanding architecture.
