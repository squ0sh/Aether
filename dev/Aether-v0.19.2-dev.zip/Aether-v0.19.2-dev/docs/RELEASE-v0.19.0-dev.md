# Aether v0.19.0-dev — Execution & Return v0.1

Built from the reviewed v0.18.0-dev archive. This release is the approved first
**controlled mock-runtime execution/recovery checkpoint**, not production live wiring.
The [contract](EXECUTION-v0.1.md) records the exact boundary and remaining limitations.

## Included

- One new persistent concept: immutable ExecutionEvents, with source AssemblyEvent,
  request bytes/hash, explicit template transformation, target, parameters/seed and
  retry/fallback/continuation ancestry.
- Append-only ordinary lifecycle observations with exact source attribution,
  partial/raw output, narrow terminal categories, unknown processing/influence, and
  explicit local/unknown ordering.
- Durable-before-advance checkpointing using existing private Field transactions.
  No private request/output text is added to the operational performance log.
- Idempotent capture recovery from already durable output, without calling the
  model again. Partial or unresolved histories remain partial or unresolved.
- Human/system cancellation, local timeout and output/observation admission bounds.
- Execution audit exclusion from evidence roles, strict imports/branch/provenance
  validation, and existing deletion/write ownership safeguards.
- All 55 handoff adversaries plus process-exit, acknowledgement-loss, privacy,
  schema, concurrency, capacity and whitespace-integrity tests.

Existing Field captures, RetrievalEvents and AssemblyEvents are not rewritten.
Execution-return captures use a version-2 capture marker for model-only returns and
possibly unknown occurrence time; the existing completed-chat-pair version-1 helper
and all live routes/adapters are unchanged. No data migration is performed.

## Honest review boundary

The controlled cycle works through immutable Field/assembly records and injected
test adapters. Production HTTP submission, real model cancellation, hard runtime
isolation and live automatic memory remain outside this checkpoint. No model or
runtime download, tool execution, resident or distributed networking was added.

Killed writers can leave locks. Inspection recovers the last published history;
writing recovery requires reviewed release of confirmed orphan ownership. The tests
supervise exact child exits before releasing only their temporary locks. The product
does not steal locks or claim unattended recovery of arbitrary production writers.

Snapshot-per-checkpoint writes prioritize correctness over long-stream performance.
Raw provider response is preserved only when the controlled adapter supplies it;
missing or never-durable information is not fabricated. A local cancellation/timeout
does not establish that a remote model stopped or produced nothing.

## Verification and packaging

Verified on Linux with Node.js v26.8.2:

- `npm run check`: passed.
- `npm test -- --test-reporter=spec`: 377 passed, 0 failed, 0 skipped.
- The full run includes 79 execution-specific tests: all 55 handoff scenarios,
  11 durability tests (including six actual child-process exit boundaries), and
  13 schema/validation tests. The runner total also includes fixture modules.
- Compared against the v0.18.0-dev source archive: live app, UI, runtime adapters,
  existing tests and private-storage implementations are unchanged.

Run `npm run check`, `npm run test:execution` and `npm test` from this source tree.
Tests use synthetic Fields, private temporary stores, controlled adapters and isolated
mock subprocesses. They do not establish live model behavior, scientific truth,
hidden cognition, physical power-loss tolerance or distributed continuity.

The ZIP is source-only: code, public assets, docs, tests and package metadata.
It excludes models, runtimes, private application data, node_modules, caches,
prior archives and Git history. The stable repository-root app is untouched.
