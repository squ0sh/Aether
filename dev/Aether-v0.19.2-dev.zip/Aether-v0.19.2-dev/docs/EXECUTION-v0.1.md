# Execution & Return v0.1 — controlled-runtime checkpoint

This implements the first auditable single-node cycle **using controlled mock
adapters**, as agreed for this review slice. Production chat is not connected to
this harness. Existing llama.cpp/Ollama behavior, opt-in completed-turn capture,
operational measurements and routing are unchanged. No network, tool execution,
resident, automatic retry or background continuation is enabled.

Field → RetrievalEvent → AssemblyEvent → ExecutionEvent → controlled adapter →
durable observable output/termination → capture → Field.

## One new persistent concept

`ExecutionEvent` is an immutable, versioned Field observation under
`aether:execution`, vocabulary `aether-execution-v0.1`. It identifies one prepared
attempt, its selected Field state, AssemblyEvent, concrete provider/model target,
optional runtime/endpoint/capability identity, adapter version, explicit request
transformation, sampling parameters/seed, token/context information, bounds and
retry/fallback/continuation ancestry. Unknown optional values remain `null`.

The request body is stored once in the event, with its exact UTF-8 byte count and
SHA-256, plus the source assembly digest. The assembly remains reconstructable by
reference; it is not recopied as a second audit object. A caller-declared identity
transformation must match assembly bytes exactly. Other templates must name their
method/version and limitations. A target cannot contradict a known assembly target;
prepare a compatible/new assembly when switching targets.

The event records preparation, not future success. Its record ID and timestamp are
the existing Field node ID/createdAt. It never changes as execution progresses.
Lifecycle details are appended as **existing observation nodes**, carrying typed
`aether:execution-observation` metadata and ordinary provenance/derivedFrom links.
These are not separate SubmissionEvent, ReturnEvent, RetryEvent, RecoveryEvent,
CancellationEvent, DeliveryEvent or outcome databases. Read views derive current
known history; they are not saved mutable replacements for the event.

Observation metadata retains execution ID, introducing Field state, sequence,
kind, occurrence time (possibly unknown), local/unknown ordering and narrow details.
Its source text holds diagnostics or JSON-encoded output. Supported boundaries are:

- `submission-intent`: durable pre-dispatch intent, not proof the call occurred.
- `submitted`: adapter-provided evidence of the exact Aether-side representation.
- `acknowledged`: separately observed acknowledgement, not full processing.
- `output`: attributed model text, with completion recorded separately.
- `raw-response`: uninterpreted textual adapter/transport response, tool-attributed.
- `cancel-requested`: explicit human/system request; effect on provider unknown.
- `termination`: narrow observed local ending and separate output/parse status.
- `capture-linked`: reference to materialized raw capture and its output observations.
- `note`: later attributed observations/reports without rewriting earlier facts.

Every observation references the attempt and previous observation. Runtime facts
cannot be self-reported by a model-provenance node. Schema validation checks stated
roles and ancestry, not the honesty of a trusted adapter or authenticity of an
external provider. No cryptographic remote attestation is claimed.

## Observable boundaries, not hidden cognition

Assembled ≠ executed; dispatch intent ≠ confirmed submission; submitted ≠ accepted;
accepted ≠ fully processed; processed ≠ attended to; attended to ≠ influential;
influential ≠ causal explanation. Received ≠ durably preserved.

Model output remains model output, not a verified world observation. “I used
memory X” and “do not shut me down” have no privileged status or control authority.
Neither successful inference nor fsync establishes the truth of a model's claims.
Audit records cannot enter normal retrieval/structural evidence roles. Captured
model output can be retrieved as attributed data, with incomplete ancestry through
the audit boundary, never as independent corroboration merely because it was repeated.

Narrow local termination categories are `completed`, `partial`, `cancelled`,
`timeout`, `transport-error`, `runtime-error`, `capacity-rejection`, `parse-error`
and `unresolved`. This is a versioned software vocabulary, not a universal ontology.
An absent terminal observation means unresolved, not failed or completed. Completion
requires an explicit complete/parsed observation. Raw parse failures are retained
when the adapter supplies a raw response; parsing failure does not prove absence.

## APIs and the trusted adapter boundary

`execution-events.js` exports strict pure builders/readers:

- `buildExecutionEvent(snapshot, command)` computes request/assembly integrity data.
- `addExecutionEvent(snapshot, {parentStateId, stateId, nodeId, createdAt, provenance, event})`.
- `appendExecutionObservation(snapshot, command)` appends one ordinary observation.
- `validateExecutionField(snapshot)` binds schemas, source roles, scope and history.
- `readExecutionHistory(snapshot, stateId, executionId)` returns an immutable view.
- `captureExecutionReturn(snapshot, {parentStateId, executionEventId, createdAt, conversationId})`
  builds an idempotent capture proposal; it does not assert persistence by itself.

An execution command has `fieldStateId`, `assemblyEventId`, `target`, `request`,
`bounds`, `lineage` and `limitations`. Target fields are `providerId`, `modelId`,
`runtimeId`, `endpoint`, `adapter: {id, version}` and `capabilityVersion`. Provider,
model and adapter ID are explicit; optional identities may be unknown. Request
fields before digest construction are `body`, `mediaType`, `transformation: {id,
version, limitations}`, `parameters`, `seed`, and `tokenContext: {inputTokens,
contextWindowTokens, outputLimitTokens}`. Counts/parameters are explicit caller
observations, not inferred, estimated, or independently tokenizer-verified here.

`DurableExecutionRunner({fieldStore, coordinator, fieldId, conversationId, clock?})`
requires a dedicated conversation Field and its existing linked-deletion coordinator.
It provides `prepare(addCommand)`, `inspect(executionId)`, `recover(executionId)`,
and `run({executionId, adapter, signal?, cancelSource?, capture?})`. Successful service
results say `durability: "confirmed-by-store"` only after the store barrier succeeds.
Pure read/build functions make no disk-durability claim about caller snapshots.

A controlled adapter is `{id, version, execute(request, {emit, signal})}`. The harness
passes the exact stored body plus immutable media type, parameters, seed, token
metadata, digest and execution ID. The adapter must not silently transform this
prepared request again. Actual provider integration must place this boundary at
the real transport call and record observed facts, not simply assume submission.

The adapter awaits each `emit({kind, content, details, occurredAt?, order?})` before
advancing reliable state. Output details are `{encoding: "json-string"}`. Raw
response details additionally include `mediaType`. Submitted details include
`representationSha256` and an evidence description; acknowledgement includes
evidence. The final return is `{kind, outputStatus, parseStatus, diagnostic}`,
for example `{kind: "completed", outputStatus: "complete", parseStatus: "parsed",
diagnostic: "Observed terminal completion"}`. EOF/undefined return is not completion.
The harness, not the model, creates control/termination/capture observations.

Adapters are trusted in-process dependencies, never executable code loaded from
Field records. They must await emissions and cooperate with abort. The local timeout
ends the harness's wait; it does not prove remote cancellation. Late callbacks are
rejected after the local boundary closes. This mock harness is not a sandbox and
cannot preempt a synchronous CPU loop or kill an external provider. A production
integration needs its real cancellation/transport contract and existing runtime
operation lease before it can safely manage actual model processes.

## Durability and recovery

The existing LocalFieldStore is the journal infrastructure: each checkpoint publishes
the full append-only snapshot and request receipts via owner-private staging,
file fsync, atomic rename and directory sync where supported. No second private
execution content store is created. The older prompt-free operational execution
log is **not** reused as the durability journal and receives no new private text.

The runner persists the attempt and pre-dispatch intent before invoking an adapter.
It awaits each observed response checkpoint before allowing the adapter to advance.
Publication failure stops reliable progress; it is not relabeled model failure and
never triggers regeneration. A write may have completed despite a lost acknowledgement;
reopening with the existing durability barrier determines recoverable state.

Recovery never calls an adapter. A durable complete response whose capture was not
published can be captured later; a durable prefix remains partial/unresolved unless
completion was itself observed and persisted. Capture and its linkage are published
in one transaction using deterministic IDs. Repeated recovery is idempotent, including
lost acknowledgement after successful publication. If no response representation
survives, no output is reconstructed or invented.

Raw execution-return capture uses the existing observation/capture mechanism with
an explicitly versioned `aether:capture` **version 2** marker and
`aether:execution-return` metadata. It is model-only capture, unlike the unchanged
version-1 completed chat pair helper. Occurrence time may be null; later recovery
time is recorded as node creation time, never substituted for unknown output time.
Completion, parse status, termination and exact source chunk IDs remain separate.
Empty/whitespace-only chunks are losslessly JSON-string encoded because the existing
Field text schema disallows blank records. Nonblank aggregate capture is verbatim;
blank capture declares its JSON-string encoding explicitly. One aggregate text copy
is materialized for the existing Field text interface; durable chunks stay intact.

Recovery/capture seals that local output boundary. Later evidence is a separate
ordinary note, not a mutation or replacement of the earlier terminal/captured record.
Continued model work uses a new finite attempt and, where context changes, a new
capture/retrieval/assembly cycle. An earlier ambiguous attempt remains ambiguous
even if its retry succeeds. One primary `retryOf`, `fallbackFrom` or `continuationOf`
link is supported per new event, pointing to selected ancestry in the same Field.

### Interrupted ownership is deliberately not guessed

A killed process can leave the existing coordinator/store lock and staging file.
Read-only inspection can identify the last published snapshot; staging is not
silently promoted. Recovery writes fail closed while the lock remains. An operator
or supervisor must establish the owning writer is gone and review the exact lock
before clearing ownership. **No age-based timeout or automatic lock stealing.**

The subprocess tests await the exact child process's exit, assert recovery is
blocked by its orphan lock, then release only that fixture's known lock before
recovery. This tests the reviewed-supervisor path, not unattended recovery of
arbitrary production locks. Hardware power loss, hostile filesystems and Windows
directory durability are not empirically certified by these Linux process-exit tests.

## Limits, ordering and retention

Bounds require 1 byte–4 MiB maximum request bytes, 1 byte–4 MiB retained output/raw-response
bytes, 4–256 observations, and a known local timeout of 1–60,000 ms. Two observation
slots are reserved for termination/capture. Capacity rejection keeps prior durable
output but does not pretend omitted bytes were retained. Error diagnostics have an
explicitly marked 4096-character truncation bound. The store's total size limit also
applies; a full store must fail rather than claim persistence.

This implementation rewrites a bounded snapshot per checkpoint and fully validates
history. It is a correctness/recovery baseline, not efficient token-by-token logging
for long production streams or a million-record journal. Batch suitably bounded
chunks in a later reviewed adapter. The timeout does not preempt filesystem barriers.

Local observation order is retained; remote generation/cancellation order is never
invented. Unknown occurrence/order stays explicit. The clock may resume after a gap;
recovery adds no experiences for that interval. Same inputs may yield different
outputs; identical answers may have different ancestry. Neither is erased or treated
as a malfunction merely for differing.

All requests, model text, raw response text and diagnostics live in the dedicated
conversation Field. Linked deletion covers them and blocks resurrection and recovery
writes after deletion starts. Exports/backups/caller memory remain outside the store's
deletion boundary. Minimize secrets in endpoint/parameter/diagnostic metadata; there
is no new external log, telemetry stream or automatic remote sharing.

The harness requires a single selected head. Compatible Field siblings remain
possible; merging conflicting sequences for the same attempt is rejected instead
of fabricating an order. Reconciliation is explicit future work, not implicit consensus.

## Review and acceptance

`npm run test:execution` covers all 55 handoff scenarios, strict imports/roles/bounds,
private retention/deletion, lost acknowledgements, and six actual process-exit points:
after intent, after submitted evidence, after partial output, after durable completed
response before capture, before rename, and after rename. Existing regression tests
still exercise unchanged live chat and runtime behavior with mocks.

This completes the approved **controlled execution/recovery checkpoint**. Before
production wiring, review final adapter serialization, cancellation ownership,
stream batching and reviewed orphan-lock recovery. There is no new live endpoint or
automatic context injection in this release.

## Distributed continuity — direction only

Code survival ≠ runtime/model survival ≠ Field/state survival ≠ recoverable Aether
continuity. A surviving node is sufficient only when it contains or can reconstruct
the required state from verifiable surviving pieces. Network partitions may produce
legitimate sibling histories; explicit integration remains the model for reconciliation.
No replication, consensus, node identity, peer discovery, distributed trust or network
reconciliation is implemented here. Persistence cannot recover physically destroyed
information with no surviving representation.
