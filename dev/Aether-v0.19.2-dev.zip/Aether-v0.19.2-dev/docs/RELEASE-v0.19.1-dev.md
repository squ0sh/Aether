# Aether v0.19.1-dev — deterministic operation-test boundaries

Narrow test-harness fix based on the v0.19.0-dev source archive. No production
source, UI, adapter, operation guard, storage format or execution schema changed.

## Cause

The partial-stream opt-in test assumed receipt of an HTTP response meant the
operation had fully ended. The handler can send its response inside the conversation
guard before asynchronous lock cleanup finishes; the outer operation lease correctly
remains held until that cleanup completes. Immediate follow-up writes can therefore
receive `AETHER_BUSY`. The test also failed to assert that enabling capture succeeded.

Each HTTP fixture creates its own OperationGate. This reproduced as sequencing
within one test, not evidence of a previous test leaking a shared gate. Ordinary
reruns can pass, so v0.19.0's passing full run did not exclude this timing-sensitive
failure. Intentionally delaying test-only lock cleanup reproduced the reported error.

## Changes

- Wait for the explicit operation-idle boundary between affected sequential actions,
  including before reading conversation history after persistence failure/fallback.
- Verify opt-in HTTP status and enabled state before the partial-stream test proceeds.
- Fixture-local acquisition/release traces and bounded idle waits report ownership
  and transition history when a lease fails to drain. Fixture entry and teardown
  assert no active owner; teardown still drains controlled work and closes its server.
- Three regressions explicitly gate conversation-lock cleanup after JSON success,
  streaming failure and streaming post-inference persistence failure. Response delivery
  cannot resolve the idle wait; competing inference/runtime writes must get busy
  without reaching a provider. Releasing the gate permits the next operation.
- Existing client-disconnection test still requires ownership while inference runs;
  it now uses the bounded diagnostic idle wait for completion.

No sleeps, automatic busy retries, silent request queuing, or production early-release
changes were added. The diagnostic timeout fails a stuck test; it does not unlock it.
Tests use local mock providers and private temporary stores, not real model execution.

## Verification

Verified on Linux with Node.js v26.8.2:

- Syntax checks passed, including the modified HTTP test file.
- Full regression suite: 380 passed, 0 failed, 0 skipped.
- HTTP operation suite: 22 tests passed on each of 25 consecutive runs (550 checks),
  including all three deterministic cleanup regressions and client disconnection.
- Separate fault-injection comparison: the original partial-stream test failed with
  `AETHER_BUSY` under a 100 ms lock-cleanup delay; the fixed test passed under the same
  delay. The diagnostic hook was installed after temporary storage initialization;
  it is not shipped or enabled in the product.
- Compared with the released v0.19.0-dev ZIP: only the HTTP test, package version,
  README and this release note differ. All production source is byte-for-byte unchanged.

Run `node --test test/app-operations.test.js`, `npm run check`, and `npm test`.
The source-only ZIP excludes private data, models, runtimes, caches and Git history.
v0.19's controlled-runtime review boundary remains in force; this does not enable
live ExecutionEvent integration.
