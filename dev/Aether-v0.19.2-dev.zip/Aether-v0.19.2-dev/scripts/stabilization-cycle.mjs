// Synthetic verification only. No production route imports this module.
import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { LocalFieldStore } from "../src/core/field-store.js";
import { LinkedDeletionCoordinator } from "../src/core/linked-deletion.js";
import { DurableExecutionRunner } from "../src/core/execution-runner.js";
import { readExecutionHistory, validateExecutionField } from "../src/core/execution-events.js";
import { isAuditNode } from "../src/core/audit-history.js";
import { prepare, nextAssembly, loaded, adapter, complete, partial, emitText, intent } from "../test/fixtures/execution-cases.js";

export const schedule = ["success", "partial", "inference-failure", "retry", "transport-failure", "fallback",
  "cancelled", "timeout", "capacity", "malformed", "response-crash", "continuation", "intent-crash", "retry-unknown", "write-failure", "success"];
export const modeAt = (n) => schedule[(n - 1) % schedule.length];
export const digest = (value) => createHash("sha256").update(typeof value === "string" ? value : JSON.stringify(value)).digest("hex");
export function reopen(directory, conversationId, n = 1) {
  const store = new LocalFieldStore({ root: join(directory, "fields") });
  const coordinator = new LinkedDeletionCoordinator({ root: join(directory, "deletions"), conversationRoot: join(directory, "conversations"), fieldStore: store });
  // Fixed logical time makes observed event sequences directly comparable. A gap is
  // explicit at cycle 12; no event is generated for the intervening five years.
  const clock = () => new Date(Date.UTC(n >= 12 ? 2031 : 2026, 8, 18, 0, n)).toISOString();
  const runner = new DurableExecutionRunner({ fieldStore: store, coordinator, fieldId: "field", conversationId, clock });
  return { directory, conversationId, store, coordinator, runner };
}

export async function runCycle(f, n, { crash = false } = {}) {
  const mode = modeAt(n), id = `soak-${n}`;
  await nextAssembly(f, `soak-${n}`);
  const lineage = { retryOf: null, fallbackFrom: null, continuationOf: null };
  if (mode === "retry" || mode === "retry-unknown") lineage.retryOf = `soak-${n - 1}`;
  if (mode === "fallback") lineage.fallbackFrom = `soak-${n - 1}`;
  if (mode === "continuation") lineage.continuationOf = `soak-${n - 1}`;
  const overrides = { lineage, bounds: { maxRequestBytes: 65536, maxOutputBytes: mode === "capacity" ? 4 : 1024,
    maxObservations: 16, timeoutMs: mode === "timeout" ? 5 : 60000 } };
  if (mode === "fallback") overrides.target = { providerId: "mock", modelId: "model-b", runtimeId: null, endpoint: null,
    adapter: { id: "controlled-mock", version: "1" }, capabilityVersion: null };
  await prepare(f, id, overrides);
  let calls = 0;
  const controller = new AbortController();
  if (mode === "write-failure") {
    await intent(f, id);
    const save = f.store.save.bind(f.store);
    f.store.save = async () => { throw new Error("scheduled nondurable output"); };
    // Exercise the actual output publication path, preserving the durable intent.
    const { observe } = await import("../test/fixtures/execution-cases.js");
    try { await assert.rejects(observe(f, "output", { executionId: id, content: "must not survive",
      details: { encoding: "json-string" } }), /scheduled nondurable/); }
    finally { f.store.save = save; }
  } else {
    await f.runner.run({ executionId: id, signal: controller.signal, capture: mode !== "response-crash",
      adapter: adapter(async (_, { emit, signal }) => {
        calls++;
        if (mode === "intent-crash") {
          if (crash) process.exit(71);
          // Continuous comparison preserves the same pre-dispatch durable boundary.
          throw new Error("intent-crash must be driven by the crash worker");
        }
        if (mode === "inference-failure") throw new Error("scheduled inference failure");
        if (mode === "transport-failure") throw Object.assign(new Error("scheduled transport failure"), { termination: "transport-error" });
        if (mode === "cancelled") { controller.abort(); return await new Promise((resolve) => setImmediate(() => resolve(complete()))); }
        if (mode === "timeout") {
          await new Promise((resolve) => signal.addEventListener("abort", resolve, { once: true }));
          // Resolve after the harness's timeout boundary. This trusted mock owns no
          // external runtime; this is not proof of real-model cancellation.
          await new Promise((resolve) => setImmediate(resolve));
          return complete();
        }
        if (mode === "malformed") {
          await emit({ kind: "raw-response", content: "{invalid", details: { encoding: "json-string", mediaType: "application/json" } });
          return undefined;
        }
        await emitText(emit, "blue");
        if (mode === "capacity") await emitText(emit, "overflow");
        return mode === "partial" ? partial() : complete();
      }) });
    if (mode === "response-crash" && crash) process.exit(71);
  }
  return { calls, mode };
}

export async function recoverAndCheck(f, n) {
  const id = `soak-${n}`, mode = modeAt(n);
  const before = await f.runner.inspect(id);
  await f.runner.recover(id);
  const once = await loaded(f);
  await f.runner.recover(id);
  const twice = await loaded(f);
  assert.deepEqual(twice, once, "repeated recovery must not write a new state or receipt");
  const h = readExecutionHistory(twice.snapshot, twice.headStateIds[0], id);
  const expected = { partial: "partial", "inference-failure": "runtime-error", "transport-failure": "transport-error",
    cancelled: "cancelled", timeout: "timeout", capacity: "capacity-rejection", malformed: "parse-error",
    "intent-crash": "unresolved", "write-failure": "unresolved" }[mode] || "completed";
  assert.equal(h.termination, expected);
  assert.equal(h.termination, before.history.termination, "recovery cannot invent a terminal event");
  assert.equal(h.providerProcessing, "unknown"); assert.equal(h.influence, "unknown");
  if (["intent-crash", "write-failure"].includes(mode)) { assert.equal(h.output, ""); assert.equal(h.captureNodeId, null); }
  if (["partial", "capacity"].includes(mode)) assert.equal(h.outputStatus, "partial");
  const records = twice.snapshot.nodes;
  const captures = records.filter((r) => r.extensions["aether:execution-return"]);
  assert.equal(new Set(captures.map((r) => r.provenance.executionId)).size, captures.length);
  const retrieval = records.find((r) => r.id === `retrieval-soak-${n}`).extensions["aether:retrieval"];
  const byId = new Map(records.map((r) => [r.id, r]));
  for (const candidate of retrieval.candidatePool) {
    assert.equal(isAuditNode(byId.get(candidate.recordId)), false);
    if (byId.get(candidate.recordId).extensions["aether:execution-return"]) assert.equal(candidate.lineage.status, "incomplete");
  }
  // All prior outcome/lineage assertions are checked again at the final checkpoint.
  const event = h.execution.extensions["aether:execution"];
  assert.equal(event.assemblyEventId, `assembly-soak-${n}`);
  const link = mode === "fallback" ? "fallbackFrom" : mode === "continuation" ? "continuationOf" : mode.startsWith("retry") ? "retryOf" : null;
  if (link) assert.equal(event.lineage[link], `soak-${n - 1}`);
  await assertClean(f);
  return twice;
}

export async function assertClean(f) {
  for (const root of [f.store.root, f.coordinator.root]) {
    const names = await fs.readdir(root);
    assert.deepEqual(names.filter((s) => s.endsWith(".lock") || s.includes("incoming")), [], "no stale ownership/staging after completion");
    if (root === f.coordinator.root) assert.deepEqual(names, [], "completed execution must not leave deletion/recovery work");
  }
}
export function assertExtension(before, after) {
  for (const group of ["nodes", "edges", "states"]) {
    const byId = new Map(after[group].map((r) => [r.id, digest(r)]));
    for (const record of before[group]) assert.equal(byId.get(record.id), digest(record), `immutable ${group}:${record.id}`);
  }
  validateExecutionField(after);
}
export async function metrics(f, snapshot) {
  const files = await fs.readdir(f.store.root);
  const bytes = (await Promise.all(files.map(async (name) => (await fs.stat(join(f.store.root, name))).size))).reduce((a, b) => a + b, 0);
  return { nodes: snapshot.nodes.length, states: snapshot.states.length, bytes, fieldFiles: files.length,
    resources: process.getActiveResourcesInfo().sort(), memory: process.memoryUsage() };
}
