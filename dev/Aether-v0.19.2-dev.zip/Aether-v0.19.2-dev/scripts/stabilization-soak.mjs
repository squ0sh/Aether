import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fixture, loaded } from "../test/fixtures/execution-cases.js";
import { reopen, runCycle, modeAt, assertExtension, metrics, recoverAndCheck, digest } from "./stabilization-cycle.mjs";

const cycles = Number(process.argv[2] || 32);
assert.ok(Number.isSafeInteger(cycles) && cycles >= 1 && cycles <= 256);
const exec = promisify(execFile), child = fileURLToPath(new URL("./stabilization-worker.mjs", import.meta.url));
const cleanup = [], f0 = await fixture({ after(fn) { cleanup.push(fn); } });
let previous = (await loaded(f0)).snapshot;
const results = [], started = performance.now();
let f = reopen(f0.directory, f0.conversationId);
try {
  for (let n = 1; n <= cycles; n++) {
    const begin = performance.now(), mode = modeAt(n);
    if (n % 8 === 1) f = reopen(f0.directory, f0.conversationId, n);
    f.runner.clock = reopen(f0.directory, f0.conversationId, n).runner.clock;
    let interrupted = false;
    try {
      if (["intent-crash", "response-crash"].includes(mode)) await exec(process.execPath, [child, "cycle", f.directory, f.conversationId, String(n)], { timeout: 600000 });
      else await runCycle(f, n);
    }
    catch (error) { if (error.code !== 71 || !["intent-crash", "response-crash"].includes(mode)) throw error; interrupted = true; }
    assert.equal(interrupted, ["intent-crash", "response-crash"].includes(mode), "scheduled process exit must really occur");
    if (interrupted) {
      // The exact child has exited; never apply this fixture supervision to a live writer.
      const locks = [];
      for (const root of [f.store.root, f.coordinator.root]) for (const name of await fs.readdir(root)) if (name.endsWith(".lock")) locks.push(join(root, name));
      if (locks.length) await assert.rejects(f.runner.recover(`soak-${n}`), /owned|locked|interrupted/i);
      for (const lock of locks) await fs.unlink(lock);
    }
    // Mix long-lived in-process ownership with actual subprocess recovery.
    if (interrupted || n % 4 === 0) await exec(process.execPath, [child, "recover", f.directory, f.conversationId, String(n)], { timeout: 600000 });
    else await recoverAndCheck(f, n);
    const saved = await loaded(f);
    assertExtension(previous, saved.snapshot);
    previous = saved.snapshot;
    const row = { cycle: n, mode, interrupted, durationMs: Math.round(performance.now() - begin), ...await metrics(f, previous) };
    results.push(row); console.log(JSON.stringify({ checkpoint: row }));
  }
  // Earlier failed/ambiguous attempts must survive later retries and fallbacks intact.
  const beforeFinal = digest(await loaded(f0));
  for (let n = 1; n <= cycles; n++) await recoverAndCheck(reopen(f0.directory, f0.conversationId, n), n);
  assert.equal(digest(await loaded(f0)), beforeFinal);
  console.log(JSON.stringify({ result: "passed", cycles, passed: cycles, failed: 0, skipped: 0,
    elapsedMs: Math.round(performance.now() - started), historyDigest: digest(previous), results }));
} finally { for (const fn of cleanup) await fn(); }
