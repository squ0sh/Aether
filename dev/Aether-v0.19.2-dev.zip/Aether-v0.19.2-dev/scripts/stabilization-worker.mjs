import { reopen, runCycle, recoverAndCheck } from "./stabilization-cycle.mjs";
const [command, directory, conversationId, count] = process.argv.slice(2);
const n = Number(count), f = reopen(directory, conversationId, n);
if (command === "cycle") console.log(JSON.stringify(await runCycle(f, n, { crash: true })));
else if (command === "recover") { await recoverAndCheck(f, n); console.log(JSON.stringify({ recovered: n, modelCalls: 0 })); }
else throw new Error("Explicit cycle or recover command required");
