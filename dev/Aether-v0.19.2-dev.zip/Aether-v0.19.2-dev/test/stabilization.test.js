import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fixture, prepare, adapter, complete, emitText, loaded, clone, intent } from "./fixtures/execution-cases.js";
import { validateFieldSnapshot, validateFieldJson } from "../src/core/field.js";
import { validateStructuralField } from "../src/core/structural-field.js";
import { validateRetrievalField, retrievalHistory } from "../src/core/retrieval-events.js";
import { validateAssemblyField } from "../src/core/assembly-events.js";
import { validateExecutionField } from "../src/core/execution-events.js";
import { reopen, runCycle, recoverAndCheck, assertClean, assertExtension, digest } from "../scripts/stabilization-cycle.mjs";
const exec = promisify(execFile), worker = fileURLToPath(new URL("../scripts/stabilization-worker.mjs", import.meta.url));

for (const validate of [validateFieldSnapshot, validateStructuralField, validateRetrievalField, validateAssemblyField, validateExecutionField]) {
  test(`${validate.name} caches only its own immutable successful results`, async (t) => {
    const f = await fixture(t), input = clone(f.original), result = validate(input);
    assert.notEqual(input, result);
    assert.equal(validate(result), result);
    assert.throws(() => result.nodes[0].content.text = "changed", TypeError);
    assert.throws(() => result.states[0].nodeIds.push("forged"), TypeError);
    input.unrecognized = true;
    assert.throws(() => validate(input), "a previously submitted mutable input must be checked again");
    assert.throws(() => validate(Object.freeze(input)), "caller freezing does not confer validation");
    assert.throws(() => validate(validateFieldJson(input)), "generic JSON validation does not confer Field validation");
    const getter = clone(f.original); let called = false;
    Object.defineProperty(getter, "id", { enumerable: true, get() { called = true; return "field"; } });
    assert.throws(() => validate(getter)); assert.equal(called, false);
  });
}

test("validation caches do not let lower-layer validation bless forged upper-layer history", async (t) => {
  const f = await fixture(t); await prepare(f);
  const valid = validateExecutionField((await loaded(f)).snapshot);
  const variants = [
    [validateRetrievalField, (s) => { s.nodes.find((n) => n.id === "retrieval").extensions["aether:retrieval"].schemaVersion = 99; }],
    [validateAssemblyField, (s) => { s.nodes.find((n) => n.id === "assembly").extensions["aether:assembly"].measurement.sha256 = "0".repeat(64); }],
    [validateExecutionField, (s) => { s.nodes.find((n) => n.id === "e1").extensions["aether:execution"].request.body += "forged"; }]
  ];
  for (const [validate, mutate] of variants) {
    const forged = clone(valid); mutate(forged);
    assert.throws(() => validate(validateFieldSnapshot(forged)));
    assert.equal(validateExecutionField(valid), valid);
  }
  const h = retrievalHistory(valid, "captured");
  assert.deepEqual(h.nodes.map((n) => n.id), ["human", "model"]);
  assert.throws(() => h.nodes.push(valid.nodes.at(-1)), TypeError);
  assert.ok(retrievalHistory(valid, "e1:prepared").nodes.some((n) => n.id === "e1"));
  assert.equal(retrievalHistory(valid, "captured"), h);
});

test("continuous cycles and fresh-process cycles preserve identical durable history", { timeout: 120000 }, async (t) => {
  const base = await fixture(t), copy = await fs.mkdtemp(join(tmpdir(), "aether-restart-equivalence-"));
  t.after(() => fs.rm(copy, { recursive: true, force: true }));
  await fs.cp(base.directory, copy, { recursive: true });
  const continuous = reopen(base.directory, base.conversationId);
  for (let n = 1; n <= 4; n++) {
    continuous.runner.clock = reopen(base.directory, base.conversationId, n).runner.clock;
    const before = (await loaded(continuous)).snapshot;
    await runCycle(continuous, n); await recoverAndCheck(continuous, n);
    await exec(process.execPath, [worker, "cycle", copy, base.conversationId, String(n)], { timeout: 30000 });
    await exec(process.execPath, [worker, "recover", copy, base.conversationId, String(n)], { timeout: 30000 });
    const a = await loaded(continuous), b = await loaded(reopen(copy, base.conversationId, n));
    assert.deepEqual(a, b, `restart equivalence at cycle ${n}`);
    assertExtension(before, a.snapshot);
  }
});

test("a five-year reopen gap does not invent events or resolve unknown execution", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f);
  const before = await loaded(f);
  const later = reopen(f.directory, f.conversationId, 12);
  const result = await later.runner.recover("e1");
  assert.equal(result.history.termination, "unresolved");
  assert.equal(result.history.output, ""); assert.equal(result.history.captureNodeId, null);
  assert.deepEqual(await loaded(later), before);
  await assertClean(later);
});

test("recovery preserves closed history while corruption still fails after warming validation", async (t) => {
  const f = await fixture(t); await prepare(f);
  await f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { await emitText(emit, "blue"); return complete(); }) });
  const before = await loaded(f); validateExecutionField(before.snapshot);
  for (let n = 0; n < 5; n++) await f.runner.recover("e1");
  assert.equal(digest(await loaded(f)), digest(before));
  const [name] = await fs.readdir(f.store.root), path = join(f.store.root, name);
  const bytes = await fs.readFile(path), envelope = JSON.parse(bytes);
  envelope.payload.snapshot.nodes[0].content.text = "corrupted";
  await fs.writeFile(path, JSON.stringify(envelope), { mode: 0o600 });
  await assert.rejects(f.runner.inspect("e1"), { code: "FIELD_CORRUPT" });
  await fs.writeFile(path, bytes, { mode: 0o600 });
  assert.deepEqual(await loaded(f), before);
  await assertClean(f);
});

for (const mode of ["cancelled", "timeout", "capacity", "malformed"]) {
  test(`coordinator ownership drains after ${mode} without permitting concurrent recovery`, { timeout: 10000 }, async (t) => {
    const f = await fixture(t);
    await prepare(f, "e1", { bounds: { maxRequestBytes: 65536, maxOutputBytes: mode === "capacity" ? 1 : 100, maxObservations: 8, timeoutMs: mode === "timeout" ? 100 : 5000 } });
    let enter, release;
    const entered = new Promise((resolve) => { enter = resolve; }), held = new Promise((resolve) => { release = resolve; });
    const controller = new AbortController();
    const running = f.runner.run({ executionId: "e1", signal: controller.signal, adapter: adapter(async (_, { emit, signal }) => {
      enter(); await held;
      if (mode === "cancelled") controller.abort();
      if (mode === "timeout") {
        if (!signal.aborted) await new Promise((resolve) => signal.addEventListener("abort", resolve, { once: true }));
        await new Promise((resolve) => setImmediate(resolve));
      }
      if (mode === "capacity") await emitText(emit, "too much");
      return mode === "malformed" ? undefined : complete();
    }) });
    await entered;
    try { await assert.rejects(f.runner.recover("e1"), { code: "LINK_LOCKED" }); }
    finally { release(); }
    const result = await running;
    assert.equal(result.history.termination, { capacity: "capacity-rejection", malformed: "parse-error" }[mode] || mode);
    await assertClean(f);
    await f.runner.recover("e1"); await assertClean(f);
  });
}
