import test from "node:test";
import assert from "node:assert/strict";
import { fixture, prepare, adapter, complete, emitText, loaded, history, observe, intent, clone, at, author } from "./fixtures/execution-cases.js";
import { buildExecutionEvent, validateExecutionEvent, validateExecutionField, appendExecutionObservation, executionProvenance } from "../src/core/execution-events.js";
import { applyFieldChange } from "../src/core/field-operations.js";
import { validateFieldSnapshot } from "../src/core/field.js";
import { buildRetrievalDecision, DEFAULT_RETRIEVAL_POLICY } from "../src/core/retrieval.js";

test("execution event schema rejects forged requests, non-JSON getters and false unknown defaults", async (t) => {
  const f = await fixture(t), event = await prepare(f);
  for (const mutate of [
    (e) => e.schemaVersion = 2, (e) => e.vocabularyVersion = "future", (e) => e.extra = "authority",
    (e) => e.request.body += "changed", (e) => e.request.bytes++, (e) => e.request.sha256 = "0".repeat(64),
    (e) => e.request.seed = {}, (e) => e.request.parameters = [], (e) => e.request.tokenContext.inputTokens = -1,
    (e) => e.bounds.timeoutMs = null, (e) => e.bounds.maxOutputBytes = Infinity,
    (e) => e.lineage.retryOf = e.lineage.fallbackFrom = "parent", (e) => e.limitations = []
  ]) { const altered = clone(event); mutate(altered); assert.throws(() => validateExecutionEvent(altered)); }
  let calls = 0; const getter = clone(event); Object.defineProperty(getter.request, "body", { enumerable: true, get() { calls++; return "fake"; } });
  assert.throws(() => validateExecutionEvent(getter)); assert.equal(calls, 0);
  assert.throws(() => event.request.body = "rewrite", TypeError);
});
test("execution import rejects audit role mixing and marker-stripped revisions", async (t) => {
  const f = await fixture(t); await prepare(f); const valid = (await loaded(f)).snapshot;
  for (const mutate of [
    (s) => s.nodes.at(-1).kind = "hypothesis", (s) => s.nodes.at(-1).confidence = { value: 1, basis: "claimed certainty" },
    (s) => s.nodes.at(-1).extensions["aether:assembly"] = {}, (s) => s.nodes.at(-1).derivedFrom = [],
    (s) => s.extensions["aether:execution"] = {}, (s) => s.states[0].extensions["aether:execution-observation"] = {}
  ]) { const altered = clone(valid); mutate(altered); assert.throws(() => validateExecutionField(altered)); }
  const altered = clone(valid), old = altered.nodes.at(-1);
  altered.nodes.push({ ...clone(old), id: "forged-revision", revises: old.id, extensions: {} });
  altered.states.push({ ...clone(altered.states.at(-1)), id: "forged-state", parentStateIds: ["e1:prepared"], nodeIds: [...altered.states.at(-1).nodeIds, "forged-revision"] });
  assert.doesNotThrow(() => validateFieldSnapshot(altered)); assert.throws(() => validateExecutionField(altered), /cannot be revised/);
});
test("unsupported stored execution versions fail closed without changing storage", async (t) => {
  const f = await fixture(t), valid = await prepare(f), saved = await loaded(f), imported = clone(saved.snapshot);
  imported.nodes.at(-1).extensions["aether:execution"].vocabularyVersion = "future";
  assert.throws(() => validateExecutionField(imported), /Unsupported execution/);
  assert.deepEqual((await history(f)).execution.extensions["aether:execution"], valid);
});
test("execution cannot borrow unselected sibling attempts for retry ancestry", async (t) => {
  const f = await fixture(t), event = await prepare(f), saved = await loaded(f);
  const sibling = applyFieldChange(saved.snapshot, { parentStateId: "assembled", stateId: "sibling", createdAt: at, provenance: author, actions: [] });
  const request = { ...event.request }; delete request.sha256; delete request.bytes; delete request.assemblySha256;
  assert.throws(() => buildExecutionEvent(sibling, { fieldStateId: "sibling", assemblyEventId: "assembly", target: event.target, request, bounds: event.bounds,
    lineage: { retryOf: "e1", fallbackFrom: null, continuationOf: null }, limitations: [] }), /earlier attempt/);
});
test("wrong adapter identity or claimed submitted bytes never reach execution", async (t) => {
  const f = await fixture(t); await prepare(f); let calls = 0;
  await assert.rejects(f.runner.run({ executionId: "e1", adapter: { ...adapter(async () => { calls++; return complete(); }), version: "wrong" } }), /identity/);
  assert.equal(calls, 0); assert.equal((await history(f)).observations.length, 0);
  await intent(f);
  await assert.rejects(observe(f, "submitted", { details: { representationSha256: "0".repeat(64), evidence: "wrong bytes" } }), /differs/);
});
test("observation sequence, provenance and capture role are validated on imports", async (t) => {
  const f = await fixture(t); await prepare(f); await f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { await emitText(emit, "blue"); return complete(); }) });
  const original = (await loaded(f)).snapshot;
  for (const mutate of [
    (s) => s.nodes.find((n) => n.extensions["aether:execution-observation"]).extensions["aether:execution-observation"].sequence = 2,
    (s) => s.nodes.find((n) => n.extensions["aether:execution-observation"]?.kind === "output").provenance.modelId = "other-model",
    (s) => s.nodes.find((n) => n.extensions["aether:execution-return"]).extensions["aether:capture"].role = "human",
    (s) => s.nodes.find((n) => n.extensions["aether:execution-return"]).content.text = "changed return"
  ]) { const altered = clone(original); mutate(altered); assert.throws(() => validateExecutionField(altered)); }
  const capture = original.nodes.find((n) => n.extensions["aether:execution-return"]);
  const forged = clone(original); forged.nodes.push({ ...clone(capture), id: "rewritten-return", revises: capture.id, extensions: {} });
  forged.states.push({ ...clone(forged.states.at(-1)), id: "rewrite-state", parentStateIds: [forged.states.at(-1).id], nodeIds: [...forged.states.at(-1).nodeIds, "rewritten-return"] });
  assert.doesNotThrow(() => validateFieldSnapshot(forged)); assert.throws(() => validateExecutionField(forged), /return capture cannot be revised/);
});
test("bounded output admission retains prior prefix and records capacity rejection", async (t) => {
  const f = await fixture(t); await prepare(f, "e1", { bounds: { maxRequestBytes: 65536, maxOutputBytes: 4, maxObservations: 16, timeoutMs: 5000 } });
  const result = await f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { await emitText(emit, "blue"); await emitText(emit, "overflow"); return complete(); }) });
  assert.equal(result.history.output, "blue"); assert.equal(result.history.outputStatus, "partial"); assert.equal(result.history.termination, "capacity-rejection");
  assert.ok(result.history.captureNodeId);
});
test("bounded observation admission reserves termination and capture slots", async (t) => {
  const f = await fixture(t); await prepare(f, "e1", { bounds: { maxRequestBytes: 65536, maxOutputBytes: 100, maxObservations: 4, timeoutMs: 5000 } });
  const result = await f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { await emitText(emit, "one"); await emitText(emit, "two"); return complete(); }) });
  assert.equal(result.history.termination, "capacity-rejection"); assert.equal(result.history.output, "one"); assert.equal(result.history.observations.length, 4);
});
test("empty and whitespace-only output stays recoverable without changing the existing Field text schema", async (t) => {
  for (const output of ["", " \n\t"]) {
    const f = await fixture(t); await prepare(f); const result = await f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { await emitText(emit, output); return complete(); }) });
    assert.equal(result.history.output, output); const saved = await loaded(f), capture = saved.snapshot.nodes.find((n) => n.id === result.history.captureNodeId);
    assert.equal(capture.extensions["aether:execution-return"].encoding, "json-string"); assert.equal(JSON.parse(capture.content.text), output);
  }
});
test("concurrent recovery cannot take execution ownership and late emissions cannot change closed history", async (t) => {
  const f = await fixture(t); await prepare(f); let entered, release, late;
  const ready = new Promise((r) => { entered = r; }), gate = new Promise((r) => { release = r; });
  const pending = f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { late = emit; entered(); await gate; await emitText(emit, "owned output"); return complete(); }) });
  await ready;
  try { await assert.rejects(f.runner.recover("e1"), { code: "LINK_LOCKED" }); }
  finally { release(); }
  await pending; const before = await loaded(f);
  assert.throws(() => emitText(late, "late data"), { code: "EXECUTION_CLOSED" }); assert.deepEqual(await loaded(f), before);
});
test("system cancellation remains distinct from human cancellation and runtime failure", async (t) => {
  const f = await fixture(t); await prepare(f); const controller = new AbortController(); controller.abort();
  const result = await f.runner.run({ executionId: "e1", adapter: adapter(async () => complete()), signal: controller.signal, cancelSource: "system" });
  const cancel = result.history.observations.find((n) => n.extensions["aether:execution-observation"].kind === "cancel-requested");
  assert.equal(cancel.extensions["aether:execution-observation"].details.requestedBy, "system"); assert.equal(result.history.termination, "cancelled");
});
test("execution audits cannot enter direct retrieval attention or source ancestry roles", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f); const saved = await loaded(f);
  const base = { fieldStateId: saved.headStateIds[0], request: { query: "blue", context: "", activeQuestionIds: [] }, policy: DEFAULT_RETRIEVAL_POLICY, ancestry: { previousRetrievalEventIds: [], attentionSourceIds: ["e1"] } };
  assert.throws(() => buildRetrievalDecision(saved.snapshot, base), /non-event/);
  base.ancestry.attentionSourceIds = [saved.snapshot.nodes.at(-1).id]; assert.throws(() => buildRetrievalDecision(saved.snapshot, base), /non-event/);
});

test("adapter status cannot conceal an observed prefix or invent unobserved partial output", async (t) => {
  for (const hasOutput of [true, false]) {
    const f = await fixture(t); await prepare(f);
    const result = await f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => {
      if (hasOutput) await emitText(emit, "known prefix");
      return { kind: "runtime-error", outputStatus: hasOutput ? "unknown" : "partial", parseStatus: "unknown", diagnostic: "contradictory adapter status" };
    }) });
    assert.equal(result.history.termination, "parse-error"); assert.equal(result.history.outputStatus, hasOutput ? "partial" : "unknown");
  }
});
