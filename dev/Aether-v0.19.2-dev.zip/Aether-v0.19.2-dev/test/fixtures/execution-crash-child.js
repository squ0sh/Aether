// Invoked explicitly by execution-durability.test.js in a supervised subprocess.
// Test discovery merely imports this module and never exits its parent runner.
if (process.argv[2] === "--execution-crash-fixture") {
  const { join } = await import("node:path");
  const fs = await import("node:fs/promises");
  const { LocalFieldStore } = await import("../../src/core/field-store.js");
  const { LinkedDeletionCoordinator } = await import("../../src/core/linked-deletion.js");
  const { DurableExecutionRunner } = await import("../../src/core/execution-runner.js");
  const [directory, conversationId, phase] = process.argv.slice(3);
  let publication = 0;
  const io = { ...fs, async rename(...args) {
    publication++;
    if (publication === 2 && phase === "write-before-rename") process.exit(71);
    await fs.rename(...args);
    if (publication === 2 && phase === "write-after-rename") process.exit(71);
  } };
  const fieldStore = new LocalFieldStore({ root: join(directory, "fields"), fileSystem: io });
  const coordinator = new LinkedDeletionCoordinator({ root: join(directory, "deletions"), conversationRoot: join(directory, "conversations"), fieldStore });
  const runner = new DurableExecutionRunner({ fieldStore, coordinator, fieldId: "field", conversationId });
  await runner.run({ executionId: "e1", capture: false, adapter: { id: "controlled-mock", version: "1", async execute(request, { emit }) {
    if (phase === "after-intent") process.exit(71);
    if (phase === "after-submitted") {
      await emit({ kind: "submitted", content: "Mock confirmed submission.", details: { representationSha256: request.sha256, evidence: "Child observed request bytes at controlled boundary." } });
      process.exit(71);
    }
    await emit({ kind: "output", content: "surviving child output\n雪🙂", details: { encoding: "json-string" } });
    if (phase === "after-partial") process.exit(71);
    return { kind: "completed", outputStatus: "complete", parseStatus: "parsed", diagnostic: "Child observed complete result." };
  } } });
  process.exit(71); // Complete durable response, before the separate capture step.
}
