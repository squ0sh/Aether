import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fixture, prepare, adapter, complete, emitText, loaded, history, observe, intent } from "./fixtures/execution-cases.js";
import { LocalFieldStore } from "../src/core/field-store.js";
import { readExecutionHistory, validateExecutionField } from "../src/core/execution-events.js";
import { getConversation } from "../src/core/conversations.js";

const exec = promisify(execFile);
const child = fileURLToPath(new URL("./fixtures/execution-crash-child.js", import.meta.url));
for (const phase of ["after-intent", "after-submitted", "after-partial", "after-response", "write-before-rename", "write-after-rename"]) {
  test(`actual process exit at ${phase} retains last recoverable boundary without regeneration`, async (t) => {
    const f = await fixture(t); await prepare(f);
    await assert.rejects(exec(process.execPath, [child, "--execution-crash-fixture", f.directory, f.conversationId, phase], { timeout: 20000 }), (error) => error.code === 71);
    const reopened = new LocalFieldStore({ root: f.store.root }), saved = await reopened.load("field", { confirmDurability: true });
    const before = readExecutionHistory(saved.snapshot, saved.headStateIds[0], "e1");
    const hasOutput = ["after-partial", "after-response", "write-after-rename"].includes(phase);
    assert.equal(before.output, hasOutput ? "surviving child output\n雪🙂" : "");
    assert.equal(before.termination, phase === "after-response" ? "completed" : "unresolved");
    if (phase === "after-submitted") assert.equal(before.submission, "observed");
    // The supervisor has awaited this exact child's exit. Production must review
    // orphan ownership; neither runner nor FieldStore silently steals locks.
    const lockPaths = [];
    for (const dir of [f.coordinator.root, f.store.root]) for (const name of await fs.readdir(dir)) if (name.endsWith(".lock")) lockPaths.push(join(dir, name));
    if (lockPaths.length) await assert.rejects(f.runner.recover("e1"), /owned|locked|interrupted/i);
    for (const path of lockPaths) await fs.unlink(path);
    const recovered = await f.runner.recover("e1");
    assert.equal(recovered.history.output, before.output); assert.equal(recovered.history.termination, before.termination);
    if (hasOutput) assert.ok(recovered.history.captureNodeId);
    else assert.equal(recovered.history.captureNodeId, null);
    const once = await loaded(f); await f.runner.recover("e1"); assert.deepEqual(await loaded(f), once);
    if (phase !== "after-response") assert.notEqual(recovered.history.outputStatus, "complete");
  });
}

test("lost acknowledgement after durable output publication never reruns the model", async (t) => {
  const f = await fixture(t); await prepare(f); const save = f.store.save.bind(f.store); let calls = 0, failed = false;
  f.store.save = async (snapshot, options) => {
    const result = await save(snapshot, options);
    if (!failed && snapshot.nodes.at(-1).extensions["aether:execution-observation"]?.kind === "output") { failed = true; throw new Error("lost output publication acknowledgement"); }
    return result;
  };
  await assert.rejects(f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { calls++; await emitText(emit, "durable despite lost acknowledgement"); return complete(); }) }), /lost output/);
  f.store.save = save; const result = await f.runner.recover("e1");
  assert.equal(calls, 1); assert.equal(result.history.output, "durable despite lost acknowledgement"); assert.equal(result.history.outputStatus, "partial"); assert.equal(result.history.termination, "unresolved");
});
test("lost acknowledgement after atomic capture publication recovers exactly once", async (t) => {
  const f = await fixture(t); await prepare(f); const save = f.store.save.bind(f.store); let fail = true;
  f.store.save = async (snapshot, options) => { const result = await save(snapshot, options); if (fail && options.requestId === "execution-capture:e1") { fail = false; throw new Error("lost capture acknowledgement"); } return result; };
  await assert.rejects(f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { await emitText(emit, "capture survives"); return complete(); }) }), /lost capture/);
  f.store.save = save; const before = await loaded(f); await f.runner.recover("e1"); assert.deepEqual(await loaded(f), before);
  assert.equal(before.snapshot.nodes.filter((n) => n.extensions["aether:execution-return"]).length, 1);
});
test("unknown output occurrence time is not fabricated from later recovery time", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f);
  await observe(f, "output", { content: "time unknown", details: { encoding: "json-string" }, occurredAt: null, order: "unknown" });
  f.runner.clock = () => "2030-01-01T00:00:00.000Z";
  const result = await f.runner.recover("e1"), saved = await loaded(f), node = saved.snapshot.nodes.find((n) => n.id === result.history.captureNodeId);
  assert.equal(node.createdAt, "2030-01-01T00:00:00.000Z"); assert.equal(node.extensions["aether:capture"].occurredAt, null);
});
test("linked deletion covers requests, partial response, raw diagnostics and recovery writes", async (t) => {
  const f = await fixture(t); await prepare(f);
  await f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { await emitText(emit, "private output secret"); await emit({ kind: "raw-response", content: "private raw secret", details: { encoding: "json-string", mediaType: "text/plain" } }); throw new Error("private diagnostic secret"); }) });
  const snapshot = (await loaded(f)).snapshot, review = await f.coordinator.review(f.conversationId, "field");
  const command = { conversationId: f.conversationId, fieldId: "field", requestId: "delete-execution", expectedRevision: review.expectedRevision, conversationDigest: review.conversationDigest };
  await f.coordinator.deleteLinked(command, { permission: true });
  await assert.rejects(f.runner.recover("e1"), { code: "LINK_DELETING" });
  await assert.rejects(f.store.save(snapshot, { requestId: "resurrect" }), { code: "FIELD_DELETED" });
  await assert.rejects(getConversation(f.conversationId, f.conversationRoot), { statusCode: 404 });
  for (const dir of [f.store.root, f.coordinator.root]) for (const name of await fs.readdir(dir)) {
    const remaining = await fs.readFile(join(dir, name), "utf8");
    for (const secret of ["private output secret", "private raw secret", "private diagnostic secret", "mockTemplate"]) assert.equal(remaining.includes(secret), false);
  }
});
test("corrupt durable history fails closed without resetting it", async (t) => {
  const f = await fixture(t); await prepare(f); const name = (await fs.readdir(f.store.root)).find((name) => name.endsWith(".json"));
  const path = join(f.store.root, name); await fs.writeFile(path, "broken JSON", { mode: 0o600 });
  await assert.rejects(f.runner.recover("e1"), { code: "FIELD_CORRUPT" }); assert.equal(await fs.readFile(path, "utf8"), "broken JSON");
});
