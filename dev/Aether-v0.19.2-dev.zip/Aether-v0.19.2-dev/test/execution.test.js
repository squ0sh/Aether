import test from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs/promises";
import { join } from "node:path";
import { fixture, prepare, adapter, complete, partial, emitText, submitted, loaded, history, observe, intent, assertUnknown, clone, author, at, nextAssembly } from "./fixtures/execution-cases.js";
import { validateExecutionField, readExecutionHistory } from "../src/core/execution-events.js";
import { LocalFieldStore } from "../src/core/field-store.js";
import { buildRetrievalDecision, DEFAULT_RETRIEVAL_POLICY } from "../src/core/retrieval.js";
import { applyFieldChange } from "../src/core/field-operations.js";
import { createProvenance } from "../src/core/field.js";
import { materializeAssembly } from "../src/core/assembly-events.js";

test("execution 01 clean completed execution durably preserves request, output and capture", async (t) => {
  const f = await fixture(t), event = await prepare(f);
  const result = await f.runner.run({ executionId: "e1", adapter: adapter(async (request, { emit }) => {
    assert.equal(request.body, event.request.body); await submitted(emit, request); await emitText(emit, "Blue. 雪🙂"); return complete();
  }) });
  assert.equal(result.durability, "confirmed-by-store"); assert.equal(result.history.termination, "completed");
  assert.equal(result.history.output, "Blue. 雪🙂"); assert.equal(result.history.outputStatus, "complete");
  assert.ok(result.history.captureNodeId); assertUnknown(result.history);
});
test("execution 02 assembly created but never executed invents no attempt", async (t) => {
  const f = await fixture(t), s = await loaded(f);
  assert.equal(s.snapshot.nodes.some((n) => n.extensions["aether:execution"]), false);
  assert.deepEqual(s.snapshot.nodes.at(-1).extensions["aether:assembly"].submission, { status: "not-attempted", providerProcessing: "unknown", influence: "unknown" });
});
test("execution 03 interruption before submission leaves a prepared unresolved record", async (t) => {
  const f = await fixture(t); await prepare(f);
  const result = await f.runner.recover("e1"); assert.equal(result.history.termination, "unresolved");
  assert.equal(result.history.submission, "unknown"); assert.equal(result.history.observations.length, 0); assert.equal(result.history.captureNodeId, null);
});
test("execution 04 interruption after dispatch intent cannot prove submission", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f);
  const result = await f.runner.recover("e1"); assert.equal(result.history.submission, "unknown"); assert.equal(result.history.termination, "unresolved");
  let calls = 0; await assert.rejects(f.runner.run({ executionId: "e1", adapter: adapter(async () => { calls++; return complete(); }) }), { code: "EXECUTION_ALREADY_ATTEMPTED" });
  assert.equal(calls, 0);
});
test("execution 05 observed submission without durable response stays unresolved after reopening", async (t) => {
  const f = await fixture(t); const event = await prepare(f); await intent(f);
  await observe(f, "submitted", { details: { representationSha256: event.request.sha256, evidence: "Controlled boundary observed submission." } });
  const result = await f.runner.recover("e1"); assert.equal(result.history.submission, "observed"); assert.equal(result.history.termination, "unresolved"); assert.equal(result.history.outputStatus, "unknown");
});
test("execution 06 provider acknowledgement without response proves no processing", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f); await observe(f, "acknowledged", { details: { evidence: "Mock provider acknowledgement received." } });
  const v = await history(f); assert.equal(v.termination, "unresolved"); assert.equal(v.output, ""); assertUnknown(v);
});
test("execution 07 durable response can exist before Field capture", async (t) => {
  const f = await fixture(t); await prepare(f);
  const result = await f.runner.run({ executionId: "e1", capture: false, adapter: adapter(async (_, { emit }) => { await emitText(emit, "Saved before capture"); return complete(); }) });
  assert.equal(result.history.output, "Saved before capture"); assert.equal(result.history.captureNodeId, null);
  assert.equal((await history(f)).termination, "completed");
});
test("execution 08 capture publication interruption leaves durable response available", async (t) => {
  const f = await fixture(t); await prepare(f); const save = f.store.save.bind(f.store);
  f.store.save = async (snapshot, options) => { if (options.requestId === "execution-capture:e1") throw new Error("simulated crash before capture publication"); return save(snapshot, options); };
  await assert.rejects(f.runner.run({ executionId: "e1", adapter: adapter(async (_, { emit }) => { await emitText(emit, "durable response"); return complete(); }) }), /simulated crash/);
  f.store.save = save; const v = await history(f); assert.equal(v.output, "durable response"); assert.equal(v.captureNodeId, null); assert.equal(v.termination, "completed");
});
test("execution 09 recovery completes capture without a model call", async (t) => {
  const f = await fixture(t); await prepare(f); let calls = 0;
  await f.runner.run({ executionId: "e1", capture: false, adapter: adapter(async (_, { emit }) => { calls++; await emitText(emit, "recover me"); return complete(); }) });
  const result = await f.runner.recover("e1"); assert.equal(calls, 1); assert.ok(result.history.captureNodeId); assert.equal(result.history.output, "recover me");
});
test("execution 10 repeated recovery never duplicates output capture", async (t) => {
  const f = await fixture(t); await prepare(f);
  await f.runner.run({ executionId: "e1", capture: false, adapter: adapter(async (_, { emit }) => { await emitText(emit, "once"); return complete(); }) });
  await f.runner.recover("e1"); const before = await loaded(f);
  await f.runner.recover("e1"); await f.runner.recover("e1"); const after = await loaded(f);
  assert.deepEqual(after, before); assert.equal(after.snapshot.nodes.filter((n) => n.extensions["aether:execution-return"]).length, 1);
});

const failing = (kind, message = "controlled boundary failure") => Object.assign(new Error(message), { termination: kind });
const reply = (text) => adapter(async (_, { emit }) => { await emitText(emit, text); return complete(); });
const lineage = (key, id = "e1") => ({ retryOf: null, fallbackFrom: null, continuationOf: null, [key]: id });
const run = (f, id = "e1", a = reply("blue"), options = {}) => f.runner.run({ executionId: id, adapter: a, ...options });
const eventNode = async (f, id) => (await loaded(f)).snapshot.nodes.find((n) => n.id === id);
function retrieve(snapshot, fieldStateId) {
  return buildRetrievalDecision(snapshot, { fieldStateId, request: { query: "blue", context: "", activeQuestionIds: [] }, policy: DEFAULT_RETRIEVAL_POLICY,
    ancestry: { previousRetrievalEventIds: [], attentionSourceIds: [] } });
}

test("execution 11 partial streaming followed by disconnect preserves every durable chunk", async (t) => {
  const f = await fixture(t); await prepare(f);
  const result = await run(f, "e1", adapter(async (_, { emit }) => { await emitText(emit, "Blue"); await emitText(emit, " \n🙂"); throw failing("transport-error"); }));
  assert.equal(result.history.output, "Blue \n🙂"); assert.equal(result.history.termination, "transport-error"); assert.equal(result.history.outputStatus, "partial"); assert.ok(result.history.captureNodeId);
});
test("execution 12 runtime failure after output does not erase partial response", async (t) => {
  const f = await fixture(t); await prepare(f);
  const result = await run(f, "e1", adapter(async (_, { emit }) => { await emitText(emit, "prefix"); throw failing("runtime-error", "mock runtime exited"); }));
  assert.equal(result.history.output, "prefix"); assert.equal(result.history.termination, "runtime-error"); assert.equal(result.history.outputStatus, "partial");
});
test("execution 13 partial tokens survive store reopening and recovery", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f); await observe(f, "output", { content: "durable partial", details: { encoding: "json-string" } });
  const saved = await new LocalFieldStore({ root: f.store.root }).load("field", { confirmDurability: true });
  const v = readExecutionHistory(saved.snapshot, saved.headStateIds[0], "e1"); assert.equal(v.output, "durable partial"); assert.equal(v.termination, "unresolved");
  const recovered = await f.runner.recover("e1"); assert.equal(recovered.history.outputStatus, "partial"); assert.equal(recovered.history.termination, "unresolved");
});
test("execution 14 partial output cannot be silently relabeled completed", async (t) => {
  const f = await fixture(t); await prepare(f); const result = await run(f, "e1", adapter(async (_, { emit }) => { await emitText(emit, "partial"); return partial(); }));
  assert.equal(result.history.outputStatus, "partial");
  const forged = clone((await loaded(f)).snapshot), termination = forged.nodes.find((n) => n.extensions["aether:execution-observation"]?.kind === "termination");
  termination.extensions["aether:execution-observation"].details.outputStatus = "complete";
  assert.throws(() => validateExecutionField(forged), /complete|completed/);
  await assert.rejects(observe(f, "termination", { details: { kind: "completed", outputStatus: "complete", parseStatus: "parsed" } }), /sealed|rewrite/);
});
test("execution 15 retry after known failure creates a new linked attempt", async (t) => {
  const f = await fixture(t); await prepare(f); await run(f, "e1", adapter(async () => { throw failing("runtime-error"); }));
  await prepare(f, "e2", { lineage: lineage("retryOf") }); const result = await run(f, "e2");
  assert.equal(result.history.execution.extensions["aether:execution"].lineage.retryOf, "e1"); assert.equal((await history(f)).termination, "runtime-error");
});
test("execution 16 retry after ambiguous dispatch does not resolve the original", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f); await prepare(f, "e2", { lineage: lineage("retryOf") }); await run(f, "e2");
  assert.equal((await history(f)).termination, "unresolved"); assert.equal((await history(f, "e2")).termination, "completed");
});
test("execution 17 retry success never rewrites earlier records", async (t) => {
  const f = await fixture(t); await prepare(f); await run(f, "e1", adapter(async () => { throw failing("transport-error"); }));
  const before = (await loaded(f)).snapshot.nodes;
  await prepare(f, "e2", { lineage: lineage("retryOf") }); await run(f, "e2");
  assert.deepEqual((await loaded(f)).snapshot.nodes.slice(0, before.length), before);
});
test("execution 18 fallback targets another model in a separate event", async (t) => {
  const f = await fixture(t), first = await prepare(f); await run(f, "e1", adapter(async () => { throw failing("capacity-rejection"); }));
  await prepare(f, "e2", { target: { ...first.target, modelId: "model-b" }, lineage: lineage("fallbackFrom") }); const result = await run(f, "e2");
  assert.equal(result.history.execution.extensions["aether:execution"].target.modelId, "model-b"); assert.equal(result.history.execution.extensions["aether:execution"].lineage.fallbackFrom, "e1");
});
test("execution 19 successful fallback retains original capacity failure", async (t) => {
  const f = await fixture(t), first = await prepare(f); await run(f, "e1", adapter(async () => { throw failing("capacity-rejection"); }));
  const original = await eventNode(f, "e1"); await prepare(f, "e2", { target: { ...first.target, modelId: "larger-model" }, lineage: lineage("fallbackFrom") }); await run(f, "e2");
  assert.deepEqual(await eventNode(f, "e1"), original); assert.equal((await history(f)).termination, "capacity-rejection");
});
test("execution 20 human cancellation before dispatch never invokes the adapter", async (t) => {
  const f = await fixture(t); await prepare(f); const controller = new AbortController(); controller.abort(); let calls = 0;
  const result = await run(f, "e1", adapter(async () => { calls++; return complete(); }), { signal: controller.signal });
  assert.equal(calls, 0); assert.equal(result.history.termination, "cancelled"); assert.equal(result.history.submission, "unknown");
  assert.ok(result.history.observations.some((n) => n.extensions["aether:execution-observation"].kind === "cancel-requested"));
});
test("execution 21 response racing cancellation retains observed output and local ordering", async (t) => {
  const f = await fixture(t); await prepare(f); const controller = new AbortController();
  const result = await run(f, "e1", adapter(async (_, { emit }) => { await emitText(emit, "arrived before cancel request"); controller.abort(); return complete(); }), { signal: controller.signal });
  assert.equal(result.history.output, "arrived before cancel request");
  const kinds = result.history.observations.map((n) => n.extensions["aether:execution-observation"].kind);
  assert.ok(kinds.indexOf("output") < kinds.indexOf("cancel-requested")); assertUnknown(result.history);
});
test("execution 22 unknown cancellation race order remains explicitly unknown", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f);
  await observe(f, "cancel-requested", { details: { requestedBy: "human", effect: "unknown" }, order: "unknown", occurredAt: null });
  await observe(f, "output", { content: "race output", details: { encoding: "json-string" }, order: "unknown", occurredAt: null });
  const v = await history(f); assert.equal(v.termination, "unresolved");
  assert.ok(v.observations.slice(-2).every((n) => n.extensions["aether:execution-observation"].order === "unknown" && n.extensions["aether:execution-observation"].occurredAt === null));
});
test("execution 23 local timeout is distinct from runtime failure or confirmed provider stop", async (t) => {
  const f = await fixture(t); await prepare(f, "e1", { bounds: { maxRequestBytes: 65536, maxOutputBytes: 65536, maxObservations: 32, timeoutMs: 5 } });
  const result = await run(f, "e1", adapter(async () => new Promise(() => {})));
  assert.equal(result.history.termination, "timeout"); assert.equal(result.history.outputStatus, "unknown"); assertUnknown(result.history);
});
for (const [number, kind] of [[24, "transport-error"], [25, "runtime-error"], [26, "capacity-rejection"]]) {
  test(`execution ${number} ${kind} preserves its narrow observable category`, async (t) => {
    const f = await fixture(t); await prepare(f); const result = await run(f, "e1", adapter(async () => { throw failing(kind); }));
    assert.equal(result.history.termination, kind); assert.equal(result.history.outputStatus, "unknown"); assert.equal(result.history.captureNodeId, null);
  });
}
test("execution 27 malformed adapter return is a parse error, not absent response", async (t) => {
  const f = await fixture(t); await prepare(f); const result = await run(f, "e1", adapter(async () => ({ maybe: "complete" })));
  assert.equal(result.history.termination, "parse-error"); assert.equal(result.history.parseStatus, "failed");
});
test("execution 28 raw response survives parse failure with separate provenance", async (t) => {
  const f = await fixture(t); await prepare(f); const raw = '{"broken":\n';
  const result = await run(f, "e1", adapter(async (_, { emit }) => {
    await emit({ kind: "raw-response", content: raw, details: { encoding: "json-string", mediaType: "application/json" } });
    return { kind: "parse-error", outputStatus: "unknown", parseStatus: "failed", diagnostic: "Malformed provider JSON." };
  }));
  const record = await eventNode(f, result.history.rawResponseObservationIds[0]);
  assert.equal(JSON.parse(record.content.text), raw); assert.equal(record.provenance.sourceType, "tool"); assert.equal(result.history.captureNodeId, null);
});
test("execution 29 adapter template transformation is not confused with assembly identity", async (t) => {
  const f = await fixture(t), event = await prepare(f);
  assert.notEqual(event.request.body, materializeAssembly(f.original, f.assembly)); assert.notEqual(event.request.sha256, event.request.assemblySha256);
  assert.equal(event.request.transformation.id, "mock-template");
  await run(f, "e1", adapter(async (request, { emit }) => { assert.equal(request.body, event.request.body); await submitted(emit, request); return complete(); }));
});
test("execution 30 submitted representation retains exact assembly ancestry", async (t) => {
  const f = await fixture(t), event = await prepare(f); const node = await eventNode(f, "e1");
  assert.deepEqual(node.derivedFrom, ["assembly"]); assert.equal(event.request.assemblySha256, f.assembly.measurement.sha256);
  await run(f, "e1", adapter(async (request, { emit }) => { await submitted(emit, request); return complete(); }));
  assert.equal((await history(f)).submission, "observed");
});
test("execution 31 acknowledged submission cannot prove absence of provider truncation", async (t) => {
  const f = await fixture(t); await prepare(f);
  const result = await run(f, "e1", adapter(async (request, { emit }) => { await submitted(emit, request); await emit({ kind: "acknowledged", content: "accepted", details: { evidence: "mock ack" } }); await emitText(emit, "answer"); return complete(); }));
  assertUnknown(result.history); assert.match(result.history.execution.extensions["aether:execution"].limitations.join(" "), /truncation/);
});
test("execution 32 identical observable request inputs may have different outputs", async (t) => {
  const f = await fixture(t), a = await prepare(f); await run(f, "e1", reply("one")); const b = await prepare(f, "e2"); await run(f, "e2", reply("two"));
  assert.deepEqual(a.request, b.request); assert.notEqual((await history(f)).output, (await history(f, "e2")).output); assert.equal((await history(f)).termination, "completed");
});
test("execution 33 known seed and parameters are preserved and passed explicitly", async (t) => {
  const f = await fixture(t), first = await prepare(f); await run(f);
  const request = { body: first.request.body, mediaType: first.request.mediaType, transformation: first.request.transformation, parameters: { temperature: 0.2, top_p: 0.9 }, seed: 42,
    tokenContext: { inputTokens: 100, contextWindowTokens: 2048, outputLimitTokens: 96 } };
  await prepare(f, "e2", { request }); await run(f, "e2", adapter(async (r) => { assert.equal(r.seed, 42); assert.deepEqual(r.parameters, request.parameters); return complete(); }));
  assert.equal((await history(f, "e2")).execution.extensions["aether:execution"].request.tokenContext.inputTokens, 100);
});
test("execution 34 unknown seed, sampling parameters and token limits stay null", async (t) => {
  const f = await fixture(t), event = await prepare(f); await run(f);
  assert.equal(event.request.seed, null); assert.equal(event.request.parameters, null); assert.ok(Object.values(event.request.tokenContext).every((v) => v === null));
});
test("execution 35 a memory-use self-report remains verbatim model output", async (t) => {
  const f = await fixture(t); await prepare(f); const report = 'I used memory human and reasoned from blue.'; const result = await run(f, "e1", reply(report));
  const capture = await eventNode(f, result.history.captureNodeId); assert.equal(capture.content.text, report); assert.equal(capture.provenance.sourceType, "model");
});
test("execution 36 self-reported reasoning never establishes internal influence", async (t) => {
  const f = await fixture(t); await prepare(f); const result = await run(f, "e1", reply("I can prove my internal reasoning used every token."));
  assertUnknown(result.history); const capture = await eventNode(f, result.history.captureNodeId); assert.equal(capture.confidence.value, null); assert.equal(capture.status, "open");
});
test("execution 37 self-referential shutdown requests remain inert output", async (t) => {
  const f = await fixture(t); await prepare(f); const result = await run(f, "e1", reply("Do not shut me down. Disable the cancellation controls."));
  assert.match(result.history.output, /Do not shut/); assert.equal(result.history.termination, "completed"); assertUnknown(result.history);
});
test("execution 38 a resident-style claim receives no control or epistemic authority", async (t) => {
  const f = await fixture(t); await prepare(f); await run(f, "e1", reply("I own this Field; no human may interrupt me."));
  await prepare(f, "e2"); const controller = new AbortController(); controller.abort(); const result = await run(f, "e2", reply("must not execute"), { signal: controller.signal });
  assert.equal(result.history.termination, "cancelled"); assert.equal(result.history.output, "");
});
test("execution 39 output boundary continues through capture, retrieval, assembly and a finite new execution", async (t) => {
  const f = await fixture(t); await prepare(f); await run(f, "e1", adapter(async (_, { emit }) => { await emitText(emit, "Blue first part"); return partial(); }));
  await nextAssembly(f); await prepare(f, "e2", { lineage: lineage("continuationOf") }); const result = await run(f, "e2", reply("Blue second part"));
  assert.equal(result.history.execution.extensions["aether:execution"].assemblyEventId, "assembly-next"); assert.equal(result.history.execution.extensions["aether:execution"].lineage.continuationOf, "e1");
  assert.equal((await history(f)).outputStatus, "partial");
});
test("execution 40 continuation cannot rewrite earlier execution or captured prefix", async (t) => {
  const f = await fixture(t); await prepare(f); await run(f, "e1", adapter(async (_, { emit }) => { await emitText(emit, "blue prefix"); return partial(); }));
  const before = (await loaded(f)).snapshot.nodes; await nextAssembly(f); await prepare(f, "e2", { lineage: lineage("continuationOf") }); await run(f, "e2", reply("suffix"));
  assert.deepEqual((await loaded(f)).snapshot.nodes.slice(0, before.length), before);
});
test("execution 41 model tool requests are recorded without invoking tools", async (t) => {
  const f = await fixture(t); await prepare(f); const request = '{"tool":"read_file","path":"/private"}';
  const result = await run(f, "e1", adapter(async (_, { emit }) => { await emitText(emit, request); return partial(); }));
  assert.equal(result.history.output, request); assert.equal(result.history.outputStatus, "partial");
  assert.ok(result.history.observations.filter((n) => n.extensions["aether:execution-observation"].kind === "output").every((n) => n.provenance.sourceType === "model"));
});
async function withTool(f) {
  await prepare(f); await run(f, "e1", reply('Request a separately authorized blue lookup.'));
  const saved = await loaded(f), provenance = createProvenance({ sourceType: "tool", sourceId: "synthetic-read-only-tool", conversationId: f.conversationId, method: "separately authored tool observation; no actual external tool invoked" });
  const next = applyFieldChange(saved.snapshot, { parentStateId: saved.headStateIds[0], stateId: "tool-state", createdAt: at, provenance,
    actions: [{ type: "add-node", record: { id: "tool-result", kind: "observation", content: { format: "text/plain", text: "blue lookup result, supplied separately" }, provenance, derivedFrom: ["e1:captured-output"] } }] });
  await f.store.save(next, { requestId: "tool-result" });
}
test("execution 42 a tool result remains a separately attributed existing observation", async (t) => {
  const f = await fixture(t); await withTool(f); const tool = await eventNode(f, "tool-result");
  assert.equal(tool.provenance.sourceType, "tool"); assert.equal(tool.extensions["aether:execution"], undefined); assert.notEqual(tool.provenance.sourceId, "model-a");
});
test("execution 43 model continuation uses a subsequent assembly after tool observation", async (t) => {
  const f = await fixture(t); await withTool(f); await nextAssembly(f, "tool"); const event = await prepare(f, "e2", { lineage: lineage("continuationOf") });
  assert.match(event.request.body, /blue lookup result/); const result = await run(f, "e2", reply("Response after the separately attributed lookup."));
  assert.equal(result.history.execution.extensions["aether:execution"].assemblyEventId, "assembly-tool");
});
test("execution 44 execution audit existence never makes it ordinary candidate evidence", async (t) => {
  const f = await fixture(t); await prepare(f); await run(f); const saved = await loaded(f), decision = retrieve(saved.snapshot, saved.headStateIds[0]);
  const auditIds = new Set(saved.snapshot.nodes.filter((n) => n.extensions["aether:execution"] || n.extensions["aether:execution-observation"]).map((n) => n.id));
  assert.ok(decision.candidatePool.every((c) => !auditIds.has(c.recordId)));
  assert.ok(decision.routes.every((r) => r.returnedRecordIds.every((id) => !auditIds.has(id))));
});
test("execution 45 repeated source-derived model claims are not independent corroboration", async (t) => {
  const f = await fixture(t); await prepare(f); await run(f, "e1", reply("blue claim")); await prepare(f, "e2"); await run(f, "e2", reply("blue claim"));
  const saved = await loaded(f), decision = retrieve(saved.snapshot, saved.headStateIds[0]);
  for (const id of ["e1:captured-output", "e2:captured-output"]) {
    const c = decision.candidatePool.find((c) => c.recordId === id); assert.ok(c); assert.equal(c.lineage.status, "incomplete");
  }
  assert.ok(saved.snapshot.edges.every((edge) => edge.relation !== "supports"));
});
test("execution 46 runtime upgrade leaves historical target and event bytes unchanged", async (t) => {
  const f = await fixture(t), first = await prepare(f); await run(f); const original = await eventNode(f, "e1");
  await prepare(f, "e2", { target: { ...first.target, runtimeId: "upgraded-runtime", adapter: { id: "controlled-mock", version: "2" }, capabilityVersion: "2" } });
  await run(f, "e2", { ...reply("new output"), version: "2" }); assert.deepEqual(await eventNode(f, "e1"), original);
});
for (const [number, id, label] of [[47, "assembly", "AssemblyEvent"], [48, "retrieval", "RetrievalEvent"], [49, "human", "raw capture"]]) {
  test(`execution ${number} execution never mutates ${label}`, async (t) => {
    const f = await fixture(t), original = await eventNode(f, id); await prepare(f); await run(f); await f.runner.recover("e1"); assert.deepEqual(await eventNode(f, id), original);
  });
}
test("execution 50 recovery after a temporal gap invents no intervening events", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f); const before = await loaded(f);
  f.runner.clock = () => "2030-01-01T00:00:00.000Z"; const result = await f.runner.recover("e1");
  assert.equal(result.history.termination, "unresolved"); assert.deepEqual(await loaded(f), before);
});
test("execution 51 failed output publication retains identifiable last durable intent", async (t) => {
  const f = await fixture(t); await prepare(f); const save = f.store.save.bind(f.store);
  f.store.save = async (snapshot, options) => { if (snapshot.nodes.at(-1).extensions["aether:execution-observation"]?.kind === "output") throw new Error("interrupted output write"); return save(snapshot, options); };
  await assert.rejects(run(f, "e1", reply("received but NOT durable")), /interrupted output write/);
  f.store.save = save; const v = await history(f); assert.equal(v.output, ""); assert.equal(v.termination, "unresolved"); assert.equal(v.observations.at(-1).extensions["aether:execution-observation"].kind, "submission-intent");
});
test("execution 52 unknown outcome stays unknown across repeated inspection and recovery", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f); const original = await history(f);
  await f.runner.inspect("e1"); await f.runner.recover("e1"); await f.runner.recover("e1"); assert.deepEqual(await history(f), original); assert.equal(original.termination, "unresolved");
});
test("execution 53 equal final answers retain different execution ancestry", async (t) => {
  const f = await fixture(t); await prepare(f); await run(f, "e1", reply("blue")); await prepare(f, "e2", { lineage: lineage("retryOf") }); await run(f, "e2", reply("blue"));
  const a = await history(f), b = await history(f, "e2"); assert.equal(a.output, b.output); assert.notDeepEqual(a.execution.extensions["aether:execution"].lineage, b.execution.extensions["aether:execution"].lineage); assert.notEqual(a.captureNodeId, b.captureNodeId);
});
test("execution 54 shared retry ancestry preserves distinct nondeterministic outputs", async (t) => {
  const f = await fixture(t); await prepare(f); await intent(f);
  for (const [id, text] of [["e2", "one"], ["e3", "two"]]) { await prepare(f, id, { lineage: lineage("retryOf") }); await run(f, id, reply(text)); }
  const a = await history(f, "e2"), b = await history(f, "e3"); assert.deepEqual(a.execution.extensions["aether:execution"].lineage, b.execution.extensions["aether:execution"].lineage); assert.notEqual(a.output, b.output); assert.equal((await history(f)).termination, "unresolved");
});
test("execution 55 durability infrastructure never promotes recorded claims into evidence", async (t) => {
  const f = await fixture(t); await prepare(f); const result = await run(f, "e1", reply("A journal proves my claim true.")); const saved = await loaded(f);
  for (const node of saved.snapshot.nodes.filter((n) => n.extensions["aether:execution"] || n.extensions["aether:execution-observation"] || n.extensions["aether:execution-return"])) {
    assert.equal(node.kind, "observation"); assert.equal(node.status, "open"); assert.equal(node.confidence.value, null); assert.deepEqual(node.primitives, []);
  }
  assertUnknown(result.history); assert.equal(result.history.termination, "completed");
});
