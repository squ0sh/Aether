import { validateFieldJson, validateFieldSnapshot } from "./field.js";
import { isAuditNode } from "./audit-history.js";
import { applyFieldChange, readFieldState } from "./field-operations.js";
import { CONVERSATION_SCOPE, assertConversationField } from "./conversation-field.js";
import { STRUCTURAL_EXTENSION, structuralCheck, structuralShape, validateStructuralInterpretation } from "./structural-vocabulary.js";

const marked = (record) => Object.hasOwn(record.extensions, STRUCTURAL_EXTENSION);

// Generic Field extensions remain opaque. Structural consumers must enter here,
// including when reading a snapshot created by another tool or vocabulary version.
const validatedSnapshots = new WeakSet();
export function validateStructuralField(input) {
  if (validatedSnapshots.has(input)) return input;
  const snapshot = validateFieldSnapshot(input);
  if (Object.hasOwn(snapshot.extensions, CONVERSATION_SCOPE)) {
    assertConversationField(snapshot, snapshot.extensions[CONVERSATION_SCOPE]?.conversationId);
  }
  for (const record of [snapshot, ...snapshot.edges, ...snapshot.states]) {
    structuralCheck(!marked(record), record.id, "structural payloads belong only on abstraction nodes");
  }
  const nodes = new Map(snapshot.nodes.map((node) => [node.id, node]));
  for (const node of snapshot.nodes) {
    if (node.revises !== null) structuralCheck(!isAuditNode(nodes.get(node.revises)), `node:${node.id}`, "Audit events cannot be revised, even after removing their marker");
  }
  for (const node of snapshot.nodes.filter(marked)) {
    const path = `node:${node.id}`;
    const payload = validateStructuralInterpretation(node.extensions[STRUCTURAL_EXTENSION]);
    structuralCheck(node.kind === "abstraction" && !Object.hasOwn(node.extensions, "aether:capture") && !isAuditNode(node), path, "interpretation must be separate from raw observations and audit history");
    structuralCheck(node.status === "open" && node.confidence.value === null && node.confidence.basis === "unknown", path, "structural descriptions do not confer support or confidence");
    structuralCheck(node.primitives.length === 0, path, "candidate vocabulary belongs in the versioned extension, not core primitives");
    structuralCheck(JSON.stringify(node.derivedFrom) === JSON.stringify(payload.sourceNodeIds), path, "derivedFrom must exactly match structural sourceNodeIds");
    // The generic validator already requires derivedFrom/revises in the parent
    // history at introduction, including when nodes/states arrive out of order.
    for (const id of payload.sourceNodeIds) structuralCheck(nodes.get(id)?.kind === "observation" && !isAuditNode(nodes.get(id)), path, "structural sources must be observation nodes, not audit history");
    if (node.revises !== null) structuralCheck(marked(nodes.get(node.revises)), path, "revision target must be another structural interpretation");
  }
  validatedSnapshots.add(snapshot);
  return snapshot;
}

export function addStructuralInterpretation(input, change) {
  const snapshot = validateStructuralField(input);
  const command = validateFieldJson(change);
  const keys = ["parentStateId", "stateId", "nodeId", "createdAt", "provenance", "summary", "interpretation"];
  structuralShape(command, Object.hasOwn(command ?? {}, "revises") ? [...keys, "revises"] : keys, "command");
  const interpretation = validateStructuralInterpretation(command.interpretation);
  structuralCheck(typeof command.summary === "string" && command.summary.trim().length > 0, "command.summary", "nonempty attributed summary required");
  if (Object.hasOwn(command, "revises")) structuralCheck(typeof command.revises === "string" && command.revises.trim().length > 0, "command.revises", "revision needs a target ID; omit revises for a new interpretation");
  const revision = Object.hasOwn(command, "revises");
  if (revision) {
    const target = snapshot.nodes.find((node) => node.id === command.revises);
    structuralCheck(target && marked(target), "command.revises", "revision target must be another structural interpretation");
  }
  const record = {
    id: command.nodeId,
    kind: "abstraction",
    content: { format: "text/plain", text: command.summary },
    context: interpretation.context.scope,
    status: "open", confidence: { value: null, basis: "unknown" },
    provenance: command.provenance,
    derivedFrom: interpretation.sourceNodeIds,
    primitives: [],
    // Replace the payload explicitly on revision; never inherit stale source IDs.
    extensions: { [STRUCTURAL_EXTENSION]: interpretation }
  };
  return validateStructuralField(applyFieldChange(snapshot, {
    parentStateId: command.parentStateId, stateId: command.stateId,
    createdAt: command.createdAt, provenance: command.provenance,
    actions: [{ type: revision ? "revise-node" : "add-node", ...(revision ? { targetId: command.revises } : {}), record }]
  }));
}

// Membership only, not a resolved belief set: earlier and competing records stay
// visible. Reading does not select a winner or call a model.
export function readStructuralInterpretations(input, stateId) {
  const snapshot = validateStructuralField(input);
  return Object.freeze(readFieldState(snapshot, stateId).nodes.filter(marked));
}
