import { createHash } from "node:crypto";
import { validateFieldJson, createProvenance } from "./field.js";
import { applyFieldChange } from "./field-operations.js";
import { ASSEMBLY_EXTENSION, validateAssemblyField, materializeAssembly } from "./assembly-events.js";
import { isAuditNode } from "./audit-history.js";

export const EXECUTION_EXTENSION = "aether:execution";
// Typed metadata on EXISTING ordinary observation nodes, not separate event kinds.
export const EXECUTION_OBSERVATION = "aether:execution-observation";
export const EXECUTION_RETURN = "aether:execution-return";
export const EXECUTION_VERSION = "aether-execution-v0.1";
export const TERMINATIONS = Object.freeze(["completed", "partial", "cancelled", "timeout", "transport-error", "runtime-error", "capacity-rejection", "parse-error", "unresolved"]);
export const EXECUTION_LIMITS = Object.freeze([
  "Aether-side dispatch is not proof of provider acceptance or full processing.",
  "Provider preprocessing, truncation, internal processing, attention, influence and causal contribution are unknown unless separately observed.",
  "Model text and self-reports are attributed output, not world observations or privileged access to cognition.",
  "Record order is local durable observation order, not a total order of unobserved remote events.",
  "Recovery cannot reconstruct information with no surviving recoverable representation."
]);
export class ExecutionValidationError extends Error {
  constructor(message, code = "INVALID_EXECUTION") { super(message); this.name = "ExecutionValidationError"; this.code = code; }
}
export const executionCheck = (condition, message, code) => { if (!condition) throw new ExecutionValidationError(message, code); };
const check = executionCheck;
const marked = (node, key) => Boolean(node?.extensions && Object.hasOwn(node.extensions, key));
const sorted = (values) => [...new Set(values)].sort();
const json = (value) => value && typeof value === "object" ? Array.isArray(value) ? `[${value.map(json).join(",")}]`
  : `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${json(value[key])}`).join(",")}}` : JSON.stringify(value);
const same = (a, b) => json(a) === json(b);
const hash = (text) => createHash("sha256").update(text, "utf8").digest("hex");
function shape(value, keys, label) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), `${label}: missing or unknown fields`);
}
function text(value, label, empty = false) { check(typeof value === "string" && (empty || value.trim().length > 0), `${label}: expected string`); }
function integer(value, min, max, label) { check(Number.isSafeInteger(value) && value >= min && value <= max, `${label}: invalid bounded integer`); }
function ids(value, label, min = 0) {
  check(Array.isArray(value) && value.length >= min, `${label}: expected array`); value.forEach((id) => text(id, label));
  check(new Set(value).size === value.length, `${label}: duplicate entry`);
}
function time(value) { check(value === null || typeof value === "string" && Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value, "Observation time must be canonical ISO or unknown"); }
function target(value) {
  shape(value, ["providerId", "modelId", "runtimeId", "endpoint", "adapter", "capabilityVersion"], "target");
  text(value.providerId, "providerId"); text(value.modelId, "modelId");
  for (const key of ["runtimeId", "endpoint", "capabilityVersion"]) if (value[key] !== null) text(value[key], key);
  shape(value.adapter, ["id", "version"], "adapter"); text(value.adapter.id, "adapter.id");
  if (value.adapter.version !== null) text(value.adapter.version, "adapter.version");
}
function bounds(value) {
  shape(value, ["maxRequestBytes", "maxOutputBytes", "maxObservations", "timeoutMs"], "bounds");
  integer(value.maxRequestBytes, 1, 4 * 1024 * 1024, "maxRequestBytes");
  integer(value.maxOutputBytes, 1, 4 * 1024 * 1024, "maxOutputBytes");
  integer(value.maxObservations, 4, 256, "maxObservations");
  integer(value.timeoutMs, 1, 60000, "timeoutMs");
}
export function validateExecutionEvent(input) {
  const value = validateFieldJson(input);
  shape(value, ["schemaVersion", "vocabularyVersion", "fieldStateId", "assemblyEventId", "target", "request", "bounds", "lineage", "limitations"], "ExecutionEvent");
  check(value.schemaVersion === 1 && value.vocabularyVersion === EXECUTION_VERSION, "Unsupported execution schema or vocabulary");
  text(value.fieldStateId, "fieldStateId"); text(value.assemblyEventId, "assemblyEventId"); target(value.target); bounds(value.bounds);
  const r = value.request;
  shape(r, ["body", "mediaType", "sha256", "bytes", "assemblySha256", "transformation", "parameters", "seed", "tokenContext"], "request");
  text(r.body, "request.body", true); text(r.mediaType, "request.mediaType");
  check(r.sha256 === hash(r.body) && r.bytes === Buffer.byteLength(r.body), "Request hash/bytes mismatch");
  check(r.bytes <= value.bounds.maxRequestBytes, "Submitted representation exceeds request byte bound");
  check(typeof r.assemblySha256 === "string" && /^[a-f0-9]{64}$/.test(r.assemblySha256), "Invalid assembly digest");
  shape(r.transformation, ["id", "version", "limitations"], "transformation");
  text(r.transformation.id, "transformation.id"); text(r.transformation.version, "transformation.version"); ids(r.transformation.limitations, "transformation.limitations", 1);
  check(r.parameters === null || typeof r.parameters === "object" && !Array.isArray(r.parameters), "Known parameters must be an object; unknown must be null");
  check(r.seed === null || typeof r.seed === "string" && r.seed.length > 0 || Number.isSafeInteger(r.seed), "Seed must be explicit integer/string or unknown");
  shape(r.tokenContext, ["inputTokens", "contextWindowTokens", "outputLimitTokens"], "tokenContext");
  for (const key of Object.keys(r.tokenContext)) if (r.tokenContext[key] !== null) integer(r.tokenContext[key], 0, Number.MAX_SAFE_INTEGER, key);
  shape(value.lineage, ["retryOf", "fallbackFrom", "continuationOf"], "lineage");
  for (const key of Object.keys(value.lineage)) if (value.lineage[key] !== null) text(value.lineage[key], key);
  check(Object.values(value.lineage).filter((id) => id !== null).length <= 1, "One explicit retry, fallback or continuation parent per attempt");
  ids(value.limitations, "limitations", 1);
  for (const limit of EXECUTION_LIMITS) check(value.limitations.includes(limit), "Execution must retain epistemic limitations");
  return value;
}
// Private per-snapshot ancestry index. Callers pass only validated frozen snapshots;
// maps never escape this module, and weak keys do not retain discarded histories.
const historyIndexes = new WeakMap();
function history(snapshot, stateId) {
  let cached = historyIndexes.get(snapshot);
  if (!cached) { cached = new Map(); historyIndexes.set(snapshot, cached); }
  if (cached.has(stateId)) return cached.get(stateId);
  const states = new Map(snapshot.states.map((s) => [s.id, s])), seen = new Set(), nodeIds = new Set(), pending = [stateId];
  check(states.has(stateId), "Execution Field state is missing");
  while (pending.length) {
    const id = pending.pop(); if (seen.has(id)) continue; seen.add(id);
    const state = states.get(id); state.nodeIds.forEach((id) => nodeIds.add(id)); pending.push(...state.parentStateIds);
  }
  const result = new Map(snapshot.nodes.filter((n) => nodeIds.has(n.id)).map((n) => [n.id, n]));
  cached.set(stateId, result);
  return result;
}
const eventRefs = (event) => sorted([event.assemblyEventId, ...Object.values(event.lineage).filter((id) => id !== null)]);
function bindEvent(snapshot, event) {
  const nodes = history(snapshot, event.fieldStateId), assembly = nodes.get(event.assemblyEventId);
  check(marked(assembly, ASSEMBLY_EXTENSION), "Execution must reference an AssemblyEvent in selected parent history");
  const payload = materializeAssembly(snapshot, assembly.extensions[ASSEMBLY_EXTENSION]);
  check(event.request.assemblySha256 === hash(payload), "Execution assembly ancestry digest mismatch");
  if (event.request.transformation.id === "identity") check(event.request.body === payload, "Identity transformation must preserve exact assembly bytes");
  const assembledTarget = assembly.extensions[ASSEMBLY_EXTENSION].target;
  for (const key of ["providerId", "modelId", "runtimeId"]) check(assembledTarget[key] === null || assembledTarget[key] === event.target[key], "Changed target requires a compatible or new assembly");
  for (const id of Object.values(event.lineage).filter((id) => id !== null)) check(marked(nodes.get(id), EXECUTION_EXTENSION), "Execution lineage must reference an earlier attempt in selected history");
}
export function buildExecutionEvent(input, change) {
  const snapshot = validateExecutionField(input), command = validateFieldJson(change);
  shape(command, ["fieldStateId", "assemblyEventId", "target", "request", "bounds", "lineage", "limitations"], "execution command");
  shape(command.request, ["body", "mediaType", "transformation", "parameters", "seed", "tokenContext"], "request command");
  text(command.request.body, "request.body", true); ids(command.limitations, "limitations");
  const assembly = history(snapshot, command.fieldStateId).get(command.assemblyEventId);
  check(marked(assembly, ASSEMBLY_EXTENSION), "Execution requires a selected AssemblyEvent");
  const event = validateExecutionEvent({ ...command, schemaVersion: 1, vocabularyVersion: EXECUTION_VERSION,
    request: { ...command.request, sha256: hash(command.request.body), bytes: Buffer.byteLength(command.request.body),
      assemblySha256: hash(materializeAssembly(snapshot, assembly.extensions[ASSEMBLY_EXTENSION])) },
    limitations: sorted([...EXECUTION_LIMITS, ...command.limitations]) });
  bindEvent(snapshot, event); return event;
}

function observationPayload(input) {
  const o = validateFieldJson(input);
  shape(o, ["schemaVersion", "vocabularyVersion", "executionEventId", "fieldStateId", "sequence", "kind", "occurredAt", "order", "details"], "execution observation");
  check(o.schemaVersion === 1 && o.vocabularyVersion === EXECUTION_VERSION, "Unsupported execution observation version");
  text(o.executionEventId, "executionEventId"); text(o.fieldStateId, "fieldStateId"); integer(o.sequence, 1, 256, "sequence"); time(o.occurredAt);
  check(["local-observation", "unknown"].includes(o.order), "Observation order must be local or unknown");
  const d = o.details;
  switch (o.kind) {
    case "submission-intent": shape(d, ["representationSha256"], o.kind); break;
    case "submitted": shape(d, ["representationSha256", "evidence"], o.kind); text(d.evidence, "evidence"); break;
    case "acknowledged": shape(d, ["evidence"], o.kind); text(d.evidence, "evidence"); break;
    case "output": shape(d, ["encoding"], o.kind); check(d.encoding === "json-string", "Output encoding must preserve exact whitespace"); break;
    case "raw-response": shape(d, ["encoding", "mediaType"], o.kind); check(d.encoding === "json-string", "Raw encoding required"); text(d.mediaType, "mediaType"); break;
    case "cancel-requested": shape(d, ["requestedBy", "effect"], o.kind); check(["human", "system"].includes(d.requestedBy) && d.effect === "unknown", "Cancellation request does not establish provider stopped"); break;
    case "termination":
      shape(d, ["kind", "outputStatus", "parseStatus"], o.kind);
      check(TERMINATIONS.includes(d.kind), "Unsupported termination category");
      check(["complete", "partial", "unknown"].includes(d.outputStatus), "Output status must be explicit");
      check(["parsed", "failed", "unknown"].includes(d.parseStatus), "Parse status must be explicit");
      if (d.kind === "completed") check(d.outputStatus === "complete" && d.parseStatus === "parsed", "Completed requires explicitly complete parsed output");
      if (d.outputStatus === "complete") check(d.kind === "completed", "Only observed completion may claim complete output");
      if (d.kind === "partial") check(d.outputStatus === "partial", "Partial termination cannot claim complete output");
      if (d.kind === "parse-error") check(d.parseStatus === "failed", "Parse-error requires failed parse status");
      break;
    case "capture-linked": shape(d, ["captureNodeId", "outputObservationIds"], o.kind); text(d.captureNodeId, "captureNodeId"); ids(d.outputObservationIds, "outputObservationIds"); break;
    case "note": shape(d, ["basis", "limitations"], o.kind); check(["observed", "reported"].includes(d.basis), "Note basis required"); ids(d.limitations, "limitations", 1); break;
    default: check(false, "Unsupported execution observation kind");
  }
  return o;
}
const outputText = (node) => {
  let value; try { value = JSON.parse(node.content.text); } catch { check(false, "Invalid encoded output"); }
  text(value, "decoded output", true); return value;
};
function observations(nodes, executionId) {
  return [...nodes.values()].filter((n) => marked(n, EXECUTION_OBSERVATION) && n.extensions[EXECUTION_OBSERVATION].executionEventId === executionId)
    .sort((a, b) => a.extensions[EXECUTION_OBSERVATION].sequence - b.extensions[EXECUTION_OBSERVATION].sequence);
}
function observationRefs(o, earlier) {
  return sorted([o.executionEventId, ...(earlier.length ? [earlier.at(-1).id] : []),
    ...(o.kind === "capture-linked" ? [o.details.captureNodeId, ...o.details.outputObservationIds] : [])]);
}
function bindObservation(snapshot, node, o) {
  const nodes = history(snapshot, o.fieldStateId), execution = nodes.get(o.executionEventId);
  check(marked(execution, EXECUTION_EXTENSION), "Observation requires an ExecutionEvent in selected parent history");
  const event = execution.extensions[EXECUTION_EXTENSION], previous = observations(nodes, execution.id);
  check(o.sequence === previous.length + 1 && previous.every((n, i) => n.extensions[EXECUTION_OBSERVATION].sequence === i + 1), "Execution observation sequence is conflicting or incomplete");
  check(same(node.derivedFrom, observationRefs(o, previous)), "Observation must preserve exact execution and previous-observation ancestry");
  check(node.provenance.executionId === execution.id, "Observation execution provenance mismatch");
  check(node.provenance.providerId === event.target.providerId && node.provenance.modelId === event.target.modelId, "Observation target provenance mismatch");
  if (o.kind === "output") check(node.provenance.sourceType === "model", "Output must remain model-attributed");
  else check(node.provenance.sourceType !== "model", "Model output cannot assert execution lifecycle facts");
  const kinds = previous.map((n) => n.extensions[EXECUTION_OBSERVATION].kind);
  if (kinds.includes("capture-linked")) check(o.kind === "note", "Recovered/captured boundary is sealed; preserve later evidence as a separate note or new attempt");
  if (kinds.includes("termination")) check(["note", "capture-linked"].includes(o.kind), "Later evidence cannot rewrite terminal observations");
  if (o.kind === "submission-intent") check(!kinds.includes("submission-intent") && !kinds.includes("termination"), "An attempt cannot be dispatched twice");
  if (["submitted", "acknowledged", "output", "raw-response"].includes(o.kind)) check(kinds.includes("submission-intent"), "Runtime observations need explicit dispatch ancestry");
  if (o.kind === "submitted") check(!kinds.includes("submitted"), "Duplicate submitted boundary");
  if (o.kind === "termination") {
    if (kinds.includes("output") && o.details.kind !== "completed") check(o.details.outputStatus === "partial", "Observed output must remain partial without explicit completion");
    if (o.details.outputStatus === "partial") check(kinds.includes("output"), "Partial model output needs an observed model output record");
  }
  if (["submitted", "submission-intent"].includes(o.kind)) check(o.details.representationSha256 === event.request.sha256, "Submitted representation differs from prepared bytes");
  if (o.kind === "capture-linked") {
    check(!kinds.includes("capture-linked"), "Execution return already captured");
    const capture = nodes.get(o.details.captureNodeId);
    check(marked(capture, EXECUTION_RETURN) && capture.extensions[EXECUTION_RETURN].executionEventId === execution.id, "Capture link must reference this execution's return");
    check(same(o.details.outputObservationIds, previous.filter((n) => n.extensions[EXECUTION_OBSERVATION].kind === "output").map((n) => n.id)), "Capture must retain every observed output chunk");
  }
  integer(o.sequence, 1, event.bounds.maxObservations, "observation count");
  if (!["termination", "capture-linked"].includes(o.kind)) check(o.sequence <= event.bounds.maxObservations - 2, "Observation capacity reserves terminal and capture boundaries", "EXECUTION_CAPACITY");
  const outputNodes = [...previous, node].filter((n) => ["output", "raw-response"].includes(n.extensions[EXECUTION_OBSERVATION].kind));
  const bytes = outputNodes.reduce((sum, n) => sum + Buffer.byteLength(outputText(n)), 0);
  check(bytes <= event.bounds.maxOutputBytes, "Observed output exceeds durable output capacity", "EXECUTION_CAPACITY");
}
function introducedAfter(snapshot, node, parentId) {
  for (const state of snapshot.states.filter((s) => s.nodeIds.includes(node.id))) {
    if (!state.parentStateIds.some((id) => history(snapshot, id).has(node.id))) check(state.parentStateIds.length === 1 && state.parentStateIds[0] === parentId, "Execution record must be introduced directly after its declared state");
  }
}
function auditShape(node, own) {
  check(node.kind === "observation" && node.revises === null && node.status === "open" && node.confidence.value === null && node.confidence.basis === "unknown" && node.primitives.length === 0, "Execution audit cannot be revised belief or evidence strength");
  for (const key of [EXECUTION_EXTENSION, EXECUTION_OBSERVATION, EXECUTION_RETURN, "aether:capture", "aether:retrieval", ASSEMBLY_EXTENSION, "aether:structural"]) check(key === own || !marked(node, key), "Execution audit roles cannot be combined");
}
const validatedSnapshots = new WeakSet();
export function validateExecutionField(input) {
  if (validatedSnapshots.has(input)) return input;
  const snapshot = validateAssemblyField(input);
  const nodeMap = new Map(snapshot.nodes.map((node) => [node.id, node]));
  for (const record of [snapshot, ...snapshot.edges, ...snapshot.states]) for (const marker of [EXECUTION_EXTENSION, EXECUTION_OBSERVATION, EXECUTION_RETURN]) check(!marked(record, marker), "Execution metadata belongs on observation nodes only");
  for (const node of snapshot.nodes) {
    if (node.revises !== null) check(!marked(nodeMap.get(node.revises), EXECUTION_RETURN), "Execution return capture cannot be revised, even after removing its markers");
    if (marked(node, EXECUTION_EXTENSION)) {
      auditShape(node, EXECUTION_EXTENSION); const event = validateExecutionEvent(node.extensions[EXECUTION_EXTENSION]);
      bindEvent(snapshot, event); check(same(node.derivedFrom, eventRefs(event)), "Execution ancestry must exactly cover its references");
      check(event.assemblyEventId !== node.id && !Object.values(event.lineage).includes(node.id), "Execution cannot be its own ancestor");
      const assembled = history(snapshot, event.fieldStateId).get(event.assemblyEventId).extensions[ASSEMBLY_EXTENSION];
      check(assembled.target.executionId === null || assembled.target.executionId === node.id, "Assembly reserved another execution ID");
      introducedAfter(snapshot, node, event.fieldStateId);
    }
    if (marked(node, EXECUTION_OBSERVATION)) {
      auditShape(node, EXECUTION_OBSERVATION); const o = observationPayload(node.extensions[EXECUTION_OBSERVATION]);
      bindObservation(snapshot, node, o); introducedAfter(snapshot, node, o.fieldStateId);
    }
    if (marked(node, EXECUTION_RETURN)) validateReturn(snapshot, node);
  }
  // Merging incompatible sibling observation sequences is not implicit reconciliation.
  for (const state of snapshot.states.filter((s) => s.parentStateIds.length > 1)) {
    const nodes = history(snapshot, state.id), seen = new Set();
    for (const node of nodes.values()) if (marked(node, EXECUTION_OBSERVATION)) {
      const o = node.extensions[EXECUTION_OBSERVATION], key = JSON.stringify([o.executionEventId, o.sequence]);
      check(!seen.has(key), "Integrated execution histories conflict; explicit reconciliation required"); seen.add(key);
    }
  }
  validatedSnapshots.add(snapshot);
  return snapshot;
}
export function addExecutionEvent(input, change) {
  const snapshot = validateExecutionField(input), command = validateFieldJson(change);
  shape(command, ["parentStateId", "stateId", "nodeId", "createdAt", "provenance", "event"], "add execution");
  const event = validateExecutionEvent(command.event); check(event.fieldStateId === command.parentStateId, "Execution parent differs from recorded Field state");
  bindEvent(snapshot, event);
  return validateExecutionField(applyFieldChange(snapshot, { parentStateId: command.parentStateId, stateId: command.stateId, createdAt: command.createdAt, provenance: command.provenance,
    actions: [{ type: "add-node", record: { id: command.nodeId, kind: "observation", content: { format: "text/plain", text: "Execution prepared; no submission or outcome is inferred." },
      provenance: command.provenance, derivedFrom: eventRefs(event), extensions: { [EXECUTION_EXTENSION]: event } } }] }));
}
export function appendExecutionObservation(input, change) {
  const snapshot = validateExecutionField(input), command = validateFieldJson(change);
  shape(command, ["parentStateId", "stateId", "nodeId", "createdAt", "provenance", "executionEventId", "kind", "occurredAt", "order", "content", "details"], "append execution observation");
  text(command.content, "content", true);
  const previous = observations(history(snapshot, command.parentStateId), command.executionEventId);
  const o = observationPayload({ schemaVersion: 1, vocabularyVersion: EXECUTION_VERSION, executionEventId: command.executionEventId,
    fieldStateId: command.parentStateId, sequence: previous.length + 1, kind: command.kind, occurredAt: command.occurredAt, order: command.order, details: command.details });
  const content = ["output", "raw-response"].includes(o.kind) ? JSON.stringify(command.content) : command.content || `Observed boundary: ${o.kind}.`;
  return validateExecutionField(applyFieldChange(snapshot, { parentStateId: command.parentStateId, stateId: command.stateId, createdAt: command.createdAt, provenance: command.provenance,
    actions: [{ type: "add-node", record: { id: command.nodeId, kind: "observation", content: { format: "text/plain", text: content },
      provenance: command.provenance, derivedFrom: observationRefs(o, previous), extensions: { [EXECUTION_OBSERVATION]: o } } }] }));
}
function view(nodes, executionId) {
  const execution = nodes.get(executionId); check(marked(execution, EXECUTION_EXTENSION), "Execution not found in selected history");
  const all = observations(nodes, executionId), outputs = all.filter((n) => n.extensions[EXECUTION_OBSERVATION].kind === "output");
  const terminal = all.find((n) => n.extensions[EXECUTION_OBSERVATION].kind === "termination");
  const capture = all.find((n) => n.extensions[EXECUTION_OBSERVATION].kind === "capture-linked");
  return { execution, observations: all, output: outputs.map(outputText).join(""), outputObservationIds: outputs.map((n) => n.id),
    rawResponseObservationIds: all.filter((n) => n.extensions[EXECUTION_OBSERVATION].kind === "raw-response").map((n) => n.id),
    termination: terminal?.extensions[EXECUTION_OBSERVATION].details.kind ?? "unresolved",
    outputStatus: terminal?.extensions[EXECUTION_OBSERVATION].details.outputStatus ?? (outputs.length ? "partial" : "unknown"),
    parseStatus: terminal?.extensions[EXECUTION_OBSERVATION].details.parseStatus ?? "unknown",
    terminalObservationId: terminal?.id ?? null, captureNodeId: capture?.extensions[EXECUTION_OBSERVATION].details.captureNodeId ?? null,
    submission: all.some((n) => n.extensions[EXECUTION_OBSERVATION].kind === "submitted") ? "observed" : "unknown",
    providerProcessing: "unknown", influence: "unknown" };
}
export function readExecutionHistory(input, stateId, executionId) {
  return validateFieldJson(view(history(validateExecutionField(input), stateId), executionId));
}
export function executionProvenance(eventNode, conversationId, kind = "system") {
  const target = eventNode.extensions[EXECUTION_EXTENSION].target;
  return createProvenance({ sourceType: kind, sourceId: kind === "model" ? target.modelId : "aether:execution-recorder", providerId: target.providerId,
    modelId: target.modelId, executionId: eventNode.id, conversationId, method: kind === "model" ? "verbatim observed model output; not claim verification" : "explicit local execution boundary observation; hidden provider state unknown" });
}
function returnContent(v) { return v.output.trim() ? { text: v.output, encoding: "verbatim" } : { text: JSON.stringify(v.output), encoding: "json-string" }; }
function outputOccurrence(v) {
  const sourceId = v.outputObservationIds.at(-1) ?? v.terminalObservationId;
  return v.observations.find((n) => n.id === sourceId)?.extensions[EXECUTION_OBSERVATION].occurredAt ?? null;
}
function validateReturn(snapshot, node) {
  const r = node.extensions[EXECUTION_RETURN];
  shape(r, ["schemaVersion", "vocabularyVersion", "executionEventId", "fieldStateId", "outputObservationIds", "terminalObservationId", "outputStatus", "parseStatus", "termination", "encoding"], "execution return capture");
  check(r.schemaVersion === 1 && r.vocabularyVersion === EXECUTION_VERSION, "Unsupported execution return metadata");
  check(marked(node, "aether:capture") && !isAuditNode(node) && node.kind === "observation" && node.revises === null, "Return is immutable raw model capture, not an audit event");
  const v = view(history(snapshot, r.fieldStateId), r.executionEventId), content = returnContent(v);
  check(same(node.extensions["aether:capture"], { version: 2, role: "model", occurredAt: outputOccurrence(v) }), "Capture must preserve model role and observed/unknown occurrence time");
  check(v.outputObservationIds.length > 0 || v.outputStatus === "complete", "No observed model output available for capture");
  check(same(r.outputObservationIds, v.outputObservationIds) && r.terminalObservationId === v.terminalObservationId && r.outputStatus === v.outputStatus && r.parseStatus === v.parseStatus && r.termination === v.termination, "Capture status or output ancestry differs from durable observations");
  check(node.content.text === content.text && r.encoding === content.encoding, "Capture differs from durable model output");
  check(same(node.derivedFrom, sorted([r.executionEventId, ...v.outputObservationIds, ...(v.terminalObservationId ? [v.terminalObservationId] : [])])), "Return ancestry mismatch");
  check(node.provenance.sourceType === "model" && node.provenance.executionId === r.executionEventId && node.provenance.providerId === v.execution.extensions[EXECUTION_EXTENSION].target.providerId && node.provenance.modelId === v.execution.extensions[EXECUTION_EXTENSION].target.modelId, "Return provenance must preserve model identity");
  check(node.status === "open" && node.confidence.value === null && node.confidence.basis === "unknown" && node.primitives.length === 0, "Captured model claims cannot acquire evidence strength");
  introducedAfter(snapshot, node, r.fieldStateId);
}
// Pure idempotent capture proposal. The service only invokes this from a confirmed
// durable snapshot and publishes output plus linkage atomically in one store save.
export function captureExecutionReturn(input, { parentStateId, executionEventId, createdAt, conversationId }) {
  const snapshot = validateExecutionField(input), nodes = history(snapshot, parentStateId), v = view(nodes, executionEventId);
  if (v.captureNodeId) return snapshot;
  if (!v.outputObservationIds.length && v.outputStatus !== "complete") return snapshot;
  const id = `${executionEventId}:captured-output`, stateId = `${executionEventId}:captured-state`, content = returnContent(v);
  check(!snapshot.nodes.some((n) => n.id === id), "Capture ID already exists outside selected history");
  const occurredAt = outputOccurrence(v);
  const captured = applyFieldChange(snapshot, { parentStateId, stateId, createdAt, provenance: executionProvenance(v.execution, conversationId), actions: [{ type: "add-node", record: {
    id, kind: "observation", content: { format: "text/plain", text: content.text }, context: "Captured observable model output; completion status is separate, content is not verified world evidence.",
    provenance: executionProvenance(v.execution, conversationId, "model"), derivedFrom: sorted([executionEventId, ...v.outputObservationIds, ...(v.terminalObservationId ? [v.terminalObservationId] : [])]),
    extensions: { "aether:capture": { version: 2, role: "model", occurredAt }, [EXECUTION_RETURN]: { schemaVersion: 1, vocabularyVersion: EXECUTION_VERSION,
      executionEventId, fieldStateId: parentStateId, outputObservationIds: v.outputObservationIds, terminalObservationId: v.terminalObservationId,
      outputStatus: v.outputStatus, parseStatus: v.parseStatus, termination: v.termination, encoding: content.encoding } }
  } }] });
  return appendExecutionObservation(captured, { parentStateId: stateId, stateId: `${executionEventId}:capture-linked-state`, nodeId: `${executionEventId}:capture-linked`,
    createdAt, provenance: executionProvenance(v.execution, conversationId), executionEventId, kind: "capture-linked", occurredAt: createdAt, order: "local-observation",
    content: "Output capture linked to the preserved execution observations.", details: { captureNodeId: id, outputObservationIds: v.outputObservationIds } });
}
