import { validateFieldJson } from "./field.js";
import { isAuditNode } from "./audit-history.js";
import { applyFieldChange, readFieldState } from "./field-operations.js";
import { validateStructuralField } from "./structural-field.js";

export const RETRIEVAL_EXTENSION = "aether:retrieval";
export const MEMORY_VERSION = "aether-memory-v0.1";
export const RETRIEVAL_ROUTES = Object.freeze(["lexical", "structural", "ancestry", "contradiction", "question-linked", "exploratory"]);
export class RetrievalValidationError extends Error {
  constructor(message) { super(message); this.name = "RetrievalValidationError"; this.code = "INVALID_RETRIEVAL"; }
}
const check = (condition, message) => { if (!condition) throw new RetrievalValidationError(message); };
const marked = (node) => Boolean(node && Object.hasOwn(node.extensions, RETRIEVAL_EXTENSION));
function shape(value, keys, path) {
  check(value && typeof value === "object" && !Array.isArray(value), `${path}: expected object`);
  check(Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), `${path}: expected fields ${keys.join(", ")}`);
}
function text(value, path, empty = false) {
  check(typeof value === "string" && (empty || value.trim().length > 0), `${path}: expected ${empty ? "" : "nonempty "}string`);
}
function strings(value, path, minimum = 0) {
  check(Array.isArray(value) && value.length >= minimum, `${path}: expected array of at least ${minimum} entries`);
  value.forEach((id) => text(id, path));
  check(new Set(value).size === value.length, `${path}: duplicate entry`);
}
function integer(value, minimum, maximum, path) {
  check(Number.isSafeInteger(value) && value >= minimum && value <= maximum, `${path}: expected integer ${minimum}..${maximum}`);
}

export function validateRetrievalEvent(input) {
  const value = validateFieldJson(input);
  shape(value, ["schemaVersion", "vocabularyVersion", "fieldStateId", "request", "policy", "routes", "candidatePool", "selectedRecordIds", "workingContext", "ancestry", "limits"], "event");
  check(value.schemaVersion === 1 && value.vocabularyVersion === MEMORY_VERSION, "Unsupported memory schema or vocabulary version");
  text(value.fieldStateId, "fieldStateId");
  shape(value.request, ["query", "activeQuestionIds", "context"], "request");
  text(value.request.query, "request.query", true); text(value.request.context, "request.context", true);
  strings(value.request.activeQuestionIds, "activeQuestionIds");
  shape(value.policy, ["id", "version", "maxCandidates", "maxSelected", "perRouteLimit", "explorationSlots"], "policy");
  const p = value.policy;
  text(p.id, "policy.id"); text(p.version, "policy.version");
  integer(p.maxCandidates, 1, 256, "maxCandidates"); integer(p.maxSelected, 0, Math.min(64, p.maxCandidates), "maxSelected");
  integer(p.perRouteLimit, 1, 128, "perRouteLimit"); integer(p.explorationSlots, 0, Math.min(16, p.maxSelected), "explorationSlots");
  check(Array.isArray(value.routes) && value.routes.length > 0 && value.routes.length <= RETRIEVAL_ROUTES.length, "Explicit bounded discovery routes required");
  const routes = new Map();
  for (const route of value.routes) {
    shape(route, ["id", "status", "consideredCount", "matchedCount", "returnedRecordIds", "limit", "notes"], "route");
    check(RETRIEVAL_ROUTES.includes(route.id) && !routes.has(route.id), "Unknown or duplicate route"); routes.set(route.id, route);
    check(["complete", "bounded", "not-applicable"].includes(route.status), "Unknown route status");
    integer(route.consideredCount, 0, Number.MAX_SAFE_INTEGER, "consideredCount");
    integer(route.matchedCount, 0, route.consideredCount, "matchedCount");
    integer(route.limit, 1, p.perRouteLimit, "route.limit");
    strings(route.returnedRecordIds, "returnedRecordIds"); strings(route.notes, "route.notes", 1);
    check(route.returnedRecordIds.length <= route.limit && route.returnedRecordIds.length <= route.matchedCount, "Route return count exceeds discovery or limit");
    if (route.status === "complete") check(route.matchedCount === route.returnedRecordIds.length, "Truncated route cannot claim complete coverage");
    if (route.status === "not-applicable") check(route.consideredCount === 0 && route.matchedCount === 0 && route.returnedRecordIds.length === 0, "Inapplicable route cannot claim discovery");
  }
  check(Array.isArray(value.candidatePool) && value.candidatePool.length <= p.maxCandidates, "Candidate pool exceeds policy bound");
  const candidates = new Map();
  for (const candidate of value.candidatePool) {
    shape(candidate, ["recordId", "reasons", "selected", "exclusionReason", "lineage"], "candidate");
    text(candidate.recordId, "candidate.recordId");
    check(!candidates.has(candidate.recordId), "Duplicate candidate"); candidates.set(candidate.recordId, candidate);
    check(typeof candidate.selected === "boolean", "Selection must be explicit boolean");
    if (candidate.selected) check(candidate.exclusionReason === null, "Selected candidate cannot have exclusion reason");
    else text(candidate.exclusionReason, "candidate.exclusionReason");
    check(Array.isArray(candidate.reasons) && candidate.reasons.length > 0 && candidate.reasons.length <= routes.size, "Candidate needs bounded discovery reasons");
    const reasonRoutes = new Set();
    for (const reason of candidate.reasons) {
      shape(reason, ["route", "detail", "sourceIds"], "reason");
      check(routes.get(reason.route)?.returnedRecordIds.includes(candidate.recordId) && !reasonRoutes.has(reason.route), "Reason must match a unique route that discovered this candidate");
      reasonRoutes.add(reason.route); text(reason.detail, "reason.detail"); strings(reason.sourceIds, "reason.sourceIds");
    }
    shape(candidate.lineage, ["rootRecordIds", "status"], "lineage");
    check(["declared-ancestry", "incomplete"].includes(candidate.lineage.status), "Lineage is not an independence verdict");
    strings(candidate.lineage.rootRecordIds, "lineage.rootRecordIds", candidate.lineage.status === "declared-ancestry" ? 1 : 0);
  }
  strings(value.selectedRecordIds, "selectedRecordIds");
  check(value.selectedRecordIds.length <= p.maxSelected, "Selection exceeds context policy bound");
  const selected = new Set(value.selectedRecordIds);
  check(value.selectedRecordIds.every((id) => candidates.get(id)?.selected) && value.candidatePool.every((candidate) => candidate.selected === selected.has(candidate.recordId)), "Selected IDs and candidate decisions disagree");
  shape(value.workingContext, ["status", "recordIds"], "workingContext");
  check(value.workingContext.status === "not-applied" && Array.isArray(value.workingContext.recordIds) && value.workingContext.recordIds.length === 0, "Library decision cannot claim actual context use");
  shape(value.ancestry, ["previousRetrievalEventIds", "attentionSourceIds"], "ancestry");
  strings(value.ancestry.previousRetrievalEventIds, "previousRetrievalEventIds"); strings(value.ancestry.attentionSourceIds, "attentionSourceIds");
  strings(value.limits, "limits", 1);
  return value;
}

function referencedIds(event) {
  return [...new Set([
    ...event.request.activeQuestionIds, ...event.ancestry.previousRetrievalEventIds, ...event.ancestry.attentionSourceIds,
    ...event.routes.flatMap((route) => route.returnedRecordIds),
    ...event.candidatePool.flatMap((candidate) => [candidate.recordId, ...candidate.lineage.rootRecordIds, ...candidate.reasons.flatMap((reason) => reason.sourceIds)])
  ])].sort();
}

// Index only internally validated frozen snapshots, not caller identities.
const historyIndexes = new WeakMap();
function historyOf(snapshot, stateId) {
  text(stateId, "stateId");
  let cached = historyIndexes.get(snapshot);
  if (!cached) { cached = new Map(); historyIndexes.set(snapshot, cached); }
  if (cached.has(stateId)) return cached.get(stateId);
  const stateMap = new Map(snapshot.states.map((state) => [state.id, state]));
  check(stateMap.has(stateId), "Selected Field state does not exist");
  const visited = new Set(), nodeIds = new Set(), edgeIds = new Set(), pending = [stateId];
  while (pending.length) {
    const id = pending.pop(); if (visited.has(id)) continue;
    visited.add(id); const state = stateMap.get(id);
    state.nodeIds.forEach((item) => nodeIds.add(item)); state.edgeIds.forEach((item) => edgeIds.add(item));
    pending.push(...state.parentStateIds);
  }
  const result = Object.freeze({ snapshot,
    nodes: Object.freeze(snapshot.nodes.filter((node) => nodeIds.has(node.id))),
    edges: Object.freeze(snapshot.edges.filter((edge) => edgeIds.has(edge.id))),
    states: Object.freeze(snapshot.states.filter((state) => visited.has(state.id))) });
  cached.set(stateId, result);
  return result;
}

function validateReferences(event, available) {
  const nodes = new Map(available.nodes.map((node) => [node.id, node]));
  for (const id of referencedIds(event)) check(nodes.has(id), `Retrieval reference ${id} is outside selected parent history`);
  for (const id of event.request.activeQuestionIds) check(nodes.get(id).kind === "question" && !isAuditNode(nodes.get(id)), "Active question must reference a question node, not audit history");
  for (const id of event.ancestry.previousRetrievalEventIds) check(marked(nodes.get(id)), "Previous retrieval ID must reference a RetrievalEvent");
  for (const id of event.ancestry.attentionSourceIds) check(!isAuditNode(nodes.get(id)), "Attention sources are ordinary attributed nodes, not event objects");
  for (const route of event.routes) for (const id of route.returnedRecordIds) check(!isAuditNode(nodes.get(id)), "Audit events are audit history, not candidate evidence");
  for (const candidate of event.candidatePool) {
    for (const id of [...candidate.lineage.rootRecordIds, ...candidate.reasons.flatMap((reason) => reason.sourceIds)]) {
      check(!isAuditNode(nodes.get(id)), "Audit events belong in an explicit prior-event trace, not candidate source ancestry");
    }
  }
}

const validatedSnapshots = new WeakSet();
export function validateRetrievalField(input) {
  if (validatedSnapshots.has(input)) return input;
  const snapshot = validateStructuralField(input);
  for (const record of [snapshot, ...snapshot.edges, ...snapshot.states]) check(!marked(record), "Retrieval payload belongs only on an observation node");
  const histories = new Map();
  const history = (id) => { if (!histories.has(id)) histories.set(id, historyOf(snapshot, id)); return histories.get(id); };
  const nodes = new Map(snapshot.nodes.map((node) => [node.id, node]));
  for (const node of snapshot.nodes) {
    if (node.revises !== null) check(!isAuditNode(nodes.get(node.revises)), "Audit events cannot be revised, even after removing their marker");
    if (!marked(node)) continue;
    const event = validateRetrievalEvent(node.extensions[RETRIEVAL_EXTENSION]);
    check(node.kind === "observation" && !["aether:capture", "aether:structural", "aether:assembly", "aether:execution", "aether:execution-observation"].some((key) => Object.hasOwn(node.extensions, key)), "Retrieval event must remain separate from capture, interpretation and assembly; execution audits are separate too");
    check(node.revises === null && node.status === "open" && node.confidence.value === null && node.confidence.basis === "unknown" && node.primitives.length === 0, "Retrieval event cannot carry revised beliefs or evidence strength");
    check(JSON.stringify(node.derivedFrom) === JSON.stringify(referencedIds(event)), "Event derivedFrom must exactly cover its sorted references");
    validateReferences(event, history(event.fieldStateId));
    for (const state of snapshot.states.filter((item) => item.nodeIds.includes(node.id))) {
      const inherited = state.parentStateIds.some((parentId) => history(parentId).nodes.some((item) => item.id === node.id));
      if (!inherited) check(state.parentStateIds.length === 1 && state.parentStateIds[0] === event.fieldStateId, "Event must be introduced directly after its declared Field state");
    }
  }
  validatedSnapshots.add(snapshot);
  return snapshot;
}

export function retrievalHistory(input, stateId) {
  return historyOf(validateRetrievalField(input), stateId);
}

export function addRetrievalEvent(input, change) {
  const snapshot = validateRetrievalField(input), command = validateFieldJson(change);
  shape(command, ["parentStateId", "stateId", "nodeId", "createdAt", "provenance", "event"], "command");
  const event = validateRetrievalEvent(command.event);
  check(event.fieldStateId === command.parentStateId, "Event must name the selected parent state");
  validateReferences(event, historyOf(snapshot, command.parentStateId));
  return validateRetrievalField(applyFieldChange(snapshot, {
    parentStateId: command.parentStateId, stateId: command.stateId, createdAt: command.createdAt, provenance: command.provenance,
    actions: [{ type: "add-node", record: {
      id: command.nodeId, kind: "observation", content: { format: "text/plain", text: "Retrieval decision recorded; no model context applied." },
      context: "Versioned retrieval audit; attention is not evidence.", status: "open", confidence: { value: null, basis: "unknown" },
      provenance: command.provenance, derivedFrom: referencedIds(event), primitives: [], extensions: { [RETRIEVAL_EXTENSION]: event }
    } }]
  }));
}

export function readRetrievalEvents(input, stateId) {
  const snapshot = validateRetrievalField(input);
  return Object.freeze(readFieldState(snapshot, stateId).nodes.filter(marked));
}
