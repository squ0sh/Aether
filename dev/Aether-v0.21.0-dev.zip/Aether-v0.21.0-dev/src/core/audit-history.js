// Conservative role classification, not payload validation. Even an unknown or
// malformed own audit marker must not turn into ordinary candidate evidence.
// Dedicated event readers remain responsible for validating each event payload.
export function isAuditNode(record) {
  const extensions = record?.extensions;
  return Boolean(extensions && typeof extensions === "object" &&
    ["aether:retrieval", "aether:assembly", "aether:execution", "aether:execution-observation", "aether:continuation"].some((key) => Object.hasOwn(extensions, key)));
}
