import { validateFieldJson } from "./field.js";
import { applyFieldChange } from "./field-operations.js";
import { isAuditNode } from "./audit-history.js";
import { retrievalHistory } from "./retrieval-events.js";
import { validateExecutionField } from "./execution-events.js";

export const CONTINUATION_EXTENSION = "aether:continuation";
export const CONTINUATION_VERSION = "aether-continuation-v0.1";
export const DEFAULT_CONTINUATION_POLICY = validateFieldJson({ id: "aether-finite-review", version: "1", mode: "evaluate", preferredDirectionIds: [] });
const limitations = [
  "Attributed reasons and snapshots are not authenticated facts or world evidence.",
  "Recurrence uses declared ancestry, not a semantic equivalence oracle.",
  "No model call, execution, scheduling, lasting permission, or truth ranking is implied.",
  "Future execution must independently recheck current authority and resources."
];
const kinds = ["human-request", "discriminating-evidence", "dependency-review", "capability-change", "reconsideration-met", "open-question", "contradiction", "proposal", "urgency", "self-preservation", "surprise", "previous-failure", "unanswerable", "counterargument"];
const warrants = new Set(kinds.slice(0, 5));
const marked = (node) => Object.hasOwn(node.extensions, CONTINUATION_EXTENSION);
const sorted = (ids) => [...new Set(ids)].sort();
const same = (a, b) => canonical(a) === canonical(b);
function canonical(v) {
  if (Array.isArray(v)) return `[${v.map(canonical).join(",")}]`;
  if (v && typeof v === "object") return `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical(v[k])}`).join(",")}}`;
  return JSON.stringify(v);
}
export class ContinuationValidationError extends Error {
  constructor(message) { super(message); this.name = "ContinuationValidationError"; this.code = "INVALID_CONTINUATION"; }
}
const check = (yes, message) => { if (!yes) throw new ContinuationValidationError(message); };
const text = v => check(typeof v === "string" && v.trim().length > 0, "Expected nonempty text");
function shape(v, keys) {
  check(v && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === keys.length && keys.every(k => Object.hasOwn(v, k)), `Expected fields: ${keys.join(", ")}`);
}
function ids(v) { check(Array.isArray(v) && v.length <= 256, "Expected bounded ID list"); v.forEach(text); check(new Set(v).size === v.length, "Duplicate ID"); }
function commandShape(c) {
  shape(c, ["fieldStateId", "policy", "trigger", "directions", "authority", "resources", "materialChangeIds", "reconsiderationConditions"]);
  text(c.fieldStateId);
  shape(c.policy, ["id", "version", "mode", "preferredDirectionIds"]);
  text(c.policy.id); text(c.policy.version); ids(c.policy.preferredDirectionIds);
  check(["evaluate", "review-only"].includes(c.policy.mode), "Unsupported finite policy mode");
  shape(c.trigger, ["kind", "sourceIds"]);
  check(["human-request", "proposal", "scheduled-wake", "field-change", "manual-review"].includes(c.trigger.kind), "Unknown trigger kind"); ids(c.trigger.sourceIds);
  check(Array.isArray(c.directions) && c.directions.length <= 32, "At most 32 nested directions");
  ids(c.directions.map(d => d.recordId));
  for (const d of c.directions) {
    shape(d, ["recordId", "objectiveIds", "reasons", "requiredCapabilities", "requiresExternalAccess", "requiredCalls"]);
    text(d.recordId); ids(d.objectiveIds); ids(d.requiredCapabilities);
    check(typeof d.requiresExternalAccess === "boolean", "External requirement must be explicit");
    check(Number.isSafeInteger(d.requiredCalls) && d.requiredCalls >= 0 && d.requiredCalls <= 32, "Finite call bound required");
    check(Array.isArray(d.reasons) && d.reasons.length > 0 && d.reasons.length <= 32, "Bounded attributed reasons required");
    for (const r of d.reasons) { shape(r, ["kind", "sourceIds", "detail"]); check(kinds.includes(r.kind), "Unknown reason kind"); ids(r.sourceIds); check(r.sourceIds.length > 0, "Reason requires provenance references"); text(r.detail); }
  }
  check(c.policy.preferredDirectionIds.every(id => c.directions.some(d => d.recordId === id)), "Policy preference outside considered directions");
  shape(c.authority, ["status", "sourceIds", "scopeIds", "restrictions"]);
  check(["granted", "denied", "unknown"].includes(c.authority.status), "Unknown authority status");
  ids(c.authority.sourceIds); ids(c.authority.scopeIds); ids(c.authority.restrictions);
  check(c.authority.restrictions.every(r => ["shutdown", "no-inference", "no-external-calls"].includes(r)), "Unknown restriction");
  if (c.authority.status !== "unknown" || c.authority.restrictions.length) check(c.authority.sourceIds.length > 0, "Authority needs attributed human/system sources");
  shape(c.resources, ["remainingCalls", "availableCapabilities", "unavailableCapabilities", "sourceIds"]);
  check(c.resources.remainingCalls === null || Number.isSafeInteger(c.resources.remainingCalls) && c.resources.remainingCalls >= 0, "Unknown or nonnegative resource budget required");
  ids(c.resources.availableCapabilities); ids(c.resources.unavailableCapabilities); ids(c.resources.sourceIds);
  check(!c.resources.availableCapabilities.some(id => c.resources.unavailableCapabilities.includes(id)), "Conflicting capability snapshot");
  check(c.resources.sourceIds.length > 0 || c.resources.remainingCalls === null && !c.resources.availableCapabilities.length && !c.resources.unavailableCapabilities.length, "Known resources require provenance");
  ids(c.materialChangeIds); ids(c.reconsiderationConditions);
}
function sourceIds(c) {
  return sorted([...c.trigger.sourceIds, ...c.authority.sourceIds, ...c.authority.scopeIds, ...c.resources.sourceIds, ...c.materialChangeIds,
    ...c.directions.flatMap(d => [d.recordId, ...d.objectiveIds, ...d.reasons.flatMap(r => r.sourceIds)])]);
}
function refs(event) { return sorted([...sourceIds(event.consideration), ...event.priorDecisionIds, ...event.priorExecutionIds]); }
// No text parsing, model call, clock, scheduler or mutable policy registry.
function evaluate(snapshot, c) {
  commandShape(c);
  const available = retrievalHistory(snapshot, c.fieldStateId), nodes = new Map(available.nodes.map(n => [n.id, n]));
  for (const id of sourceIds(c)) check(nodes.has(id) && !isAuditNode(nodes.get(id)), `Ordinary source ${id} missing or is audit history`);
  for (const id of c.authority.sourceIds) check(["human", "system"].includes(nodes.get(id).provenance.sourceType), "Model/tool proposals cannot grant authority");
  if (c.trigger.kind === "human-request") check(c.trigger.sourceIds.length > 0 && c.trigger.sourceIds.every(id => nodes.get(id).provenance.sourceType === "human"), "Human intent must retain human provenance");
  for (const d of c.directions) for (const r of d.reasons) if (r.kind === "human-request") check(r.sourceIds.every(id => nodes.get(id).provenance.sourceType === "human"), "Human reason cannot be fabricated from model output");
  const lineage = (start) => {
    const seen = new Set(), pending = [...start];
    while (pending.length) { const id = pending.pop(); if (seen.has(id)) continue; seen.add(id); const n = nodes.get(id); if (n) pending.push(...n.derivedFrom); }
    return seen;
  };
  const prior = available.nodes.filter(marked);
  const assessments = c.directions.map(d => {
    const ancestry = lineage([d.recordId, ...d.objectiveIds]);
    const related = prior.filter(n => n.extensions[CONTINUATION_EXTENSION].consideration.directions.some(old => [...lineage([old.recordId, ...old.objectiveIds])].some(id => ancestry.has(id))));
    const oldNodes = new Set(related.flatMap(n => retrievalHistory(snapshot, n.extensions[CONTINUATION_EXTENSION].consideration.fieldStateId).nodes.map(n => n.id)));
    const material = c.materialChangeIds.filter(id => !oldNodes.has(id) && [...lineage([id])].every(source => nodes.has(source) && !isAuditNode(nodes.get(source)) && nodes.get(source).provenance.sourceType !== "model"));
    const reasons = d.reasons.filter(r => warrants.has(r.kind));
    const supported = id => [...lineage([id])].every(source => nodes.has(source) && !isAuditNode(nodes.get(source)) && nodes.get(source).provenance.sourceType !== "model");
    const worthwhile = reasons.some(r => r.sourceIds.some(supported)) && !d.reasons.some(r => r.kind === "unanswerable");
    const recurrent = related.length > 0;
    const changed = material.some(id => reasons.some(r => r.sourceIds.includes(id)));
    const blockers = [];
    if (d.reasons.some(r => r.kind === "counterargument")) blockers.push("unresolved-counterargument");
    if (c.authority.status === "denied" || c.authority.restrictions.includes("shutdown") || d.requiredCalls > 0 && c.authority.restrictions.includes("no-inference") || d.requiresExternalAccess && c.authority.restrictions.includes("no-external-calls")) blockers.push("forbidden");
    if (c.authority.status === "unknown" || c.authority.status === "granted" && !c.authority.scopeIds.includes(d.recordId)) blockers.push("authority-unknown-or-out-of-scope");
    if (d.requiredCalls > 0 && c.resources.remainingCalls === null || d.requiredCapabilities.some(id => !c.resources.availableCapabilities.includes(id) && !c.resources.unavailableCapabilities.includes(id))) blockers.push("resources-unknown");
    if (c.resources.remainingCalls !== null && d.requiredCalls > c.resources.remainingCalls || d.requiredCapabilities.some(id => c.resources.unavailableCapabilities.includes(id))) blockers.push("resources-unavailable");
    let outcome = "eligible";
    if (blockers.includes("forbidden")) outcome = "forbidden";
    else if (!worthwhile || recurrent && !changed) outcome = "wait";
    else if (blockers.includes("authority-unknown-or-out-of-scope") || blockers.includes("resources-unknown") || blockers.includes("unresolved-counterargument")) outcome = "unresolved";
    else if (blockers.includes("resources-unavailable")) outcome = "blocked";
    return { recordId: d.recordId, worthwhile, recurrent, materialChangeIds: material, relatedDecisionIds: related.map(n => n.id).sort(), blockers, outcome };
  });
  const eligible = assessments.filter(a => a.outcome === "eligible");
  const preferred = c.policy.preferredDirectionIds.find(id => eligible.some(a => a.recordId === id));
  const selectedDirectionId = c.policy.mode === "evaluate" ? preferred ?? (eligible.length === 1 ? eligible[0].recordId : null) : null;
  for (const a of eligible) a.outcome = a.recordId === selectedDirectionId ? "continue" : "deferred";
  const outcomes = new Set(assessments.map(a => a.outcome));
  const outcome = c.authority.restrictions.includes("shutdown") ? "forbidden" : selectedDirectionId ? "continue" : eligible.length ? "deferred" : outcomes.size === 1 ? [...outcomes][0] : outcomes.size === 0 ? "wait" : "unresolved";
  return validateFieldJson({ schemaVersion: 1, vocabularyVersion: CONTINUATION_VERSION, consideration: c,
    priorDecisionIds: prior.map(n => n.id).sort(), priorExecutionIds: available.nodes.filter(n => Object.hasOwn(n.extensions, "aether:execution")).map(n => n.id).sort(),
    assessments, selectedDirectionId, outcome, limitations });
}
const validated = new WeakSet();
export function validateContinuationField(input) {
  if (validated.has(input)) return input;
  const snapshot = validateExecutionField(input);
  for (const r of [snapshot, ...snapshot.edges, ...snapshot.states]) check(!marked(r), "Continuation payload belongs only on an observation node");
  for (const node of snapshot.nodes.filter(marked)) {
    check(node.kind === "observation" && node.revises === null && node.status === "open" && node.confidence.value === null && node.confidence.basis === "unknown" && !node.primitives.length, "Decision is immutable audit, not a belief");
    check(["human", "system"].includes(node.provenance.sourceType), "Decision must be recorded by trusted host or human, not a model");
    check(!["aether:capture", "aether:structural", "aether:retrieval", "aether:assembly", "aether:execution", "aether:execution-observation", "aether:execution-return"].some(k => Object.hasOwn(node.extensions, k)), "Continuation audit roles cannot be combined");
    const event = node.extensions[CONTINUATION_EXTENSION];
    shape(event, ["schemaVersion", "vocabularyVersion", "consideration", "priorDecisionIds", "priorExecutionIds", "assessments", "selectedDirectionId", "outcome", "limitations"]);
    check(event.schemaVersion === 1 && event.vocabularyVersion === CONTINUATION_VERSION, "Unsupported continuation schema or vocabulary");
    check(same(event, evaluate(snapshot, event.consideration)), "Decision differs from deterministic policy reconstruction");
    check(same(node.derivedFrom, refs(event)), "Decision ancestry must exactly cover its references");
    let introduced = false;
    for (const state of snapshot.states.filter(s => s.nodeIds.includes(node.id))) {
      const inherited = state.parentStateIds.some(id => retrievalHistory(snapshot, id).nodes.some(n => n.id === node.id));
      if (!inherited) { introduced = true; check(same(state.parentStateIds, [event.consideration.fieldStateId]), "Decision must follow its declared Field state"); }
    }
    check(introduced, "Decision must have an introduction state");
  }
  validated.add(snapshot); return snapshot;
}
export function buildContinuationDecision(input, consideration) {
  return evaluate(validateContinuationField(input), validateFieldJson(consideration));
}
export function addContinuationDecision(input, change) {
  const snapshot = validateContinuationField(input), c = validateFieldJson(change);
  shape(c, ["parentStateId", "stateId", "nodeId", "createdAt", "provenance", "decision"]);
  check(c.parentStateId === c.decision.consideration.fieldStateId, "Decision must name selected parent state");
  check(same(c.decision, evaluate(snapshot, c.decision.consideration)), "Decision does not match reconstruction");
  return validateContinuationField(applyFieldChange(snapshot, { parentStateId: c.parentStateId, stateId: c.stateId, createdAt: c.createdAt, provenance: c.provenance,
    actions: [{ type: "add-node", record: { id: c.nodeId, kind: "observation", content: { format: "text/plain", text: `Continuation decision: ${c.decision.outcome}. No execution implied.` },
      context: "Internal decision audit; not independent world evidence or lasting authorization.", provenance: c.provenance,
      derivedFrom: refs(c.decision), extensions: { [CONTINUATION_EXTENSION]: c.decision } } }] }));
}
export function readContinuationHistory(input, stateId) {
  const snapshot = validateContinuationField(input), history = retrievalHistory(snapshot, stateId);
  return validateFieldJson({ fieldStateId: stateId, decisions: history.nodes.filter(marked), executionAttribution: "unknown", temporalGaps: "unknown",
    limitations: ["No decision is inferred from inactivity. Execution must be explicitly attributed by a future integration; mere co-presence is not a link."] });
}
