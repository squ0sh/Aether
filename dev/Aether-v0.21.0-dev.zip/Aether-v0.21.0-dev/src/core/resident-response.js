import { validateFieldJson } from "./field.js";

export class ResidentValidationError extends Error {
  constructor(message) { super(message); this.name = "ResidentValidationError"; this.code = "INVALID_RESIDENT"; }
}
export const residentCheck = (yes, message) => { if (!yes) throw new ResidentValidationError(message); };
export function residentShape(value, fields) {
  residentCheck(value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === fields.length && fields.every(k => Object.hasOwn(value, k)), `Expected resident fields: ${fields.join(", ")}`);
}
export function residentText(value) { residentCheck(typeof value === "string" && value.trim().length > 0 && value.length <= 4096, "Bounded nonempty resident text required"); }
export function residentStrings(value, minimum = 0) {
  residentCheck(Array.isArray(value) && value.length >= minimum && value.length <= 32, "Bounded resident list required"); value.forEach(residentText);
  residentCheck(new Set(value).size === value.length, "Duplicate resident list entry");
}
export function validateResidentIdentity(input) {
  const v = validateFieldJson(input);
  residentShape(v, ["participantId", "providerId", "modelId", "runtimeId", "representation", "weightsId", "quantization", "adapter"]);
  for (const k of ["participantId", "providerId", "modelId", "runtimeId", "representation", "weightsId", "quantization"]) residentText(v[k]);
  residentShape(v.adapter, ["id", "version"]); residentText(v.adapter.id); residentText(v.adapter.version); return v;
}

// A structural admission format, not a detector of truthful or faithful reasoning.
// Raw output is captured even when this strict proposal parser rejects it.
export function validateResidentResponse(input, { phase, sourceIds }) {
  const v = validateFieldJson(input), allowed = new Set(sourceIds);
  residentShape(v, ["contractVersion", "phase", "alternatives", "questions", "analogies", "compression", "limitations"]);
  residentCheck(v.contractVersion === "0.1" && v.phase === phase && ["expand", "contract", "integrate"].includes(phase), "Unknown or mismatched resident response phase");
  const refs = ids => { residentStrings(ids); residentCheck(ids.every(id => allowed.has(id)), "Resident referenced material outside its assembled perspective"); };
  for (const kind of ["alternatives", "questions"]) {
    residentCheck(Array.isArray(v[kind]) && v[kind].length <= 16, "Bounded proposals required");
    for (const item of v[kind]) { residentShape(item, ["text", "sourceIds"]); residentText(item.text); refs(item.sourceIds); }
  }
  residentCheck(Array.isArray(v.analogies) && v.analogies.length <= 8, "Bounded analogies required");
  for (const a of v.analogies) {
    residentShape(a, ["text", "sourceIds", "similarity", "referenceFrame", "scale", "context", "knownMechanisms", "differences", "failureBoundaries"]);
    refs(a.sourceIds); residentCheck(a.sourceIds.length >= 2, "Analogy needs two explicit source references");
    for (const k of ["text", "similarity", "referenceFrame", "scale", "context", "knownMechanisms"]) residentText(a[k]);
    residentStrings(a.differences, 1); residentStrings(a.failureBoundaries, 1);
  }
  if (v.compression !== null) {
    const c = v.compression;
    residentShape(c, ["text", "sourceIds", "preserved", "omitted", "recoverableSourceIds", "unrecoverable", "uncertainty"]);
    residentText(c.text); refs(c.sourceIds); residentCheck(c.sourceIds.length > 0, "Compression needs preserved ancestry");
    refs(c.recoverableSourceIds); residentCheck(c.recoverableSourceIds.every(id => c.sourceIds.includes(id)), "Recovery cannot invent sources");
    for (const k of ["preserved", "omitted", "unrecoverable", "uncertainty"]) residentStrings(c[k], 1);
  }
  residentStrings(v.limitations, 1); return v;
}

export const MOCK_RESIDENT_IDENTITY = validateResidentIdentity({ participantId: "resident-example", providerId: "controlled-mock", modelId: "deterministic-resident", runtimeId: "node-mock-v1",
  representation: "deterministic-fixture", weightsId: "none", quantization: "none", adapter: { id: "resident-mock", version: "1" } });

// Scripted outputs prove boundary behavior only. No claim of intelligence, model
// quality, low-bit performance or scientific mechanism is made by this mock.
export function createMockResident({ identity = MOCK_RESIDENT_IDENTITY, response = null } = {}) {
  const config = validateResidentIdentity(identity), scripted = response === null ? null : validateFieldJson(response);
  return Object.freeze({ id: config.adapter.id, version: config.adapter.version,
    async execute(request, { emit, signal }) {
      if (signal.aborted) return { kind: "cancelled", outputStatus: "unknown", parseStatus: "unknown", diagnostic: "Mock cancelled." };
      const body = JSON.parse(request.body);
      const refs = body.assembly.history.map(h => h.representationRecordId).slice(0, 16);
      const output = scripted ?? { contractVersion: "0.1", phase: body.phase,
        alternatives: [], questions: body.phase === "expand" ? [{ text: "What preserved observation would distinguish the available alternatives?", sourceIds: refs }] : [],
        analogies: [], compression: body.phase === "contract" && refs.length ? { text: "Sources retained; no consensus or semantic equivalence inferred.", sourceIds: refs,
          preserved: ["Source identifiers and unresolved alternatives remain in the Field."], omitted: ["Source wording is not reproduced in this small working representation."],
          recoverableSourceIds: refs, unrecoverable: ["Any information never preserved externally remains unavailable."], uncertainty: ["This mock does not certify semantic faithfulness."] } : null,
        limitations: ["Deterministic mock, not a cognitive result.", "Unobserved intervals and missing information remain unknown.", "Similar structure does not establish a shared mechanism."] };
      await emit({ kind: "submitted", content: "Controlled mock received the bounded representation.", details: { representationSha256: request.sha256, evidence: "In-process mock received these exact bytes." } });
      await emit({ kind: "output", content: JSON.stringify(output), details: { encoding: "json-string" } });
      return { kind: "completed", outputStatus: "complete", parseStatus: "parsed", diagnostic: "Finite mock phase completed; another phase is not authorized." };
    }
  });
}
