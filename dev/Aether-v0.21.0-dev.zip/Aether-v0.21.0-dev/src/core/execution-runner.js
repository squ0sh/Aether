import { validateFieldJson } from "./field.js";
import { assertConversationField } from "./conversation-field.js";
import { EXECUTION_EXTENSION, EXECUTION_OBSERVATION, TERMINATIONS, ExecutionValidationError, executionCheck,
  validateExecutionField, addExecutionEvent, appendExecutionObservation, readExecutionHistory,
  executionProvenance, captureExecutionReturn } from "./execution-events.js";

const check = executionCheck;
const only = (value, names) => value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).every((key) => names.includes(key));
const diagnostic = (error) => typeof error?.message === "string" ? error.message.slice(0, 4096) + (error.message.length > 4096 ? " [diagnostic truncated to local safety bound]" : "") : "Runtime boundary ended without a readable diagnostic.";
function terminal(value) {
  const result = validateFieldJson(value);
  check(only(result, ["kind", "outputStatus", "parseStatus", "diagnostic"]) && Object.keys(result).length === 4, "Adapter must return an explicit termination observation");
  check(TERMINATIONS.includes(result.kind) && ["complete", "partial", "unknown"].includes(result.outputStatus) && ["parsed", "failed", "unknown"].includes(result.parseStatus) && typeof result.diagnostic === "string", "Malformed adapter return");
  if (result.kind === "completed") check(result.outputStatus === "complete" && result.parseStatus === "parsed", "Incomplete response cannot claim completion");
  if (result.outputStatus === "complete") check(result.kind === "completed", "Complete status needs a completed boundary");
  if (result.kind === "partial") check(result.outputStatus === "partial", "Partial status required");
  if (result.kind === "parse-error") check(result.parseStatus === "failed", "Parse failure must remain explicit");
  return result;
}

// Controlled in-process adapter harness only. No production adapter, live chat,
// automatic retry, networking, or tool executor is registered by this module.
// The existing Field snapshot transaction is the durability journal: chunks and
// observations publish append-only history using private atomic/fsynced saves.
export class DurableExecutionRunner {
  constructor({ fieldStore, coordinator, fieldId, conversationId, clock = () => new Date().toISOString() }) {
    check(fieldStore && coordinator && coordinator.fieldStore === fieldStore, "Runner requires the existing linked-deletion coordinator for this store");
    check(typeof fieldId === "string" && fieldId.trim() && typeof conversationId === "string" && conversationId.trim(), "Explicit dedicated Field and conversation required");
    check(typeof clock === "function", "Clock must be a trusted local function");
    this.store = fieldStore; this.coordinator = coordinator; this.fieldId = fieldId; this.conversationId = conversationId; this.clock = clock;
  }
  async #load() {
    const saved = await this.store.load(this.fieldId, { confirmDurability: true });
    check(saved, "Execution Field is missing");
    assertConversationField(saved.snapshot, this.conversationId); validateExecutionField(saved.snapshot);
    check(saved.headStateIds.length === 1, "Execution requires one explicitly selected/integrated Field head");
    return { snapshot: saved.snapshot, head: saved.headStateIds[0] };
  }
  async prepare(change) {
    const command = validateFieldJson(change);
    return this.coordinator.withActiveConversation(this.conversationId, async () => {
      const state = await this.#load();
      check(command.parentStateId === state.head, "Preparation must extend the current selected Field head");
      const next = addExecutionEvent(state.snapshot, command);
      await this.store.save(next, { requestId: `execution-prepare:${command.nodeId}` });
      return { executionId: command.nodeId, durability: "confirmed-by-store", history: readExecutionHistory(next, command.stateId, command.nodeId) };
    });
  }
  async inspect(executionId) {
    const state = await this.#load();
    return { durability: "confirmed-by-store", history: readExecutionHistory(state.snapshot, state.head, executionId) };
  }
  async #capture(state, executionId) {
    const next = captureExecutionReturn(state.snapshot, { parentStateId: state.head, executionEventId: executionId,
      createdAt: this.clock(), conversationId: this.conversationId });
    if (next !== state.snapshot && next.states.length !== state.snapshot.states.length) {
      await this.store.save(next, { requestId: `execution-capture:${executionId}` });
      state.snapshot = next; state.head = next.states.at(-1).id;
    }
    return { durability: "confirmed-by-store", history: readExecutionHistory(state.snapshot, state.head, executionId) };
  }
  async recover(executionId) {
    return this.coordinator.withActiveConversation(this.conversationId, async () => this.#capture(await this.#load(), executionId));
  }
  async run({ executionId, adapter, signal, cancelSource = "human", capture = true, admission }) {
    check(typeof capture === "boolean", "Capture option must be explicit boolean");
    check(["human", "system"].includes(cancelSource), "Cancellation source must be human or system");
    check(adapter && typeof adapter.execute === "function", "A controlled local adapter is required");
    if (signal !== undefined) check(signal instanceof AbortSignal, "Cancellation requires an AbortSignal");
    if (admission !== undefined) check(typeof admission === "function", "Admission must be a trusted synchronous host function");
    return this.coordinator.withActiveConversation(this.conversationId, async () => {
      const state = await this.#load(), initial = readExecutionHistory(state.snapshot, state.head, executionId);
      check(initial.observations.length === 0, "Attempt already has durable observations; recovery never resubmits it. Create a new ExecutionEvent for retry.", "EXECUTION_ALREADY_ATTEMPTED");
      const eventNode = initial.execution, event = eventNode.extensions[EXECUTION_EXTENSION];
      check(!Object.hasOwn(event.request.parameters ?? {}, "resident") || typeof admission === "function", "Resident attempts require fresh host admission");
      check(adapter.id === event.target.adapter.id && adapter.version === event.target.adapter.version, "Adapter identity/version differs from the prepared target");
      const controller = new AbortController();
      let queue = Promise.resolve(), failure = null, accepting = true, timer, onCancel;
      let resolveStop;
      const stop = new Promise((resolve) => { resolveStop = resolve; });
      const current = () => readExecutionHistory(state.snapshot, state.head, executionId);
      const persist = async (item) => {
        if (failure) throw failure;
        const sequence = current().observations.length + 1;
        const id = `${executionId}:observation:${sequence}`, stateId = `${id}:state`, createdAt = this.clock();
        const next = appendExecutionObservation(state.snapshot, { parentStateId: state.head, stateId, nodeId: id, createdAt,
          provenance: executionProvenance(eventNode, this.conversationId, item.kind === "output" ? "model" : item.kind === "raw-response" ? "tool" : "system"),
          executionEventId: executionId, kind: item.kind, content: item.content, details: item.details,
          occurredAt: item.occurredAt === undefined ? createdAt : item.occurredAt, order: item.order ?? "local-observation" });
        await this.store.save(next, { requestId: id });
        state.snapshot = next; state.head = stateId;
      };
      const enqueue = (input) => {
        const item = validateFieldJson(input);
        check(only(item, ["kind", "content", "details", "occurredAt", "order"]) && ["kind", "content", "details"].every((key) => Object.hasOwn(item, key)), "Observation has missing/unknown fields");
        const task = queue.then(() => persist(item));
        queue = task.catch((error) => { failure ||= error; controller.abort(error); resolveStop({ type: "recording-error", error }); });
        return task;
      };
      const emit = (input) => {
        check(accepting, "Adapter emission arrived after the local execution boundary closed", "EXECUTION_CLOSED");
        const item = validateFieldJson(input);
        check(["submitted", "acknowledged", "output", "raw-response", "note"].includes(item?.kind), "Adapter cannot create control or capture boundaries");
        return enqueue(item);
      };
      const cancellation = () => {
        if (!accepting) return;
        // Only the local request order is known, never the remote generation order.
        enqueue({ kind: "cancel-requested", content: "Cancellation requested; provider stop and unobserved output remain unknown.",
          details: { requestedBy: cancelSource, effect: "unknown" } }).catch(() => {});
        controller.abort(); resolveStop({ type: "stop", kind: "cancelled" });
      };
      let outcome;
      try {
        onCancel = cancellation;
        signal?.addEventListener("abort", onCancel, { once: true });
        if (signal?.aborted) cancellation();
        else {
          await enqueue({ kind: "submission-intent", content: "Durable intent immediately before local adapter dispatch; actual submission remains unconfirmed.", details: { representationSha256: event.request.sha256 } });
          // Cancellation can occur while intent is being made durable.
          if (!signal?.aborted) {
            if (event.bounds.timeoutMs !== null) timer = setTimeout(() => { controller.abort(); resolveStop({ type: "stop", kind: "timeout" }); }, event.bounds.timeoutMs);
            const executed = Promise.resolve().then(async () => {
              // Host control runs under the existing ownership lock, after durable
              // intent and immediately before dispatch. Model output never supplies it.
              if (admission) {
                let access;
                try {
                  access = validateFieldJson(admission({ snapshot: state.snapshot, headStateId: state.head, execution: eventNode }));
                  check(only(access, ["allowed", "reason"]) && Object.keys(access).length === 2 && typeof access.allowed === "boolean" && typeof access.reason === "string", "Malformed host admission result");
                } catch { access = { allowed: false, reason: "Host admission unavailable or malformed; denied closed." }; }
                if (!access.allowed) {
                  await enqueue({ kind: "note", content: access.reason || "Host admission denied.", details: { basis: "observed", limitations: ["Admission is local host authority, not a model claim or new continuation warrant."] } });
                  return { kind: "cancelled", outputStatus: "unknown", parseStatus: "unknown", diagnostic: "Host admission denied before adapter dispatch." };
                }
              }
              if (controller.signal.aborted) return { kind: "cancelled", outputStatus: "unknown", parseStatus: "unknown", diagnostic: "Cancelled before adapter dispatch." };
              return adapter.execute(Object.freeze({ body: event.request.body, mediaType: event.request.mediaType,
              parameters: event.request.parameters, seed: event.request.seed, tokenContext: event.request.tokenContext,
              sha256: event.request.sha256, executionId }), { emit, signal: controller.signal });
            })
              .then((result) => ({ type: "return", result }), (error) => ({ type: "adapter-error", error }));
            outcome = await Promise.race([executed, stop]);
          }
        }
        outcome ||= await stop;
      } finally {
        accepting = false; clearTimeout(timer); signal?.removeEventListener("abort", onCancel);
        await queue;
      }
      // A failed publication must not be relabeled as model failure, retried, or
      // followed by optimistic capture. Reopen to determine the last durable state.
      if (failure && !(failure instanceof ExecutionValidationError)) throw failure;
      const hasOutput = current().outputObservationIds.length > 0;
      const fallback = (kind, message) => ({ kind, outputStatus: hasOutput ? "partial" : "unknown", parseStatus: kind === "parse-error" ? "failed" : "unknown", diagnostic: message });
      let result;
      if (failure) result = fallback(failure.code === "EXECUTION_CAPACITY" ? "capacity-rejection" : "parse-error", diagnostic(failure));
      else if (outcome.type === "stop") result = fallback(outcome.kind, "Local wait ended; no claim that the provider stopped or produced no other output.");
      else if (outcome.type === "adapter-error") result = fallback(["transport-error", "runtime-error", "capacity-rejection", "parse-error"].includes(outcome.error?.termination) ? outcome.error.termination : "runtime-error", diagnostic(outcome.error));
      else {
        try { result = terminal(outcome.result); }
        catch (error) { result = fallback("parse-error", diagnostic(error)); }
      }
      if ((result.outputStatus === "partial" && !hasOutput) || (hasOutput && result.kind !== "completed" && result.outputStatus !== "partial")) {
        result = fallback("parse-error", "Adapter output status contradicted the durably observed model output.");
      }
      // The admission/parse failure itself is recorded using the reserved slots.
      failure = null;
      await persist({ kind: "termination", content: result.diagnostic || `Observed local termination: ${result.kind}.`,
        details: { kind: result.kind, outputStatus: result.outputStatus, parseStatus: result.parseStatus } });
      return capture ? this.#capture(state, executionId) : { durability: "confirmed-by-store", history: current() };
    });
  }
}
