// Produce a review artifact from actual completed test logs, never estimated counts.
import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
const [targetedPath, fullPath, soakPath] = process.argv.slice(2);
assert.ok(targetedPath && fullPath && soakPath, "Pass targeted, full-regression and soak log paths");
const [targeted, full, soak] = await Promise.all([targetedPath, fullPath, soakPath].map(p => readFile(p, "utf8")));
function summary(log) {
  const result = {};
  for (const name of ["tests", "pass", "fail", "cancelled", "skipped", "todo", "duration_ms"]) {
    const matches = [...log.matchAll(new RegExp(`(?:ℹ|#) ${name} ([0-9.]+)`, "g"))];
    assert.ok(matches.length, `Missing completed summary: ${name}`); result[name] = Number(matches.at(-1)[1]);
  }
  assert.equal(result.fail + result.cancelled + result.skipped + result.todo, 0);
  assert.equal(result.tests, result.pass); return result;
}
const scenarios = [...targeted.matchAll(/^✔ Continuation (\d{2}): (.*?) \([0-9.]+ms\)$/gm)].map(m => ({ number: Number(m[1]), name: m[2], result: "passed" }));
assert.deepEqual(scenarios.map(s => s.number), Array.from({ length: 64 }, (_, i) => i + 1));
const stabilization = soak.split("\n").filter(line => line.startsWith('{"result":')).map(line => JSON.parse(line)).at(-1);
assert.equal(stabilization?.result, "passed"); assert.equal(stabilization.cycles, 32);
const result = { release: "0.20.0-dev", generatedAt: new Date().toISOString(), node: process.version,
  continuation: { command: "npm run test:continuation", ...summary(targeted), numberedScenarios: scenarios },
  regression: { command: "npm test", ...summary(full) },
  stabilization: { command: "npm run test:soak", ...stabilization },
  boundaries: ["Synthetic library tests; no live model calls or automatic execution.", "Authority and resource inputs require a trusted local host; provenance is not authentication.", "Recurrence uses declared ancestry, not semantic equivalence.", "Execution attribution and temporal gaps remain unknown."] };
await writeFile(new URL("../docs/CONTINUATION-v0.20.0-results.json", import.meta.url), `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({ continuation: result.continuation.tests, regression: result.regression.tests, soak: stabilization.cycles, result: "passed" }));
