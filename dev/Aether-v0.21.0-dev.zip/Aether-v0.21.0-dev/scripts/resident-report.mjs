// Review evidence must come from actual completed runs, not planned test counts.
import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
const paths = process.argv.slice(2);
assert.equal(paths.length, 3, "Pass resident, full-regression and soak logs");
const [resident, full, soak] = await Promise.all(paths.map(p => readFile(p, "utf8")));
function summary(log) {
  const result = {};
  for (const name of ["tests", "pass", "fail", "cancelled", "skipped", "todo", "duration_ms"]) {
    const matches = [...log.matchAll(new RegExp(`(?:ℹ|#) ${name} ([0-9.]+)`, "g"))];
    assert.ok(matches.length, `Missing completed summary: ${name}`); result[name] = Number(matches.at(-1)[1]);
  }
  assert.equal(result.fail + result.cancelled + result.skipped + result.todo, 0); assert.equal(result.tests, result.pass); return result;
}
const scenarios = [...resident.matchAll(/^✔ Resident (\d{2}): (.*?) \([0-9.]+ms\)$/gm)].map(m => ({ number: Number(m[1]), name: m[2], result: "passed" }));
assert.deepEqual(scenarios.map(s => s.number), Array.from({ length: 34 }, (_, i) => i + 1));
const stabilization = soak.split("\n").filter(line => line.startsWith('{"result":')).map(line => JSON.parse(line)).at(-1);
assert.equal(stabilization?.result, "passed"); assert.equal(stabilization.cycles, 32);
const result = { release: "0.21.0-dev", generatedAt: new Date().toISOString(), node: process.version,
  resident: { command: "npm run test:resident", ...summary(resident), numberedScenarios: scenarios },
  regression: { command: "npm test", ...summary(full) }, stabilization: { command: "npm run test:soak", ...stabilization },
  limitations: ["Controlled deterministic mocks, not a production resident or cognitive evaluation.", "Metadata replacement tests do not benchmark real binary/ternary models.",
    "Trusted synchronous host policy and cooperative in-process adapters, not an OS sandbox.", "Semantic fidelity, truth and analogy validity are not certified.", "No automatic phases, live-chat changes, model downloads or private resident memory."] };
await writeFile(new URL("../docs/RESIDENT-v0.21.0-results.json", import.meta.url), `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({ resident: result.resident.tests, regression: result.regression.tests, soak: stabilization.cycles, result: "passed" }));
