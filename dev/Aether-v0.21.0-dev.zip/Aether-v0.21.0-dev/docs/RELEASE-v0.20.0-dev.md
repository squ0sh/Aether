# Aether v0.20.0-dev — Continuation & Inquiry v0.1

Review checkpoint based on the verified v0.19.2-dev source archive
(SHA-256 `bd6948382c0abfef16e4c097983127ac2a5fda26f89c7dd61a83b6e1e4a62786`).
Existing stable app and live runtime behavior remain unchanged.

## What changed

- One immutable `ContinuationDecision` concept, implemented as an existing Field
  observation. Nested triggers, directions and reconsideration descriptions do
  not create persistent ontology types.
- Deterministic versioned evaluator distinguishes continue, wait, deferred,
  forbidden, blocked and unresolved. Explicit human intent stays human intent.
- Supporting/opposing reasons, alternatives, human/system authority, capability
  and resource snapshots, prior decisions/executions and limitations are retained.
- Recurrence uses selected-history ancestry and relevant new attributed material;
  model urgency, self-preservation, proposals and repeated failure do not compel
  computation or override shutdown.
- Existing audit classification and mixed-role guards recognize continuation.
  No redesign of capture, RetrievalEvent, AssemblyEvent or ExecutionEvent.
- Dedicated validation reconstructs each decision and checks immutable parent,
  reference, role and provenance boundaries. Existing private Field storage and
  conversation ownership remain the persistence mechanism.

## Review results

- `npm run check`: passed, including the new module's syntax check.
- `npm run test:continuation`: **77 passed**, no failures/skips. All **64 numbered
  handoff scenarios** plus 13 additional boundary tests. Includes physical
  subprocess exit before execution, fresh-process recovery of WAIT/CONTINUE,
  ownership checks and 32 growing-history save/reopen cycles.
- `npm test`: **475 passed**, no failures/skips (398 existing checks plus 77 new;
  the existing count includes four fixture-module discovery entries).
- The execution stabilization soak is rerun separately with 32 cycles. Exact
  completion, timings, crash checkpoints and measurements are in the generated
  [machine-readable results](CONTINUATION-v0.20.0-results.json).

`scripts/continuation-report.mjs` generates that report from completed logs and
refuses missing summaries, failures, skips or missing numbered scenarios. Tests
use synthetic records/mock runtimes, not live-model cognition or truth judgments.

## Deliberate limits

This is a **library checkpoint**. No resident, scheduler, model-generated goals,
automatic execution, networking, live chat injection, universal importance score,
or policy self-modification is enabled. Existing chat and installed runtime/model
handling are unchanged.

Authority/resources/policy are trusted-host inputs, not authenticated by this
module. Future execution must recheck current permission and resources; a recorded
CONTINUE cannot serve as a reusable authorization token. Recurrence is conservative
declared-ancestry matching, not semantic equivalence. A reason classified as
worthwhile is an attributed policy result, not evidence that it is correct.

No decision is invented during inactivity or restart. Execution attribution is
unknown until a future explicit integration records a relationship; co-presence
of an ExecutionEvent is not enough. WAIT leaves questions open and can remain safe
indefinitely. Reconsideration descriptions never schedule work.

See [the full contract](CONTINUATION-v0.1.md) for exact precedence, mixed-outcome
handling, policy configuration, persistence requirements and trust limitations.
Review this boundary with Cal before deciding on a next integration checkpoint.

## Package

`Aether-v0.20.0-dev.zip` contains source, public assets, documentation, tests,
scripts, package metadata and ignore rules. It excludes models, runtimes, private
Field/conversation data, dependencies, logs, Git history and earlier archives.
This checkpoint is prepared for review; creating it does not commit or push it.
