# Resident Contract harness v0.1

This is the v0.21.0-dev **controlled-mock library checkpoint**, not a production
resident, background agent or live-chat feature. It implements a host-controlled
finite path:

Field → Continuation → Retrieval → Assembly → Execution → Capture → Field

The resident receives a bounded perspective and produces attributed proposals.
It owns none of these boundaries. Existing application/adapters remain unchanged.
No weights, model downloads, training, resident process, tools or scheduler are
installed. No biological, electromagnetic or quantum mechanism is asserted.

## Smallest persistence design

**Zero new persistent domain concepts or stores.** Before adding any, ask what
information existing records cannot recover. For this checkpoint there is none:

| Information | Existing representation |
| --- | --- |
| Why a phase was considered; WAIT or another outcome | ContinuationDecision |
| Historical perspective and exclusions | RetrievalEvent and AssemblyEvent |
| Participant/model/runtime/weights/representation/quantization labels; phase; selected decision/direction; budget source; recorded admission | Nested `ExecutionEvent.request.parameters.resident` v0.1 descriptor |
| Prepared call reservation | That same ExecutionEvent, counted once against its budget source |
| Output, cancellation, uncertainty, capture linkage | Existing execution observations and raw capture |
| Questions, alternatives, analogies and compressions | Existing question/hypothesis/inference nodes with model provenance and capture/source ancestry |
| REST/inactivity | Explicit non-CONTINUE decision where evaluated; absence otherwise remains unknown |

The nested descriptor is a versioned binding format, not a ResidentEvent, pulse
database, private memory, Goal, Trigger or mutable identity registry. Identity is
configuration retained per attempt. It has no priority or authority. Replacement
requires a new target-specific assembly, not historical rewriting.

## APIs

`resident-response.js` exports `validateResidentIdentity`,
`validateResidentResponse`, `MOCK_RESIDENT_IDENTITY`, and `createMockResident`.

`resident.js` exports `ResidentHarness`, `validateResidentField`, and
`regroundResidentCompression`.

Construct `ResidentHarness` with the same `fieldStore`, `coordinator`, `fieldId`,
`conversationId` and optional clock as `DurableExecutionRunner`, plus a trusted
**synchronous** `access({snapshot, headStateId, identity, phase})` function.
Conversation scope, private persistence, single integrated head and ownership are
the existing Field requirements. No store path is handed to the resident adapter.

The host access function returns:

```js
{
  authority: {
    status: "granted",          // or denied / unknown
    sourceIds: ["human-grant"], // existing human/system records
    scopeIds: ["direction"],
    restrictions: []            // shutdown / no-inference / no-external-calls
  },
  resources: {
    callLimit: 3,               // total prepared attempts for this budget; null = unknown
    budgetSourceId: "budget",  // existing human/system record
    availableCapabilities: ["mock-resident"],
    unavailableCapabilities: []
  }
}
```

The host must inspect the supplied target identity when determining current
runtime/capability availability. These are **trusted-host inputs**, not a model's
claim to resources and not cryptographically authenticated policy. The provider
must be finite, synchronous and must not perform inference. Throws, promises or
malformed admission results fail closed before adapter dispatch.

`prepare({id, phase, identity, inquiry, query})` records the continuation decision
first. `phase` is exactly expand, contract or integrate. `inquiry` contains policy,
trigger, directions, materialChangeIds and reconsiderationConditions from v0.20;
the harness supplies the current Field state, authority and resources itself.
Directions require exactly one local call; external-call directions are rejected.
Non-CONTINUE returns an explicit outcome with no ExecutionEvent. A selected
direction creates a fresh retrieval, target-specific assembly and prepared attempt.
Duplicate request IDs are rejected; inspect/recover rather than replay.

`execute(executionId, {adapter, signal})` rechecks current permission, scope,
shutdown, budget and capability under the existing conversation ownership lock,
after durable submission intent and immediately before adapter invocation. Denial
records a host note and cancelled local attempt, not model failure or submission.
The old CONTINUE decision is untouched. A prepared resident attempt cannot enter
the generic runner without a trusted admission provider.

`runPhase({request, adapter, signal})` is the convenience composition of those two
operations. It does **not** call itself, schedule another phase or integrate model
proposals automatically. Completing EXPAND does not authorize CONTRACT. The host
must supply another warranted consideration for another call. Mere resident output,
repetition or its ancestry cannot supply that warrant under the continuation policy.

`inspect(executionId)` is read-only. `recover(executionId)` uses existing durable
capture recovery, never resubmitting. Missing runtime instances, model files or
hidden state are unnecessary for these operations. Five years passing creates no
remembered experiences or invented decisions. Unresolved histories remain usable.

## Reservations and boundedness

Every prepared resident ExecutionEvent reserves one call against a human/system
budget source. Counting is durable and includes all stored branches, not just the
currently selected view. Changing resident/model/runtime does not reset that count.
The host may explicitly revise the limit or supply a new attributed budget; model
text cannot. Interrupted, cancelled and denied prepared attempts remain charged.
There is no automatic refund/retry after uncertain execution. This conservative
policy avoids duplicate spending; production resource accounting is future work.

Per phase: 32 KiB assembly artifact, 64 KiB complete request envelope, 16 KiB durable
output, 32 execution observations and a five-second local runtime wait. Existing
retrieval candidate/selection limits also apply. These are protocol bounds, **not**
token counts, CPU guarantees, energy measurements or actual-model efficiency claims.
The finite trusted-host preparation/validation work is not covered by the runtime
timeout; large histories can still be expensive to validate.

## Proposal admission and append-only integration

Resident responses use a strict bounded JSON format containing contractVersion,
phase, alternatives, questions, analogies, compression (or null), and limitations.
Each proposal has text and sourceIds restricted to representations actually
included in its assembly. It cannot name unseen Field material as its perspective.

Analogies additionally require similarity, referenceFrame, scale, context,
knownMechanisms (which may explicitly be unknown), differences and failureBoundaries.
Compression additionally requires preserved, omitted, recoverableSourceIds,
unrecoverable and uncertainty. Recovery IDs must be included source IDs; they do
not make the summary equivalent to its sources. Limits and unknowns must be explicit.

`integrate(executionId, {signal})` is a separate explicit host operation, not another
inference. It requires completed, captured output, validates its shape and appends
proposals in one atomic Field transaction. The original captures, alternatives,
minority branches and all earlier audits are unchanged. New records retain model
provenance, capture and source ancestry, open status and unknown confidence. There
are no truth, consensus, support-strength, or semantic-equivalence promotions.
Unsupported or malformed output remains raw capture, not silently repaired output.
The resident's `integrate` cognitive phase and host mechanical integration are
distinct: the former needs a gated call; the latter only admits already-captured
proposals without executing anything.

Stable proposal IDs make retries idempotent after lost acknowledgement. A process
exit before publication leaves the previous Field intact; an acknowledged or
unacknowledged successful publication remains readable. Orphan locks are **not**
stolen automatically. Review ownership before recovery. Cancellation before the
integration transaction prevents it; cancellation during an atomic save cannot
promise rollback—reopen and inspect the published state.

`regroundResidentCompression(snapshot, stateId, nodeId)` verifies captured ancestry
and returns surviving original records plus explicit missing IDs and unknown
semantic fidelity. It is a read-only host inspection tool, not an unbounded memory
API exposed to the resident. To show recovered sources to a resident, run them
through ordinary retrieval and bounded assembly. Re-grounding is not inverse
compression: never-preserved information stays unavailable. If comparison exposes
an error, preserve that disagreement rather than rewriting the original summary.

## What this can and cannot enforce

The environment can reject control fields, deny execution, bound output, preserve
sources, retain disagreements, constrain source references, and prevent raw model
text from changing host policy. It can require explicit limitation fields.

It **cannot prove** useful curiosity, truthful humility, faithful compression,
valid analogy, independence, or semantic equivalence. A model can put false claims
inside valid text fields, including an unjustified certainty claim beside an
uncertainty disclaimer. Those claims remain attributed data. They do not gain
control authority or permission to erase history. The tests demonstrate that
distinction; they do not certify a model's cognition or the truth of its words.

The JavaScript adapter and host policy callback are trusted code, not sandboxed
plugins. A malicious adapter with ambient process privileges can bypass any
in-process library, and blocking synchronous code cannot be interrupted by an
AbortSignal. The deterministic mock is cooperative; local timeout/cancellation
closes capture and rejects late emissions, but does not prove an external provider
stopped. Production untrusted runtimes require a separately reviewed process/tool
isolation boundary. Do not use this harness as an OS security boundary.

Binary/ternary and quantization replacement tests exercise identity metadata only;
they do not run real low-bit networks or establish hardware advantages. No model
is privileged or permanent. The Field and all existing services work with the
resident removed. A specialist request is a proposal, not a tool command: host
continuation, target-specific assembly and execution must still intervene.

## Verification

`npm run test:resident` covers the contract's 34 adversarial cases in order plus
admission, ownership, reservations, crash recovery, loss of acknowledgement,
replacement, deletion, malformed data and runtime-regression boundaries.
`npm test` checks all prior layers too. The execution soak remains separate.
See release notes and the generated results report for actual run counts.
