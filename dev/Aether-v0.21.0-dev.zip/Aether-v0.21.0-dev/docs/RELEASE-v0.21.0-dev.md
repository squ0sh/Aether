# Aether v0.21.0-dev — Resident Contract harness v0.1

Built from the verified v0.20.0-dev ZIP, SHA-256
`0f1f37d21f9ae12ee5e708cbbfbc8ecce3cb1a3510b6e0ead8ad3594e66192e0`.
The original [Cal/user handoff](RESIDENT-CONTRACT-v0.1-handoff.txt) is included
unchanged alongside the [implementation contract](RESIDENT-v0.1.md).

## Delivered

- A finite, deterministic mock resident and replaceable per-attempt identity,
  model, runtime, representation, weights and quantization descriptors.
- A host-controlled bridge from Continuation through retrieval and target-specific
  assembly into the existing execution/capture path. WAIT creates no attempt.
- Fresh synchronous host admission immediately before dispatch, under existing
  conversation ownership. Shutdown/revocation, scope and capability changes deny
  dispatch without rewriting the earlier decision.
- Durable conservative call reservations derived from prepared ExecutionEvents.
  Restart, replacement, cancellation and uncertain outcomes do not reset them.
- Bounded expansion/contraction/integration mock calls, each separately gated;
  no automatic next phase. REST/inactivity can persist indefinitely.
- Strict proposal shape/source checks, explicit analogy and compression limits,
  and explicit append-only integration into ordinary model-attributed Field nodes.
- Idempotent integration recovery, retained minority/disagreement sources and
  read-only re-grounding against preserved ancestry, never inverse compression.

No new persistent domain concept, resident database, privileged memory store,
scheduler or background agent. The existing `DurableExecutionRunner` gains an
optional trusted admission callback, required for resident-tagged attempts. Other
execution paths retain their behavior; all existing regression tests still pass.
The core Field, Continuation, retrieval, assembly and capture schemas are unchanged.

## Verified results

- `npm run check`: passed, including both new production modules.
- `npm run test:resident`: **52 passed**, zero failed/skipped. All **34 numbered
  contract adversaries**, plus 18 admission, persistence, deletion, provenance,
  cancellation, reservation and output-bound checks.
- `npm test`: **527 passed**, zero failed/skipped (475 previous checks plus 52
  resident checks; includes the four existing fixture-module discovery entries).
- The separate 32-cycle execution soak is rerun. Exact completed results, timings,
  process-exit checkpoints and measurements are in the generated
  [results report](RESIDENT-v0.21.0-results.json).

Scenario 30 uses an actual child-process exit during host integration before
publication. The parent verifies unchanged durable state, refuses the orphan lock,
then—only after observing that exact child's exit—clears that test lock and retries
integration without another execution. A separate lost-acknowledgement test covers
successful publication before acknowledgement. Existing execution/store crash
tests retain their write/rename and partial-output boundary coverage.

The report generator consumes completed logs and rejects absent scenarios,
failures or skipped tests. It does not substitute planned counts for actual runs.

## Important limitations for review

This proves a **controlled mock interface**, not useful resident cognition or a
production security sandbox. Trusted adapter/host code runs in-process; arbitrary
malicious JavaScript and synchronous event-loop blocking require separate runtime
isolation. Cancellation closes the local boundary but does not prove a remote
provider stopped. Host admission relies on honest, appropriately scoped authority
and resource snapshots, not cryptographic authentication.

Shape validation cannot certify semantic fidelity, honest uncertainty, independent
evidence, useful curiosity or analogy validity. False claims may remain in valid
text fields. They stay attributed proposals and cannot erase sources, grant control
authority or silently become verified truth. Re-grounding can expose a compression
error while preserving the original faulty summary and the original sources.

Identity replacement tests use mock labels. No actual binary/ternary model is run
or benchmarked. No production model is selected/downloaded, and there are no changes
to live chat, llama.cpp/Ollama, installed models, runtime selection or user data.
Optional wake-pressure accumulation is deliberately absent: existing reasons and
ancestry preserve what is needed for this checkpoint without a new accumulator.

The original contract remains the direction; these notes explicitly delimit what
the first implementation demonstrates. Review with Cal before connecting a real
resident or introducing broader runtime privileges.

## Package

`Aether-v0.21.0-dev.zip` is source-only: source, public assets, tests, scripts,
documentation, package metadata and ignore rules. It excludes model/runtime files,
private Field/conversation data, dependencies, Git history, logs and earlier ZIPs.
This checkpoint is for review, not an automatic commit or push.
