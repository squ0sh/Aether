# Continuation & Inquiry v0.1

v0.20.0-dev is a finite, deterministic **library checkpoint**, not a resident,
scheduler, planner or live-chat integration. It adds one persistent concept:
`ContinuationDecision`, an immutable existing Field observation with the
`aether:continuation` extension. Triggers, directions, reasons, resource snapshots
and reconsideration conditions are nested descriptions, not new Field types.

## API and trust boundary

`src/core/continuation.js` exports `buildContinuationDecision`,
`addContinuationDecision`, `validateContinuationField`, `readContinuationHistory`,
`DEFAULT_CONTINUATION_POLICY` and version/extension constants.

The builder takes a validated Field snapshot and an explicit consideration:

- `fieldStateId`: exact inspected history, including selected ancestors.
- `policy`: retained ID, version, finite mode (`evaluate` or `review-only`) and
  optional ordered `preferredDirectionIds`. No mutable registry or text parsing.
- `trigger`: attributed human request, proposal, manual review, Field change or
  scheduled-wake description. A trigger never grants permission or causes a call.
- `directions`: at most 32 existing ordinary node references, objective references,
  attributed supporting/opposing reasons, required capabilities, external-access
  requirement and a finite call bound (0–32). No numeric importance/truth score.
- `authority`: granted/denied/unknown, human/system source references, explicit
  direction scope, restrictions (`shutdown`, `no-inference`, `no-external-calls`).
- `resources`: known available/unavailable capabilities, remaining calls or null,
  and source references. Omitted capabilities are unknown, not available.
- `materialChangeIds`: explicit source references proposed as changed conditions.
- `reconsiderationConditions`: human-readable descriptions only; never executable
  expressions, jobs, wake registrations or commands.

These are **trusted local host inputs**, not authenticated claims. A caller that
can forge system/human provenance can lie. Never feed model-generated JSON into
this API as authority, resource or policy configuration. Direct model/tool grants
are rejected; model text, urgency, self-preservation and resident-like proposals
are not parsed for instructions and cannot change policy. Decision authors must
be human/system. A historical grant is only an audit snapshot: future execution
must independently recheck current authority, scope, resources and shutdown state.

Reasons retain source IDs and original Field records. `human-request` reasons
must have human provenance. Model-only proposals cannot create a warrant. The
v1 conservative warrant policy accepts attributed human requests, discriminating
evidence, dependency review, capability change or observed reconsideration, when
at least one source's declared lineage contains neither model nor audit records.
This is **not** verification that the reason is true, useful, independent or that
the condition really occurred. The host must make and attribute that assessment.
Model-derived useful work needs an independent human/system review; the library
does not pretend to establish epistemic value automatically.

## Outcomes and precedence

Every direction retains its reasons, `worthwhile` (under this limited policy,
not objective value), recurrence assessment and resource/authority blockers.
All blockers are recorded even when another rule decides the outcome.

| Outcome | Meaning in this policy |
| --- | --- |
| `forbidden` | Explicit denial, shutdown, or applicable restriction. |
| `wait` | No present warrant, currently unanswerable, or recurrence without relevant material change. Successful inactivity; no question resolution or ExecutionEvent required. |
| `unresolved` | Warrant exists but authority/scope, capability/budget or a counterargument remains unresolved. |
| `blocked` | Warrant exists and permission is known, but a required resource is known unavailable. |
| `deferred` | Eligible direction intentionally unselected, review-only policy, or multiple eligible alternatives without explicit preference. |
| `continue` | One finite direction selected under the recorded policy and snapshots. Not execution or lasting authorization. |

Per-direction precedence is the table order, except selection determines the last
two states. Overall: shutdown is forbidden; a selected direction is continue;
eligible but unselected alternatives are deferred; unanimous direction outcomes
are retained; mixed noneligible outcomes are unresolved. Empty consideration is
WAIT unless shutdown is explicit. Per-direction detail prevents this summary
from erasing different reasons or restrictions.

One eligible direction may be selected. Multiple eligible directions require an
explicit policy preference; otherwise they remain incomparable and deferred.
Dependency C can reference human objective A and be explicitly preferred over A
or B without asserting C is universally more important. Historical preferences,
including biased ones, remain inspectable. Policy labels may be host-defined;
the complete configuration and schema/vocabulary version preserve exact v1
semantics, not a promise to execute unknown future evaluators.

Contradiction, unresolved questions, surprise, urgency and previous failure alone
are not warrants. Surprise can retain a reconsideration description to examine
expectations, frame, assumptions and alternatives; no ontology expansion occurs.
An explicit counterargument holds a warranted direction unresolved.

## Recurrence and ancestry

The builder automatically includes **all** prior continuation and execution audit
IDs in the selected ancestry; the caller cannot omit them. Related decisions
share direction/objective IDs or their declared source ancestry. This conservatively
recognizes A→B→C→A when those links are declared. It is not a semantic-equivalence
oracle: unrelated IDs with undeclared relationships can evade semantic recurrence.

A related direction needs a material-change source absent from every related
decision's inspected history, linked to a warrant reason, and with no model/audit
record in its declared ancestry. Repetition, old evidence, self-generated echoes,
repeated failure and decision audits cannot satisfy that test. This conservative
union rule may over-suppress work; record a genuinely new attributed assessment,
do not invent independent evidence. Reconsideration produces D2; D1 remains exact.

## Durability, evidence and absence

Use the existing private `LocalFieldStore` to save an appended snapshot. For a
conversation-scoped Field use the existing `LinkedDeletionCoordinator` ownership
transaction, just as other Field changes do. This module adds no separate store,
locking system, HTTP route or automatic persistence. Readers must call
`validateContinuationField`: generic storage deliberately preserves opaque future
extensions and is not a substitute for dedicated semantic validation.

Validation reconstructs decisions, checks exact references and direct parent
binding, rejects mixed audit/capture roles and revisions, and returns frozen data.
Audit classification excludes even unknown/malformed continuation markers from
ordinary retrieval/structural evidence. Earlier capture, retrieval, assembly and
execution records are untouched. New audit records do not multiply world evidence.

`readContinuationHistory` reports execution attribution and temporal gaps as
unknown. No existing ExecutionEvent schema is changed. Co-presence of a later
execution is not evidence that this decision caused it; future integration must
record an explicit relationship and recheck permission. CONTINUE followed by a
crash without execution remains CONTINUE-with-execution-unknown. No decision plus
no execution is ambiguous, not WAIT. Restart adds no invented decisions. No
timer, resident, background task or model invocation is needed to remain inactive
indefinitely, and shutdown never depends on questions being resolved.

## Verification

`npm run test:continuation` registers 64 named handoff scenarios plus extra
schema, tamper, ancestry, ordering and revision tests. The tests use synthetic
attributed records, not live models or judgments of cognition. Scenarios 40, 50
and 51 run fresh child processes; 40 explicitly exits after durable CONTINUE and
before any execution. Existing full regression and stabilization suites remain
required. These are correctness checks, not production performance guarantees.
