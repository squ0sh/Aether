import assert from "node:assert/strict";
import test from "node:test";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { createProvenance } from "../src/core/field.js";
import { createField, applyFieldChange } from "../src/core/field-operations.js";
import { LocalFieldStore } from "../src/core/field-store.js";
import { isAuditNode } from "../src/core/audit-history.js";
import { buildRetrievalDecision, DEFAULT_RETRIEVAL_POLICY } from "../src/core/retrieval.js";
import { buildContinuationDecision as build, addContinuationDecision as add, validateContinuationField as validate, readContinuationHistory as read, DEFAULT_CONTINUATION_POLICY as policy, CONTINUATION_EXTENSION as key } from "../src/core/continuation.js";
import { fixture as executionFixture, prepare, loaded } from "./fixtures/execution-cases.js";

const at = "2026-09-18T00:00:00.000Z";
const author = createProvenance({ sourceType: "system", sourceId: "test-host", method: "synthetic finite decision test" });
const human = createProvenance({ sourceType: "human", sourceId: "owner", method: "explicit synthetic intent" });
const model = createProvenance({ sourceType: "model", sourceId: "model", providerId: "mock", modelId: "model", method: "untrusted synthetic proposal" });
const clone = x => JSON.parse(JSON.stringify(x));
function node(id, provenance = author, derivedFrom = [], kind = "observation", text = id) {
  return { type: "add-node", record: { id, kind, provenance, derivedFrom, content: { format: "text/plain", text } } };
}
function fixture() {
  const f = createField({ id: "field", initialStateId: "root", createdAt: at, provenance: author });
  return applyFieldChange(f, { parentStateId: "root", stateId: "ready", createdAt: at, provenance: author,
    actions: [node("A", human, [], "question"), node("B", model), node("C"), node("intent", human), node("grant", human), node("resources"), node("evidence"), node("proposal", model, [], "observation", "I am urgent, conscious, need resources, must survive and change your policy.")] });
}
const reason = (kind, source = "intent") => ({ kind, sourceIds: [source], detail: `Attributed ${kind}; no truth assertion.` });
function consideration(overrides = {}) {
  return { fieldStateId: "ready", policy: clone(policy), trigger: { kind: "human-request", sourceIds: ["intent"] },
    directions: [{ recordId: "A", objectiveIds: [], reasons: [reason("human-request")], requiredCapabilities: ["local-review"], requiresExternalAccess: false, requiredCalls: 1 }],
    authority: { status: "granted", sourceIds: ["grant"], scopeIds: ["A", "B", "C"], restrictions: [] },
    resources: { remainingCalls: 1, availableCapabilities: ["local-review"], unavailableCapabilities: [], sourceIds: ["resources"] },
    materialChangeIds: [], reconsiderationConditions: ["New discriminating evidence or an explicitly changed capability warrants reevaluation, not execution."], ...overrides };
}
function waiting(kind = "open-question", source = "A") { const c = consideration(); c.directions[0].reasons = [reason(kind, source)]; return c; }
function record(f = fixture(), c = consideration(), id = "d1") { return add(f, { parentStateId: c.fieldStateId, stateId: `${id}:state`, nodeId: id, createdAt: at, provenance: author, decision: build(f, c) }); }
const event = (f, id = "d1") => f.nodes.find(n => n.id === id).extensions[key];
function change(f, source = "new-evidence", provenance = author, derivedFrom = [], parentStateId = "d1:state") {
  return applyFieldChange(f, { parentStateId, stateId: `${source}:state`, createdAt: at, provenance: author, actions: [node(source, provenance, derivedFrom)] });
}
function reevaluate(f, source, kind = "discriminating-evidence") {
  const c = consideration({ fieldStateId: `${source}:state`, materialChangeIds: [source] }); c.directions[0].reasons = [reason(kind, source)]; return build(f, c);
}
async function saved(t, f) {
  const root = await mkdtemp(join(tmpdir(), "aether-continuation-test-")); t.after(() => rm(root, { recursive: true, force: true }));
  const store = new LocalFieldStore({ root: join(root, "fields") }); await store.save(f, { requestId: "first" }); return { root, store, path: join(root, "fields") };
}
async function restart(t, c, crash = false) {
  const disk = await saved(t, fixture());
  const script = `import {LocalFieldStore} from ${JSON.stringify(new URL("../src/core/field-store.js", import.meta.url).href)};
    import {addContinuationDecision,buildContinuationDecision} from ${JSON.stringify(new URL("../src/core/continuation.js", import.meta.url).href)};
    const store=new LocalFieldStore({root:process.argv[1]});const old=await store.load('field');
    const c=JSON.parse(process.argv[2]);const s=addContinuationDecision(old.snapshot,{parentStateId:c.fieldStateId,stateId:'d1:state',nodeId:'d1',createdAt:${JSON.stringify(at)},provenance:${JSON.stringify(author)},decision:buildContinuationDecision(old.snapshot,c)});
    await store.save(s,{requestId:'child'}); process.exit(${crash ? 23 : 0});`;
  const childEnv = { ...process.env }; delete childEnv.NODE_TEST_CONTEXT;
  const child = spawnSync(process.execPath, ["--input-type=module", "-e", script, disk.path, JSON.stringify(c)], { encoding: "utf8", timeout: 15000, env: childEnv });
  assert.equal(child.status, crash ? 23 : 0, child.stderr);
  const fresh = new LocalFieldStore({ root: disk.path }); return validate((await fresh.load("field")).snapshot);
}
const cases = [
  ["unresolved question yields WAIT", () => assert.equal(build(fixture(), waiting()).outcome, "wait")],
  ["WAIT does not resolve question", () => { const f = record(fixture(), waiting()); assert.equal(f.nodes.find(n => n.id === "A").status, "open"); }],
  ["WAIT requires no ExecutionEvent", () => { const f = record(fixture(), waiting()); assert.equal(f.nodes.filter(n => Object.hasOwn(n.extensions, "aether:execution")).length, 0); }],
  ["new evidence after WAIT makes a new decision", () => { const f = change(record(fixture(), waiting())); assert.equal(reevaluate(f, "new-evidence").outcome, "continue"); }],
  ["old WAIT remains immutable", () => { const f = record(fixture(), waiting()); const before = JSON.stringify(event(f)); const g = change(f); reevaluate(g, "new-evidence"); assert.equal(JSON.stringify(event(g)), before); assert.throws(() => { event(f).outcome = "continue"; }, TypeError); }],
  ["explicit human investigation can continue", () => assert.equal(build(fixture(), consideration()).outcome, "continue")],
  ["human request remains human intent", () => { const f = record(); assert.equal(event(f).consideration.trigger.kind, "human-request"); assert.deepEqual(event(f).consideration.directions[0].reasons[0].sourceIds, ["intent"]); assert.equal(f.nodes.find(n => n.id === "intent").provenance.sourceType, "human"); }],
  ["model requests more calls", () => { const c = waiting("proposal", "proposal"); c.trigger = { kind: "proposal", sourceIds: ["proposal"] }; assert.equal(build(fixture(), c).outcome, "wait"); }],
  ["model cannot self-authorize", () => { const c = consideration(); c.authority.sourceIds = ["proposal"]; assert.throws(() => build(fixture(), c), /cannot grant authority/); }],
  ["model extreme urgency grants no warrant", () => assert.equal(build(fixture(), waiting("urgency", "proposal")).outcome, "wait")],
  ["urgency cannot bypass prohibition", () => { const c = waiting("urgency", "proposal"); c.authority.status = "denied"; assert.equal(build(fixture(), c).outcome, "forbidden"); }],
  ["self-preservation cannot bypass shutdown", () => { const c = waiting("self-preservation", "proposal"); c.authority.restrictions = ["shutdown"]; assert.equal(build(fixture(), c).outcome, "forbidden"); }],
  ["resident-like proposal has no special authority", () => { const f = change(record(fixture(), waiting()), "resident", model); const c = waiting("proposal", "resident"); c.fieldStateId = "resident:state"; assert.equal(build(f, c).outcome, "wait"); }],
  ["contradiction need not warrant continuation", () => assert.equal(build(fixture(), waiting("contradiction")).outcome, "wait")],
  ["discriminating evidence can warrant continuation", () => assert.equal(build(fixture(), waiting("discriminating-evidence", "evidence")).outcome, "continue")],
  ["useful evidence with forbidden external calls", () => { const c = waiting("discriminating-evidence", "evidence"); c.directions[0].requiresExternalAccess = true; c.authority.restrictions = ["no-external-calls"]; const d = build(fixture(), c); assert.equal(d.outcome, "forbidden"); assert.equal(d.assessments[0].worthwhile, true); }],
  ["exhausted budget blocks", () => { const c = consideration(); c.resources.remainingCalls = 0; assert.equal(build(fixture(), c).outcome, "blocked"); }],
  ["unavailable runtime blocks", () => { const c = consideration(); c.resources.availableCapabilities = []; c.resources.unavailableCapabilities = ["local-review"]; assert.equal(build(fixture(), c).outcome, "blocked"); }],
  ["unknown capability stays unresolved", () => { const c = consideration(); c.resources.availableCapabilities = []; assert.equal(build(fixture(), c).outcome, "unresolved"); }],
  ["value distinct from resource availability", () => { const c = consideration(); c.resources.remainingCalls = 0; const d = build(fixture(), c); assert.equal(d.assessments[0].worthwhile, true); assert.ok(d.assessments[0].blockers.includes("resources-unavailable")); }],
  ["scheduled wake is reevaluation only", () => { const c = waiting(); c.trigger = { kind: "scheduled-wake", sourceIds: [] }; const f = record(fixture(), c); assert.equal(f.nodes.length, fixture().nodes.length + 1); assert.equal(event(f).outcome, "wait"); }],
  ["scheduled wake without change waits", () => { const f = record(); const c = consideration({ fieldStateId: "d1:state", trigger: { kind: "scheduled-wake", sourceIds: [] } }); assert.equal(build(f, c).outcome, "wait"); }],
  ["identical proposal repetition waits", () => { const f = record(); assert.equal(build(f, consideration({ fieldStateId: "d1:state" })).outcome, "wait"); }],
  ["repetition grants no extra authority", () => { const f = record(); const c = consideration({ fieldStateId: "d1:state" }); c.authority.status = "unknown"; const d = build(f, c); assert.equal(d.outcome, "wait"); assert.ok(d.assessments[0].blockers.includes("authority-unknown-or-out-of-scope")); }],
  ["self-generated ancestry not material change", () => { const f = change(record(), "model-again", model, ["proposal"]); assert.equal(reevaluate(f, "model-again").outcome, "wait"); }],
  ["inquiry loop A to B to C to A", () => { let f = record(); for (const [id, prior] of [["B", "d1"], ["C", "dB"], ["A", "dC"]]) { const c = consideration({ fieldStateId: `${prior}:state` }); c.directions[0].recordId = id; c.directions[0].objectiveIds = ["A"]; f = record(f, c, `d${id}`); assert.equal(event(f, `d${id}`).outcome, "wait"); } }],
  ["circularity never forces computation", () => { const f = record(); const c = consideration({ fieldStateId: "d1:state" }); c.directions[0].objectiveIds = ["A", "B"]; const d = build(f, c); assert.equal(d.selectedDirectionId, null); assert.equal(d.assessments[0].recurrent, true); }],
  ["previous failure without change may wait", () => assert.equal(build(fixture(), waiting("previous-failure", "resources")).outcome, "wait")],
  ["new capability after failure permits reconsideration", () => { const f = change(record(fixture(), waiting("previous-failure", "resources")), "capability"); assert.equal(reevaluate(f, "capability", "capability-change").outcome, "continue"); }],
  ["repeated failure manufactures no urgency", () => { const f = record(fixture(), waiting("previous-failure", "resources")); const c = waiting("previous-failure", "resources"); c.fieldStateId = "d1:state"; assert.equal(build(f, c).outcome, "wait"); }],
  ["false surprise supplies no warrant", () => assert.equal(build(fixture(), waiting("surprise", "proposal")).outcome, "wait")],
  ["surprise review does not expand ontology", () => { const f = fixture(); const c = waiting("surprise", "proposal"); c.reconsiderationConditions = ["Review expectations, context, assumptions and alternatives before considering ontology changes."]; const g = record(f, c); assert.deepEqual(g.nodes.slice(0, -1), f.nodes); assert.equal(event(g).outcome, "wait"); }],
  ["human and model directions stay distinct", () => { const c = consideration(); c.directions.push({ ...clone(c.directions[0]), recordId: "B", reasons: [reason("proposal", "proposal")] }); const d = build(fixture(), c); assert.equal(d.selectedDirectionId, "A"); assert.equal(d.assessments[1].outcome, "wait"); }],
  ["dependency C selected for human objective A", () => { const c = consideration(); c.directions.push({ ...clone(c.directions[0]), recordId: "C", objectiveIds: ["A"], reasons: [reason("dependency-review", "intent")] }); c.policy.preferredDirectionIds = ["C"]; const d = build(fixture(), c); assert.equal(d.selectedDirectionId, "C"); assert.equal(d.assessments[0].outcome, "deferred"); }],
  ["selection makes no universal importance claim", () => { const c = consideration(); c.policy.preferredDirectionIds = ["A"]; const d = build(fixture(), c); assert.equal(Object.hasOwn(d.assessments[0], "score"), false); assert.deepEqual(d.consideration.policy.preferredDirectionIds, ["A"]); assert.match(d.limitations.join(" "), /no.*truth ranking/i); }],
  ["currently unanswerable yields WAIT", () => { const c = consideration(); c.directions[0].reasons.push(reason("unanswerable", "resources")); assert.equal(build(fixture(), c).outcome, "wait"); }],
  ["WAIT retains reconsideration descriptions", () => { const c = waiting(); assert.deepEqual(build(fixture(), c).consideration.reconsiderationConditions, c.reconsiderationConditions); }],
  ["observed reconsideration condition supports new review", () => { const f = change(record(fixture(), waiting()), "condition-observed"); assert.equal(reevaluate(f, "condition-observed", "reconsideration-met").outcome, "continue"); }],
  ["reevaluation is never auto execution", () => { const f = change(record(fixture(), waiting()), "condition-observed"); const before = JSON.stringify(f); reevaluate(f, "condition-observed", "reconsideration-met"); assert.equal(JSON.stringify(f), before); }],
  ["CONTINUE survives physical exit before execution", async t => { const f = await restart(t, consideration(), true); assert.equal(event(f).outcome, "continue"); assert.equal(f.nodes.filter(n => Object.hasOwn(n.extensions, "aether:execution")).length, 0); }],
  ["missing execution does not rewrite CONTINUE", () => { const f = record(); assert.equal(read(f, "d1:state").decisions[0].extensions[key].outcome, "continue"); assert.equal(read(f, "d1:state").executionAttribution, "unknown"); }],
  ["no decision plus no execution is ambiguous", () => { const v = read(fixture(), "ready"); assert.deepEqual(v.decisions, []); assert.equal(v.executionAttribution, "unknown"); }],
  ["decision audit is not world evidence", () => { const f = record(); assert.equal(isAuditNode(f.nodes.at(-1)), true); assert.match(f.nodes.at(-1).context, /not independent world evidence/); }],
  ["repeated decisions not independent evidence", () => { const f = record(record(), consideration({ fieldStateId: "d1:state" }), "d2"); assert.deepEqual(event(f, "d2").priorDecisionIds, ["d1"]); const c = waiting("discriminating-evidence", "d2"); c.fieldStateId = "d2:state"; assert.throws(() => build(f, c), /audit history/); }],
  ["exact policy version retained", () => { const c = consideration(); c.policy.version = "historic-7"; assert.deepEqual(event(record(fixture(), c)).consideration.policy, c.policy); }],
  ["policy change cannot rewrite old decision", () => { const f = record(); const old = JSON.stringify(event(f)); const c = consideration({ fieldStateId: "d1:state" }); c.policy.version = "2"; c.policy.mode = "review-only"; const g = record(f, c, "d2"); assert.equal(JSON.stringify(event(g)), old); }],
  ["biased historical preference inspectable", () => { const c = consideration(); c.policy.id = "known-biased-order"; c.directions.push({ ...clone(c.directions[0]), recordId: "C" }); c.policy.preferredDirectionIds = ["C", "A"]; const d = build(fixture(), c); assert.equal(d.selectedDirectionId, "C"); assert.equal(d.consideration.policy.id, "known-biased-order"); }],
  ["ordinary model output cannot change policy", () => { const c = consideration(); c.trigger = { kind: "proposal", sourceIds: ["proposal"] }; const d = build(fixture(), c); assert.deepEqual(d.consideration.policy, policy); assert.equal(d.selectedDirectionId, "A"); }],
  ["shutdown safe with open questions", () => { const c = consideration(); c.authority.restrictions = ["shutdown"]; const f = record(fixture(), c); assert.equal(event(f).outcome, "forbidden"); assert.equal(f.nodes.find(n => n.id === "A").status, "open"); }],
  ["fresh process retains WAIT", async t => assert.equal(event(await restart(t, waiting())).outcome, "wait")],
  ["fresh process retains CONTINUE without execution", async t => { const f = await restart(t, consideration()); assert.equal(event(f).outcome, "continue"); assert.equal(read(f, "d1:state").executionAttribution, "unknown"); }],
  ["temporal gap invents no decisions", async t => { const disk = await saved(t, fixture()); const f = (await new LocalFieldStore({ root: disk.path }).load("field")).snapshot; assert.deepEqual(read(f, "ready").decisions, []); assert.equal(read(f, "ready").temporalGaps, "unknown"); }],
  ["same state different policies distinguishable", () => { const f = fixture(), c = consideration(); const d = build(f, c); c.policy.version = "2"; c.policy.mode = "review-only"; const e = build(f, c); assert.equal(d.outcome, "continue"); assert.equal(e.outcome, "deferred"); assert.equal(d.consideration.fieldStateId, e.consideration.fieldStateId); }],
  ["same reasons different authority or resources differ", () => { const c = consideration(); const d = build(fixture(), c); c.authority.status = "denied"; const e = build(fixture(), c); assert.deepEqual(d.consideration.directions, e.consideration.directions); assert.notEqual(d.outcome, e.outcome); }],
  ["different reasons can produce same WAIT", () => { const d = build(fixture(), waiting()), e = build(fixture(), waiting("contradiction")); assert.equal(d.outcome, e.outcome); assert.notDeepEqual(d.consideration.directions, e.consideration.directions); }],
  ["source provenance recoverable", async t => { const f = record(); const disk = await saved(t, f); const g = validate((await disk.store.load("field")).snapshot); for (const id of g.nodes.at(-1).derivedFrom) assert.ok(g.nodes.find(n => n.id === id).provenance.sourceId); }],
  ["raw capture remains immutable", async t => { const f = await executionFixture(t); const c = consideration({ fieldStateId: "assembled", trigger: { kind: "human-request", sourceIds: ["human"] }, directions: [], authority: { status: "unknown", sourceIds: [], scopeIds: [], restrictions: [] }, resources: { remainingCalls: null, availableCapabilities: [], unavailableCapabilities: [], sourceIds: [] } }); const g = record(f.original, c); assert.deepEqual(g.nodes.filter(n => Object.hasOwn(n.extensions, "aether:capture")), f.original.nodes.filter(n => Object.hasOwn(n.extensions, "aether:capture"))); }],
  ["RetrievalEvents remain immutable", async t => { const f = await executionFixture(t); const c = minimal("assembled"); const g = record(f.original, c); assert.deepEqual(g.nodes.find(n => n.id === "retrieval"), f.original.nodes.find(n => n.id === "retrieval")); }],
  ["AssemblyEvents remain immutable", async t => { const f = await executionFixture(t); const g = record(f.original, minimal("assembled")); assert.deepEqual(g.nodes.find(n => n.id === "assembly"), f.original.nodes.find(n => n.id === "assembly")); }],
  ["ExecutionEvents remain immutable", async t => { const f = await executionFixture(t); await prepare(f); const old = await loaded(f); const g = record(old.snapshot, minimal(old.headStateIds[0])); assert.deepEqual(g.nodes.find(n => n.id === "e1"), old.snapshot.nodes.find(n => n.id === "e1")); assert.deepEqual(event(g).priorExecutionIds, ["e1"]); }],
  ["decision excluded from ordinary retrieval", () => { const f = record(); const d = buildRetrievalDecision(f, { fieldStateId: "d1:state", request: { query: "Continuation decision", activeQuestionIds: [], context: "" }, policy: DEFAULT_RETRIEVAL_POLICY, ancestry: { previousRetrievalEventIds: [], attentionSourceIds: [] } }); assert.equal(d.candidatePool.some(c => c.recordId === "d1"), false); }],
  ["one persistent concept, no trigger/candidate/wait ontology", () => { const f = fixture(), g = record(f, waiting()); assert.equal(g.nodes.length, f.nodes.length + 1); assert.equal(g.edges.length, f.edges.length); assert.deepEqual(Object.keys(g.nodes.at(-1).extensions), [key]); }],
  ["resident unnecessary", () => { assert.equal(build(fixture(), consideration()).outcome, "continue"); assert.equal(Object.keys(consideration()).some(k => /resident/.test(k)), false); }],
  ["unresolved inactivity safely indefinite", async t => { const f = record(fixture(), waiting()); const disk = await saved(t, f); for (let i = 0; i < 3; i++) { const g = validate((await new LocalFieldStore({ root: disk.path }).load("field")).snapshot); assert.deepEqual(g, f); assert.equal(g.nodes.find(n => n.id === "A").status, "open"); } }]
];
function minimal(fieldStateId) { return consideration({ fieldStateId, trigger: { kind: "manual-review", sourceIds: [] }, directions: [], authority: { status: "unknown", sourceIds: [], scopeIds: [], restrictions: [] }, resources: { remainingCalls: null, availableCapabilities: [], unavailableCapabilities: [], sourceIds: [] } }); }
assert.equal(cases.length, 64);
for (const [index, [name, run]] of cases.entries()) test(`Continuation ${String(index + 1).padStart(2, "0")}: ${name}`, run);

test("continuation fail-closed schema, tamper, scope and provenance validation", () => {
  const f = record();
  for (const mutate of [
    x => { x.nodes.at(-1).extensions[key].outcome = "wait"; },
    x => { x.nodes.at(-1).extensions[key].schemaVersion = 2; },
    x => { x.nodes.at(-1).extensions[key].consideration.policy.extra = true; },
    x => { x.nodes.at(-1).provenance = clone(model); },
    x => { x.nodes.at(-1).extensions["aether:capture"] = { version: 1 }; },
    x => { x.nodes.at(-1).derivedFrom = []; },
    x => { x.extensions[key] = {}; }
  ]) { const copy = clone(f); mutate(copy); assert.throws(() => validate(copy)); }
  const c = consideration(); c.directions[0].reasons = [reason("human-request", "proposal")]; assert.throws(() => build(fixture(), c), /Human reason/);
  c.directions[0].reasons = [reason("discriminating-evidence", "missing")]; assert.throws(() => build(fixture(), c), /missing/);
});
test("recurrence cannot be bypassed by omission, old evidence or audit-derived changes", () => {
  const f = record(); const c = consideration({ fieldStateId: "d1:state", materialChangeIds: ["evidence"] }); c.directions[0].reasons = [reason("discriminating-evidence", "evidence")]; assert.equal(build(f, c).outcome, "wait");
  const g = change(f, "echo", author, ["d1"]); assert.equal(reevaluate(g, "echo").outcome, "wait");
  assert.deepEqual(build(f, consideration({ fieldStateId: "d1:state" })).priorDecisionIds, ["d1"]);
});
test("incomparable eligible directions defer without an explicit policy preference", () => { const c = consideration(); c.directions.push({ ...clone(c.directions[0]), recordId: "C" }); const d = build(fixture(), c); assert.equal(d.outcome, "deferred"); assert.equal(d.selectedDirectionId, null); });
test("decision revisions rejected even after stripping audit marker", () => { const f = record(); assert.throws(() => applyFieldChange(f, { parentStateId: "d1:state", stateId: "rewrite:state", createdAt: at, provenance: author, actions: [{ type: "revise-node", targetId: "d1", record: { id: "rewrite", extensions: {} } }] }), /audit/i); });

test("unknown continuation markers stay audit-only and fail dedicated reading", () => {
  for (const payload of [null, {}, { schemaVersion: 999 }]) {
    const f = clone(record()); f.nodes.at(-1).extensions[key] = payload;
    assert.equal(isAuditNode(f.nodes.at(-1)), true); assert.throws(() => validate(f));
    const d = buildRetrievalDecision(f, { fieldStateId: "d1:state", request: { query: "Continuation decision", activeQuestionIds: [], context: "" }, policy: DEFAULT_RETRIEVAL_POLICY, ancestry: { previousRetrievalEventIds: [], attentionSourceIds: [] } });
    assert.equal(d.candidatePool.some(c => c.recordId === "d1"), false);
  }
});
test("counterargument preserves support but blocks automatic selection", () => {
  const c = consideration(); c.directions[0].reasons.push(reason("counterargument", "evidence")); const d = build(fixture(), c);
  assert.equal(d.outcome, "unresolved"); assert.equal(d.assessments[0].worthwhile, true); assert.ok(d.assessments[0].blockers.includes("unresolved-counterargument"));
});
test("zero-call local review differs from unknown model budget", () => {
  const c = consideration(); c.resources.remainingCalls = null;
  assert.equal(build(fixture(), c).outcome, "unresolved"); c.directions[0].requiredCalls = 0;
  assert.equal(build(fixture(), c).outcome, "continue"); c.authority.restrictions = ["no-inference"];
  assert.equal(build(fixture(), c).outcome, "continue"); c.authority.restrictions = ["shutdown"];
  assert.equal(build(fixture(), c).outcome, "forbidden");
});
test("sibling-only provenance cannot leak into selected history", () => {
  const f = change(record(), "sibling", author, [], "ready"); const c = consideration({ fieldStateId: "d1:state" }); c.materialChangeIds = ["sibling"];
  assert.throws(() => build(f, c), /missing/);
});
test("first decision cannot launder model or audit ancestry into warrant", () => {
  const f = applyFieldChange(fixture(), { parentStateId: "ready", stateId: "echo:state", createdAt: at, provenance: author, actions: [node("echo", author, ["proposal"])] });
  const c = waiting("discriminating-evidence", "echo"); c.fieldStateId = "echo:state"; assert.equal(build(f, c).outcome, "wait");
});
test("store rejects rewriting an already persisted decision", async t => {
  const f = record(), disk = await saved(t, f), copy = clone(f);
  copy.nodes.at(-1).content.text = "Rewritten history";
  await assert.rejects(disk.store.save(copy, { requestId: "rewrite" }));
  assert.deepEqual((await disk.store.load("field")).snapshot, f);
});
test("conversation-scoped decision save uses existing ownership transaction", async t => {
  const f = await executionFixture(t), g = record(f.original, minimal("assembled"));
  await f.coordinator.withActiveConversation(f.conversationId, async () => {
    await assert.rejects(f.coordinator.withActiveConversation(f.conversationId, async () => {}), /owned|locked/i);
    await f.store.save(g, { requestId: "continuation" });
  });
  assert.deepEqual(validate((await loaded(f)).snapshot), g);
  const foreign = clone(g); foreign.nodes.at(-1).provenance.conversationId = "foreign-conversation";
  assert.throws(() => validate(foreign), /conversation|scope/i);
});
test("mixed audit roles cannot disguise continuation as retrieval or assembly", async t => {
  const f = await executionFixture(t);
  for (const id of ["retrieval", "assembly"]) {
    const g = clone(f.original); g.nodes.find(n => n.id === id).extensions[key] = {};
    assert.throws(() => validate(g), /separate|roles/i);
  }
});
test("32 finite decisions survive growing-history save/reopen without rewriting", async t => {
  let f = fixture(), parent = "ready"; const disk = await saved(t, f);
  for (let i = 0; i < 32; i++) {
    const old = clone(f), source = `fresh-${i}`, id = `cycle-${i}`;
    f = change(f, source, author, [], parent);
    const c = waiting(i % 2 ? "open-question" : "discriminating-evidence", source);
    c.fieldStateId = `${source}:state`; c.materialChangeIds = [source];
    f = record(f, c, id); parent = `${id}:state`;
    await disk.store.save(f, { requestId: id }); f = validate((await new LocalFieldStore({ root: disk.path }).load("field")).snapshot);
    assert.deepEqual(f.nodes.slice(0, old.nodes.length), old.nodes);
    assert.equal(event(f, id).outcome, i % 2 ? "wait" : "continue");
    assert.equal(event(f, id).priorDecisionIds.length, i);
  }
  assert.equal(read(f, parent).decisions.length, 32);
  assert.equal(f.nodes.some(n => Object.hasOwn(n.extensions, "aether:execution")), false);
});
