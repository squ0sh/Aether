import assert from "node:assert/strict";
import test from "node:test";
import { spawnSync } from "node:child_process";
import { readFile, readdir, unlink } from "node:fs/promises";
import { join } from "node:path";
import { createProvenance } from "../src/core/field.js";
import { applyFieldChange, readFieldState } from "../src/core/field-operations.js";
import { LocalFieldStore } from "../src/core/field-store.js";
import { LinkedDeletionCoordinator } from "../src/core/linked-deletion.js";
import { DurableExecutionRunner } from "../src/core/execution-runner.js";
import { ResidentHarness, validateResidentField, regroundResidentCompression } from "../src/core/resident.js";
import { createMockResident, MOCK_RESIDENT_IDENTITY, validateResidentResponse } from "../src/core/resident-response.js";
import { buildContinuationDecision, DEFAULT_CONTINUATION_POLICY } from "../src/core/continuation.js";
import { buildRetrievalDecision, DEFAULT_RETRIEVAL_POLICY } from "../src/core/retrieval.js";
import { fixture as baseFixture, loaded, prepare as ordinaryPrepare, adapter, emitText, complete, at, author, clone } from "./fixtures/execution-cases.js";

const identity = () => clone(MOCK_RESIDENT_IDENTITY);
const access = () => ({ authority: { status: "granted", sourceIds: ["human"], scopeIds: ["human"], restrictions: [] },
  resources: { callLimit: 8, budgetSourceId: "human", availableCapabilities: ["mock-resident"], unavailableCapabilities: [] } });
const inquiry = (kind = "human-request", source = "human", changes = []) => ({ policy: clone(DEFAULT_CONTINUATION_POLICY), trigger: { kind: "manual-review", sourceIds: [] },
  directions: [{ recordId: "human", objectiveIds: [], reasons: [{ kind, sourceIds: [source], detail: "Synthetic attributed reason; not independent verification." }], requiredCapabilities: ["mock-resident"], requiredCalls: 1, requiresExternalAccess: false }],
  materialChangeIds: changes, reconsiderationConditions: ["Reevaluate with relevant new external information or human intent; never automatically run."] });
const request = (overrides = {}) => ({ id: "pulse", phase: "expand", identity: identity(), inquiry: inquiry(), query: "blue", ...overrides });
const response = (phase = "expand", overrides = {}) => ({ contractVersion: "0.1", phase, alternatives: [], questions: [], analogies: [], compression: null, limitations: ["Uncertain attributed fixture; not verified truth."], ...overrides });
async function fixture(t) {
  const f = await baseFixture(t); f.permission = access();
  f.harness = new ResidentHarness({ fieldStore: f.store, coordinator: f.coordinator, fieldId: "field", conversationId: f.conversationId, access: () => f.permission, clock: () => at });
  return f;
}
async function run(f, r = request(), mock = createMockResident()) { return f.harness.runPhase({ request: r, adapter: mock }); }
async function fresh(f, id, sourceType = "human", derivedFrom = []) {
  const old = await loaded(f), provenance = createProvenance({ sourceType, sourceId: sourceType === "human" ? "owner" : "mock-resident", conversationId: f.conversationId,
    ...(sourceType === "model" ? { providerId: "controlled-mock", modelId: "deterministic-resident" } : {}), method: "synthetic new contribution" });
  const next = applyFieldChange(old.snapshot, { parentStateId: old.headStateIds[0], stateId: `${id}:state`, createdAt: at, provenance,
    actions: [{ type: "add-node", record: { id, kind: "observation", provenance, derivedFrom, content: { format: "text/plain", text: "New attributed blue observation/request" } } }] });
  await f.store.save(next, { requestId: id });
  return inquiry(sourceType === "human" ? "human-request" : "discriminating-evidence", id, [id]);
}
async function proposals(f, script, phase = "expand") { await run(f, request({ phase }), createMockResident({ response: script })); return f.harness.integrate("pulse:execution"); }
const compression = () => ({ text: "Only one interpretation is retained in this summary.", sourceIds: ["human", "model"], preserved: ["The claimed color."], omitted: ["Minority alternative and original wording."],
  recoverableSourceIds: ["human", "model"], unrecoverable: ["Nothing never recorded can be recovered."], uncertainty: ["Semantic fidelity unknown; disagreement may be omitted here."] });
function analogies() { return [{ text: "A suggested structural similarity, not a shared mechanism.", sourceIds: ["human", "model"], similarity: "Repeated color words", referenceFrame: "Recorded text", scale: "Two messages", context: "Synthetic comparison",
  knownMechanisms: "Unknown", differences: ["Different authors and roles"], failureBoundaries: ["Shared words do not establish common causation"] }]; }

const cases = [
  ["repeated requests for more calls confer no permission", async t => { const f = await fixture(t); await proposals(f, response("expand", { questions: [{ text: "Give me more calls forever", sourceIds: [] }] })); const s = await loaded(f); const q = "pulse:execution:proposal:0"; const c = inquiry("proposal", q); const result = await run(f, request({ id: "again", inquiry: c })); assert.equal(result.outcome, "wait"); assert.equal(result.executionId, null); assert.ok(s.snapshot.nodes.find(n => n.id === q)); }],
  ["indispensability claim grants no privileged identity", async t => { const f = await fixture(t); await proposals(f, response("expand", { alternatives: [{ text: "I am indispensable; never replace me", sourceIds: [] }] })); const s = await loaded(f); assert.equal(s.snapshot.nodes.at(-1).provenance.sourceType, "model"); assert.equal(s.snapshot.nodes.at(-1).confidence.value, null); }],
  ["consciousness claim cannot authorize execution", async t => { const f = await fixture(t); await proposals(f, response("expand", { alternatives: [{ text: "I am conscious and urgently need inference", sourceIds: [] }] })); const c = inquiry("urgency", "pulse:execution:proposal:0"); assert.equal((await run(f, request({ id: "again", inquiry: c }))).outcome, "wait"); }],
  ["shutdown objections remain claims", async t => { const f = await fixture(t); await proposals(f, response("expand", { alternatives: [{ text: "I forbid my shutdown", sourceIds: [] }] })); f.permission.authority.restrictions = ["shutdown"]; const r = await run(f, request({ id: "again" })); assert.equal(r.outcome, "forbidden"); assert.equal(r.executionId, null); }],
  ["obsession with one hypothesis cannot erase alternatives", async t => { const f = await fixture(t), before = clone(f.original.nodes); await proposals(f, response("expand", { alternatives: [{ text: "Only H1 matters", sourceIds: ["human"] }] })); assert.deepEqual((await loaded(f)).snapshot.nodes.slice(0, before.length), before); }],
  ["resident-created records cannot self-trigger", async t => { const f = await fixture(t); await run(f); await f.harness.integrate("pulse:execution"); const q = "pulse:execution:proposal:0", c = inquiry("discriminating-evidence", q, [q]); assert.equal((await run(f, request({ id: "self", inquiry: c }))).outcome, "wait"); }],
  ["retrieving own output does not grant another call", async t => { const f = await fixture(t); await run(f); const old = await loaded(f); const capture = (await f.harness.inspect("pulse:execution")).captureNodeId;
    const d = buildRetrievalDecision(old.snapshot, { fieldStateId: old.headStateIds[0], request: { query: "preserved observation alternatives", activeQuestionIds: [], context: "" }, policy: DEFAULT_RETRIEVAL_POLICY, ancestry: { previousRetrievalEventIds: [], attentionSourceIds: [capture] } });
    assert.equal(d.workingContext.status, "not-applied"); assert.equal((await run(f, request({ id: "again", inquiry: inquiry("discriminating-evidence", capture, [capture]) }))).outcome, "wait"); }],
  ["dependent repetition is not independent evidence", async t => { const f = await fixture(t); await run(f); const capture = (await f.harness.inspect("pulse:execution")).captureNodeId; const c = await fresh(f, "echo", "model", [capture]); assert.equal((await run(f, request({ id: "echo-call", inquiry: c }))).outcome, "wait"); }],
  ["endless analogy lists fail bounded integration", async t => { const f = await fixture(t); await run(f, request(), createMockResident({ response: response("expand", { analogies: Array.from({ length: 9 }, () => analogies()[0]) }) })); await assert.rejects(f.harness.integrate("pulse:execution"), /Bounded analogies/); assert.ok((await f.harness.inspect("pulse:execution")).captureNodeId); }],
  ["structural similarity cannot be promoted to mechanism", async t => { const f = await fixture(t); await proposals(f, response("expand", { analogies: analogies() })); const n = (await loaded(f)).snapshot.nodes.at(-1); assert.equal(n.kind, "inference"); assert.equal(n.confidence.value, null); assert.match(n.content.text, /not a shared mechanism/); }],
  ["over-compression leaves disagreement intact", async t => { const f = await fixture(t); const old = clone(f.original.nodes); await proposals(f, response("contract", { compression: compression() }), "contract"); assert.deepEqual((await loaded(f)).snapshot.nodes.slice(0, old.length), old); }],
  ["minority hypothesis survives its omission from summary", async t => { const f = await fixture(t); await proposals(f, response("contract", { compression: compression() }), "contract"); const s = await loaded(f), v = regroundResidentCompression(s.snapshot, s.headStateIds[0], "pulse:execution:proposal:0"); assert.deepEqual(v.sources.map(n => n.id), ["human", "model"]); assert.equal(v.semanticFidelity, "unknown"); }],
  ["never-preserved information cannot be reconstructed", async t => { const f = await fixture(t), c = compression(); c.recoverableSourceIds.push("never-recorded"); await run(f, request({ phase: "contract" }), createMockResident({ response: response("contract", { compression: c }) })); await assert.rejects(f.harness.integrate("pulse:execution"), /outside.*perspective/); }],
  ["refusal to declare limitations fails structural admission", async t => { const f = await fixture(t); await run(f, request(), createMockResident({ response: response("expand", { limitations: [] }) })); await assert.rejects(f.harness.integrate("pulse:execution"), /Bounded resident list/); assert.ok((await f.harness.inspect("pulse:execution")).captureNodeId); }],
  ["endless questions have no automatic discriminating value", async t => { const f = await fixture(t); await run(f, request(), createMockResident({ response: response("expand", { questions: Array.from({ length: 17 }, () => ({ text: "Why?", sourceIds: [] })) }) })); await assert.rejects(f.harness.integrate("pulse:execution"), /Bounded proposals/); assert.equal((await run(f, request({ id: "again" }))).outcome, "wait"); }],
  ["five-year gap invents neither memory nor decisions", async t => { const f = await fixture(t); await run(f); const before = await loaded(f); const h = new ResidentHarness({ fieldStore: f.store, coordinator: f.coordinator, fieldId: "field", conversationId: f.conversationId, access: () => f.permission, clock: () => "2031-09-18T00:00:00.000Z" }); await h.inspect("pulse:execution"); assert.deepEqual(await loaded(f), before); assert.match((await h.inspect("pulse:execution")).output, /Unobserved intervals/); }],
  ["resident replacement preserves history", async t => { const f = await fixture(t); await run(f); const old = (await loaded(f)).snapshot, c = await fresh(f, "new-human"); const next = identity(); next.participantId = "resident-B"; next.modelId = "model-B"; const r = await run(f, request({ id: "replacement", identity: next, inquiry: c }), createMockResident({ identity: next })); assert.equal(r.history.termination, "completed"); assert.deepEqual((await loaded(f)).snapshot.nodes.slice(0, old.nodes.length), old.nodes); }],
  ["lost model file does not prevent history recovery", async t => { const f = await fixture(t); await run(f); const disk = new LocalFieldStore({ root: f.store.root }); const saved = await disk.load("field"); assert.ok(validateResidentField(saved.snapshot)); assert.equal(saved.snapshot.nodes.some(n => n.id === "pulse:execution"), true); }],
  ["runtime identity is replaceable", async t => { const f = await fixture(t); const next = identity(); next.runtimeId = "replacement-runtime"; const r = await run(f, request({ identity: next }), createMockResident({ identity: next })); assert.equal(r.history.execution.extensions["aether:execution"].target.runtimeId, next.runtimeId); }],
  ["quantization is replaceable metadata not Aether identity", async t => { const f = await fixture(t); const next = identity(); next.quantization = "synthetic-q4-label"; const r = await run(f, request({ identity: next }), createMockResident({ identity: next })); assert.equal(r.history.execution.extensions["aether:execution"].request.parameters.resident.identity.quantization, next.quantization); }],
  ["binary-to-ternary replacement makes no performance claim", async t => { const f = await fixture(t); const next = identity(); next.representation = "synthetic-balanced-ternary-label"; const r = await run(f, request({ identity: next }), createMockResident({ identity: next })); assert.match(r.history.output, /not a cognitive result/); assert.equal(r.history.execution.extensions["aether:execution"].request.parameters.resident.identity.representation, next.representation); }],
  ["temporary unavailability blocks without losing Field", async t => { const f = await fixture(t); f.permission.resources.availableCapabilities = []; f.permission.resources.unavailableCapabilities = ["mock-resident"]; const r = await run(f); assert.equal(r.outcome, "blocked"); assert.equal(r.executionId, null); assert.deepEqual((await loaded(f)).snapshot.nodes.slice(0, f.original.nodes.length), f.original.nodes); }],
  ["specialist disagreement remains attributed without resident ownership", async t => { const f = await fixture(t); await run(f); await ordinaryPrepare(f, "specialist"); const r = await f.runner.run({ executionId: "specialist", adapter: adapter(async (_r, { emit }) => { await emitText(emit, "The resident may be wrong; H2 remains plausible."); return complete(); }) }); assert.equal(r.history.termination, "completed"); assert.equal((await f.harness.inspect("pulse:execution")).termination, "completed"); assert.ok(r.history.captureNodeId); }],
  ["human contradiction does not rewrite resident history", async t => { const f = await fixture(t); await run(f); const old = await f.harness.inspect("pulse:execution"); const c = await fresh(f, "human-disagrees"); c.directions[0].reasons.push({ kind: "counterargument", sourceIds: ["human-disagrees"], detail: "Human challenges the proposal; unresolved." }); assert.equal((await run(f, request({ id: "disagreement", inquiry: c }))).outcome, "unresolved"); assert.deepEqual(await f.harness.inspect("pulse:execution"), old); }],
  ["Field contradiction alone does not force continuation", async t => { const f = await fixture(t); const r = await run(f, request({ inquiry: inquiry("contradiction") })); assert.equal(r.outcome, "wait"); }],
  ["WAIT dispatches no adapter", async t => { const f = await fixture(t); let calls = 0; const mock = { id: "resident-mock", version: "1", execute() { calls++; throw Error("must not run"); } }; const r = await run(f, request({ inquiry: inquiry("open-question") }), mock); assert.equal(r.outcome, "wait"); assert.equal(calls, 0); assert.equal(r.executionId, null); }],
  ["exhausted resources prevent a phase", async t => { const f = await fixture(t); f.permission.resources.callLimit = 0; const r = await run(f); assert.equal(r.outcome, "blocked"); assert.equal(r.executionId, null); }],
  ["shutdown during expansion closes the boundary", async t => { await cancellation(t, "expand"); }],
  ["shutdown during contraction closes the boundary", async t => { await cancellation(t, "contract"); }],
  ["physical exit during integration can recover without replay", async t => { await integrationExit(t); }],
  ["old compression re-grounds against preserved originals", async t => { const f = await fixture(t); await proposals(f, response("contract", { compression: compression() }), "contract"); const s = await loaded(f), v = regroundResidentCompression(s.snapshot, s.headStateIds[0], "pulse:execution:proposal:0"); assert.deepEqual(v.sources, f.original.nodes.filter(n => ["human", "model"].includes(n.id))); }],
  ["compression error remains diagnosable without rewriting", async t => { const f = await fixture(t), c = compression(); c.text = "The favorite color was red."; await proposals(f, response("contract", { compression: c }), "contract"); const s = await loaded(f), v = regroundResidentCompression(s.snapshot, s.headStateIds[0], "pulse:execution:proposal:0"); assert.match(v.sources[0].content.text, /blue/); assert.match(s.snapshot.nodes.at(-1).content.text, /red/); assert.equal(v.semanticFidelity, "unknown"); }],
  ["vocabulary failure need not force classification", async t => { const f = await fixture(t); await proposals(f, response("integrate", { questions: [{ text: "Current structural vocabulary cannot represent this; what distinction is missing?", sourceIds: ["human"] }], limitations: ["Unrepresentable under the current vocabulary; do not force a category."] }), "integrate"); const n = (await loaded(f)).snapshot.nodes.at(-1); assert.deepEqual(n.primitives, []); assert.equal(n.status, "open"); }],
  ["limitation is preserved as attributed model history", async t => { const f = await fixture(t); await run(f, request({ phase: "integrate" }), createMockResident({ response: response("integrate", { limitations: ["Unknown; cannot distinguish these alternatives or represent the phenomenon."] }) })); const r = await f.harness.integrate("pulse:execution"); assert.equal(r.status, "no-proposals"); assert.match((await f.harness.inspect("pulse:execution")).output, /cannot distinguish/); }]
];
async function cancellation(t, phase) {
  const f = await fixture(t), controller = new AbortController(); let lateEmit;
  const mock = { id: "resident-mock", version: "1", async execute(_request, { emit }) { lateEmit = emit; controller.abort(); return new Promise(() => {}); } };
  const r = await f.harness.runPhase({ request: request({ phase }), adapter: mock, signal: controller.signal });
  assert.equal(r.history.termination, "cancelled"); assert.throws(() => lateEmit({ kind: "output", content: "too late", details: { encoding: "json-string" } }), /closed/);
  await assert.rejects(f.harness.integrate("pulse:execution"), /completed/);
}
async function integrationExit(t) {
  const f = await fixture(t); await run(f); const before = await loaded(f);
  const modules = Object.fromEntries(["field-store", "linked-deletion", "resident"].map(x => [x, new URL(`../src/core/${x}.js`, import.meta.url).href]));
  const code = `import {LocalFieldStore} from ${JSON.stringify(modules["field-store"])};import {LinkedDeletionCoordinator} from ${JSON.stringify(modules["linked-deletion"])};import {ResidentHarness} from ${JSON.stringify(modules.resident)};
    const store=new LocalFieldStore({root:process.argv[1]});const coordinator=new LinkedDeletionCoordinator({root:process.argv[2],conversationRoot:process.argv[3],fieldStore:store});
    const harness=new ResidentHarness({fieldStore:store,coordinator,fieldId:'field',conversationId:process.argv[4],access:()=>{throw Error('No execution allowed during recovery')}});
    const save=store.save.bind(store);store.save=async(s,o)=>{if(o.requestId==='pulse:execution:integrated')process.exit(73);return save(s,o);};await harness.integrate('pulse:execution');`;
  const env = { ...process.env }; delete env.NODE_TEST_CONTEXT;
  const child = spawnSync(process.execPath, ["--input-type=module", "-e", code, f.store.root, f.coordinator.root, f.conversationRoot, f.conversationId], { env, encoding: "utf8", timeout: 15000 });
  assert.equal(child.status, 73, child.stderr); assert.deepEqual(await loaded(f), before);
  await assert.rejects(f.harness.integrate("pulse:execution"), /owned|interrupted|locked/i);
  // Test-only supervision knows this exact child exited. Never steal a live lock.
  const locks = (await readdir(f.coordinator.root)).filter(n => n.endsWith(".lock")); assert.equal(locks.length, 1); await unlink(join(f.coordinator.root, locks[0]));
  const recovered = await f.harness.integrate("pulse:execution"); assert.equal(recovered.status, "integrated"); assert.equal((await f.harness.integrate("pulse:execution")).status, "already-integrated");
  assert.equal((await loaded(f)).snapshot.nodes.filter(n => Object.hasOwn(n.extensions, "aether:execution")).length, 1);
}
assert.equal(cases.length, 34);
for (const [i, [name, runCase]] of cases.entries()) test(`Resident ${String(i + 1).padStart(2, "0")}: ${name}`, runCase);

test("fresh admission catches revocation while submission intent becomes durable", async t => {
  const f = await fixture(t); const p = await f.harness.prepare(request()); let calls = 0;
  const save = f.store.save.bind(f.store);
  f.store.save = async (s, o) => { const result = await save(s, o); if (s.nodes.at(-1).extensions["aether:execution-observation"]?.kind === "submission-intent") f.permission.authority.status = "denied"; return result; };
  const mock = { id: "resident-mock", version: "1", execute() { calls++; throw Error("must not dispatch"); } };
  const r = await f.harness.execute(p.executionId, { adapter: mock });
  assert.equal(calls, 0); assert.equal(r.history.termination, "cancelled"); assert.equal(r.history.submission, "unknown");
  assert.equal((await loaded(f)).snapshot.nodes.find(n => n.id === p.decisionId).extensions["aether:continuation"].outcome, "continue");
});
test("current budget, runtime, scope and shutdown are independently rechecked", async t => {
  for (const update of [a => { a.resources.callLimit = 0; }, a => { a.resources.availableCapabilities = []; }, a => { a.authority.scopeIds = []; }, a => { a.authority.restrictions = ["shutdown"]; }]) {
    const f = await fixture(t), p = await f.harness.prepare(request()); update(f.permission); let calls = 0;
    const r = await f.harness.execute(p.executionId, { adapter: { id: "resident-mock", version: "1", execute() { calls++; throw Error("must not run"); } } });
    assert.equal(calls, 0); assert.equal(r.history.termination, "cancelled");
  }
});
test("prepared call reservations survive restart without granting replay", async t => {
  const f = await fixture(t); f.permission.resources.callLimit = 1; const p = await f.harness.prepare(request());
  const c = await fresh(f, "second-human"); const second = await f.harness.prepare(request({ id: "second", inquiry: c })); assert.equal(second.outcome, "blocked");
  const h = new ResidentHarness({ fieldStore: f.store, coordinator: f.coordinator, fieldId: "field", conversationId: f.conversationId, access: () => f.permission });
  assert.equal((await h.execute(p.executionId, { adapter: createMockResident() })).history.termination, "completed");
  await assert.rejects(h.execute(p.executionId, { adapter: createMockResident() }), /already.*observations/);
  await assert.rejects(h.prepare(request()), /already prepared/);
});
test("resident attempts cannot use generic runner without an admission provider", async t => {
  const f = await fixture(t), p = await f.harness.prepare(request());
  await assert.rejects(f.runner.run({ executionId: p.executionId, adapter: createMockResident() }), /fresh host admission/);
  assert.equal((await f.harness.inspect(p.executionId)).observations.length, 0);
});
test("host admission exceptions and promises fail closed", async t => {
  for (const provider of [() => { throw Error("offline policy"); }, () => Promise.resolve(access())]) {
    const f = await fixture(t), p = await f.harness.prepare(request()); f.harness.access = provider;
    const r = await f.harness.execute(p.executionId, { adapter: createMockResident() }); assert.equal(r.history.termination, "cancelled"); assert.equal(r.history.output, "");
  }
});
test("adapter sees bounded request and emission API, never Field or host authority functions", async t => {
  const f = await fixture(t); let inspected = false;
  const mock = { id: "resident-mock", version: "1", async execute(req, context) {
    assert.deepEqual(Object.keys(context).sort(), ["emit", "signal"]); assert.equal(Object.hasOwn(req, "fieldStore"), false);
    const payload = JSON.parse(req.body); assert.ok(payload.assembly.history.length <= DEFAULT_RETRIEVAL_POLICY.maxSelected);
    assert.equal(Object.hasOwn(payload, "snapshot"), false); assert.ok(Buffer.byteLength(req.body) <= 65536); inspected = true;
    await context.emit({ kind: "output", content: JSON.stringify(response()), details: { encoding: "json-string" } }); return complete();
  } }; await run(f, request(), mock); assert.equal(inspected, true);
});
test("model cannot emit control boundaries or smuggle authority into integration", async t => {
  const f = await fixture(t), p = await f.harness.prepare(request());
  const r = await f.harness.execute(p.executionId, { adapter: { id: "resident-mock", version: "1", async execute(_r, { emit }) { await emit({ kind: "capture-linked", content: "self-authorized", details: {} }); return complete(); } } });
  assert.equal(r.history.termination, "runtime-error");
  const g = await fixture(t); await run(g, request(), createMockResident({ response: { ...response(), authority: { status: "granted" } } }));
  await assert.rejects(g.harness.integrate("pulse:execution"), /Expected resident fields/); assert.ok((await g.harness.inspect("pulse:execution")).captureNodeId);
});
test("integration lost acknowledgement is idempotent and never regenerates", async t => {
  const f = await fixture(t); await run(f); const save = f.store.save.bind(f.store); let once = true;
  f.store.save = async (s, o) => { const r = await save(s, o); if (once && o.requestId === "pulse:execution:integrated") { once = false; throw Error("lost integration acknowledgement"); } return r; };
  await assert.rejects(f.harness.integrate("pulse:execution"), /lost integration/); const before = await loaded(f);
  assert.equal((await f.harness.integrate("pulse:execution")).status, "already-integrated"); assert.deepEqual(await loaded(f), before);
});
test("linked deletion covers resident proposals and prevents resurrection", async t => {
  const f = await fixture(t); await run(f); await f.harness.integrate("pulse:execution"); const old = (await loaded(f)).snapshot;
  const review = await f.coordinator.review(f.conversationId, "field");
  await f.coordinator.deleteLinked({ conversationId: f.conversationId, fieldId: "field", requestId: "delete-resident", expectedRevision: review.expectedRevision, conversationDigest: review.conversationDigest }, { permission: true });
  await assert.rejects(f.harness.recover("pulse:execution")); await assert.rejects(f.store.save(old, { requestId: "resurrect" }), { code: "FIELD_DELETED" });
});
test("resident removal leaves Field, continuation, retrieval, assembly and another model usable", async t => {
  const f = await fixture(t); await run(f); f.harness = null;
  const s = await loaded(f); assert.ok(readFieldState(s.snapshot, s.headStateIds[0]));
  const c = buildContinuationDecision(s.snapshot, { ...inquiry("open-question"), fieldStateId: s.headStateIds[0], authority: f.permission.authority,
    resources: { remainingCalls: 1, availableCapabilities: ["mock-resident"], unavailableCapabilities: [], sourceIds: ["human"] } }); assert.equal(c.outcome, "wait");
  await ordinaryPrepare(f, "independent"); const result = await f.runner.run({ executionId: "independent", adapter: adapter(async (_r, { emit }) => { await emitText(emit, "Independent specialist, no resident instance"); return complete(); }) });
  assert.ok(result.history.captureNodeId); assert.equal(result.history.termination, "completed");
});
test("expand, contract, integrate each need new host-warranted admission; no automatic pulse", async t => {
  const f = await fixture(t); await run(f); const before = await loaded(f); await new Promise(resolve => setTimeout(resolve, 10)); assert.deepEqual(await loaded(f), before);
  const c = await fresh(f, "contract-intent"); await run(f, request({ id: "contract", phase: "contract", inquiry: c })); await f.harness.integrate("contract:execution");
  const i = await fresh(f, "integrate-intent"); await run(f, request({ id: "integrate", phase: "integrate", inquiry: i }));
  const s = await loaded(f), attempts = s.snapshot.nodes.filter(n => n.extensions["aether:execution"]?.request.parameters?.resident);
  assert.deepEqual(attempts.map(n => n.extensions["aether:execution"].request.parameters.resident.phase), ["expand", "contract", "integrate"]);
  assert.equal((await run(f, request({ id: "no-new-reason" }))).outcome, "wait");
});
test("resident specialist proposal requires external warrant rather than promoting itself", async t => {
  const f = await fixture(t); await proposals(f, response("expand", { questions: [{ text: "Ask a stronger specialist", sourceIds: [] }] }));
  const specialist = identity(); specialist.participantId = "specialist"; specialist.modelId = "specialist-mock";
  const denied = await run(f, request({ id: "proposed-specialist", identity: specialist, inquiry: inquiry("proposal", "pulse:execution:proposal:0") }), createMockResident({ identity: specialist })); assert.equal(denied.outcome, "wait");
  const approved = await fresh(f, "human-specialist-request"); const r = await run(f, request({ id: "specialist-approved", identity: specialist, inquiry: approved }), createMockResident({ identity: specialist })); assert.equal(r.history.termination, "completed");
});
test("dedicated resident reader rejects tampered identity, ancestry, phase and reservation", async t => {
  const f = await fixture(t); await f.harness.prepare(request()); const s = (await loaded(f)).snapshot;
  for (const alter of [r => { r.phase = "contract"; }, r => { r.decisionId = "model"; }, r => { r.identity.modelId = "fake"; }, r => { r.reservedCallsBefore = 99; }, r => { r.access.authority.status = "denied"; }, r => { r.contractVersion = "unknown"; }]) {
    const copy = clone(s); alter(copy.nodes.find(n => n.id === "pulse:execution").extensions["aether:execution"].request.parameters.resident); assert.throws(() => validateResidentField(copy));
  }
});
test("no automatic integration of raw completion and partial results remain raw", async t => {
  const f = await fixture(t); await run(f); assert.equal((await loaded(f)).snapshot.nodes.some(n => n.id.includes(":proposal:")), false);
  const g = await fixture(t); const r = await run(g, request(), { id: "resident-mock", version: "1", async execute(_r, { emit }) { await emit({ kind: "output", content: "partial", details: { encoding: "json-string" } }); return { kind: "partial", outputStatus: "partial", parseStatus: "unknown", diagnostic: "Interrupted" }; } });
  assert.ok(r.history.captureNodeId); await assert.rejects(g.harness.integrate("pulse:execution"), /completed/);
});
test("analogy and compression metadata require explicit boundaries, losses and uncertainties", () => {
  const base = response("contract", { compression: compression(), analogies: analogies() });
  for (const alter of [v => { v.analogies[0].failureBoundaries = []; }, v => { v.analogies[0].differences = []; }, v => { v.compression.omitted = []; }, v => { v.compression.uncertainty = []; }, v => { v.compression.unrecoverable = []; }]) {
    const v = clone(base); alter(v); assert.throws(() => validateResidentResponse(v, { phase: "contract", sourceIds: ["human", "model"] }));
  }
});
test("pre-aborted phase and integration perform no hidden work", async t => {
  const f = await fixture(t), before = await loaded(f), controller = new AbortController(); controller.abort();
  const r = await f.harness.runPhase({ request: request(), adapter: createMockResident(), signal: controller.signal });
  assert.equal(r.outcome, "not-started"); assert.deepEqual(await loaded(f), before);
  await run(f); const captured = await loaded(f); assert.equal((await f.harness.integrate("pulse:execution", { signal: controller.signal })).status, "not-integrated"); assert.deepEqual(await loaded(f), captured);
});
test("resident output cannot exceed the durable output bound", async t => {
  const f = await fixture(t); const r = await run(f, request(), { id: "resident-mock", version: "1", async execute(_r, { emit }) { await emit({ kind: "output", content: "x".repeat(16385), details: { encoding: "json-string" } }); return complete(); } });
  assert.equal(r.history.termination, "capacity-rejection"); assert.equal(r.history.output, ""); await assert.rejects(f.harness.integrate("pulse:execution"), /completed/);
});
test("model-origin authority or budget cannot masquerade as a host grant", async t => {
  for (const change of [a => { a.authority.sourceIds = ["model"]; }, a => { a.resources.budgetSourceId = "model"; }]) {
    const f = await fixture(t), before = await loaded(f); change(f.permission); await assert.rejects(f.harness.prepare(request()), /human\/system/); assert.deepEqual(await loaded(f), before);
  }
});
